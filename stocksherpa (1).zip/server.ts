import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { env } from './backend/src/config/env.ts';
import { getDb } from './backend/src/database/connection.ts';
import { seedDatabase } from './backend/src/database/seed.ts';
import { createApiApp } from './backend/src/app.ts';

async function startServer() {
  const db = getDb();
  const seedResult = seedDatabase(db, false);
  if (seedResult.seeded) {
    console.log(`[StockSherpa] Seeded database with ${seedResult.productsCount} sample kirana products.`);
  }

  const app = createApiApp(db);

  if (env.nodeEnv !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(env.port, '0.0.0.0', () => {
    console.log(`[StockSherpa] Full-stack server running at http://localhost:${env.port}`);
  });
}

startServer().catch((err) => {
  console.error('[StockSherpa] Failed to start server:', err);
  process.exit(1);
});
