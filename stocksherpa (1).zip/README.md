# StockSherpa — Smart Inventory & Reorder Assistant for Kirana Stores

StockSherpa is a full-stack, offline-capable inventory management and supplier reorder platform built specifically for Indian neighborhood kirana stores, grocery shops, and independent FMCG retailers.

---

## Features

- **Real-Time Dashboard & Valuation**: Live KPIs calculated directly from SQLite (`Total Products`, `Inventory Value at Cost`, `Expected Retail Turnover`, `Expected Gross Profit` & margin %, `Low-Stock Products`, `Out-of-Stock Products`, `Pending Purchase Orders`, and `Expiring Products`), paired with interactive Chart.js category valuation and distribution charts.
- **Product Catalog & Stock Ledger**: Complete CRUD with SKU & barcode uniqueness validation, non-negative pricing/stock enforcement, debounced multi-field search, category/status filters, sorting, and mobile-first touch cards.
- **Quick Stock In / Out**: Instant `-1`, `+1`, `+10`, and custom quantity adjustments across 5 movement types (`Sale`, `Supplier delivery`, `Manual correction`, `Damaged goods`, `Returned goods`), backed by atomic SQLite transactions.
- **Automated Low-Stock & Out-of-Stock Alerts**: Automatic threshold monitoring (`current_quantity <= minimum_stock_threshold`) with real-time alert recalculation after every transaction.
- **Smart Reorder Assistant & Consolidated POs**: Identifies low-stock items, computes recommended order quantities (`target_stock_level - current_quantity`), groups items by preferred supplier, and generates consolidated Purchase Orders (`Draft`, `Pending`, `Sent`, `Partially Received`, `Received`, `Cancelled`). Orders are only marked `Received` when inventory is atomically incremented.
- **WhatsApp Supplier Order Dispatch**: Generates a formatted purchase order message with store name, supplier, line items, quantities, and total estimated cost, and opens WhatsApp click-to-chat (`https://wa.me/...`) for user confirmation and dispatch.
- **Perishable Expiry Tracker**: Monitors expiry schedules across `Expired`, `Critical (≤7 days)`, `Expiring Soon (≤15 days)`, `Watch (≤30 days)`, and `Safe` intervals with batch write-off support.
- **Barcode Scanner**: HTML5 camera barcode scanner (`html5-qrcode`) for EAN-13/EAN-8/UPC codes with graceful permission-denied/camera-unavailable handling and manual barcode/SKU fallback.
- **Supplier Management**: Directory with contact validation, associated product counts, purchase history, and outstanding POs.
- **Offline Support & PWA**: Installable Progressive Web App (`vite-plugin-pwa`) with Workbox caching, offline stock adjustment queue (`operationId` + `expectedVersion`), optimistic conflict detection, and explicit server acknowledgement.

---

## Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide Icons, Chart.js (`react-chartjs-2`), Motion, `html5-qrcode`, `vite-plugin-pwa`
- **Backend**: Node.js, Express.js, TypeScript, Zod validation, Helmet, CORS, `express-rate-limit`
- **Database**: SQLite (`better-sqlite3`) with WAL mode, foreign keys, and ACID transactions
- **Testing**: Vitest + Supertest

---

## Architecture & Folder Structure

```text
stocksherpa/
├── server.ts                          # Unified server entrypoint (Express API + Vite SSR/Static on port 3000)
├── vite.config.ts                     # Vite + Tailwind v4 + VitePWA configuration
├── package.json                       # Scripts & dependencies
├── .env.example                       # Environment variable template
├── backend/
│   ├── src/
│   │   ├── app.ts                     # Express app factory (security, JSON parsing, API routes, error handler)
│   │   ├── config/env.ts              # Environment configuration
│   │   ├── controllers/apiController.ts
│   │   ├── database/
│   │   │   ├── connection.ts          # SQLite connection, WAL mode, transaction helper
│   │   │   ├── schema.ts              # SQLite DDL & indexes
│   │   │   ├── seed.ts                # 60 realistic Indian kirana products + suppliers + sample POs
│   │   │   └── seedCli.ts             # CLI seed script
│   │   ├── middleware/
│   │   │   ├── errorHandler.ts        # Safe centralized API error handling
│   │   │   └── security.ts            # Helmet, CORS, rate limiting, sanitization
│   │   ├── routes/apiRoutes.ts        # REST API endpoint definitions
│   │   ├── services/
│   │   │   ├── dashboardService.ts    # Real-time KPIs & Chart analytics
│   │   │   ├── expiryService.ts       # 7/15/30 day expiry tracking
│   │   │   ├── productService.ts      # Product CRUD, search, filter, sort
│   │   │   ├── reorderService.ts      # Reorder suggestions & atomic PO receiving
│   │   │   ├── stockService.ts        # Transactional stock adjustments & conflict detection
│   │   │   └── supplierService.ts     # Supplier CRUD & purchase history
│   │   ├── types/index.ts
│   │   ├── utils/errors.ts
│   │   └── validators/schemas.ts      # Zod validation schemas
│   └── tests/api.test.ts              # Vitest + Supertest integration suite
├── public/                            # PWA icons & SVG assets
└── src/                               # React frontend
    ├── App.tsx
    ├── components/                    # Reusable UI, modals, barcode scanner, PO & WhatsApp modal, charts
    ├── hooks/                         # useDebounce, useOnlineSync, usePWAInstall, useToast
    ├── pages/                         # Dashboard, Catalog, Reorder, Expiry, Suppliers, Movements, Settings
    ├── services/                      # Typed REST API client & offline sync queue
    ├── types/inventory.ts
    └── utils/format.ts                # INR formatting, CSV export, WhatsApp message builder
```

---

## Database Schema Documentation

- `categories`: Store categories (`Grains`, `Dairy`, `Snacks`, `Personal Care`)
- `suppliers`: Wholesale distributors (`id`, `name`, `contact_person`, `phone`, `email`, `address`, `is_sample`)
- `products`: Inventory items (`id`, `name`, `sku` UNIQUE, `barcode` UNIQUE, `category`, `cost_price`, `selling_price`, `current_quantity`, `minimum_stock_threshold`, `target_stock_level`, `unit`, `supplier_id`, `expiry_date`, `version`, `is_sample`, timestamps)
- `stock_movements`: Immutable transaction ledger (`id`, `product_id`, `movement_type`, `quantity_changed`, `previous_quantity`, `new_quantity`, `reason`, `reference_po_id`, `client_operation_id` UNIQUE, `created_at`)
- `purchase_orders`: Consolidated supplier orders (`id`, `order_number` UNIQUE, `supplier_id`, `store_name`, `status`, `total_cost`, `notes`, `order_date`, `received_at`)
- `purchase_order_items`: Line items (`id`, `purchase_order_id`, `product_id`, `product_name`, `sku`, `quantity_ordered`, `quantity_received`, `unit_cost`, `line_total`)
- `expiry_records`: Batch expiry tracking (`id`, `product_id`, `batch_code`, `quantity`, `expiry_date`, `notes`)
- `app_settings`: Key-value store configuration (`store_name`, `owner_name`, `store_phone`, `store_address`)

---

## Setup & Installation

### 1. Prerequisites
- **Node.js v22+** (LTS recommended)
- **npm v10+**

### 2. Install Dependencies (Windows PowerShell / macOS / Linux)

```powershell
npm install
```

### 3. Environment Configuration (Windows PowerShell)

```powershell
Copy-Item .env.example .env
```

Default `.env` runs the unified Express + Vite application on **port 3000** (`http://localhost:3000`) and stores SQLite at `./data/stocksherpa.db`. No port conflicts exist because Express serves both `/api/*` and the Vite frontend on the same port.

### 4. Database Initialization & Seeding

The server automatically initializes the SQLite schema and seeds 60 realistic Indian kirana products on first boot if the database is empty. To manually seed or reset the database:

```powershell
# Seed if empty
npm run seed

# Force reset and re-seed 60 sample products
npx tsx backend/src/database/seedCli.ts --force
```

### 5. Running the Application

**Development mode** (Express API + Vite middleware on `http://localhost:3000`):
```powershell
npm run dev
```

**Production build & start**:
```powershell
npm run build
npm start
```

---

## REST API Endpoints

| Group | Method & Path | Description |
| :--- | :--- | :--- |
| **System** | `GET /api/health` | Health check and product count |
| **Dashboard** | `GET /api/dashboard/summary` | Live KPI totals and valuation metrics |
| | `GET /api/dashboard/analytics` | Category breakdown, alerts, recent movements & POs |
| **Products** | `GET /api/products` | List/search/filter/sort products |
| | `GET /api/products/barcode/:code` | Lookup product by EAN barcode or SKU |
| | `GET /api/products/:id` | Get single product |
| | `POST /api/products` | Create product |
| | `PUT /api/products/:id` | Update product |
| | `DELETE /api/products/:id` | Delete product |
| **Stock** | `POST /api/stock/adjust` | Transactional stock adjustment (supports offline `client_operation_id` & `expected_version`) |
| | `GET /api/stock/movements` | Filterable stock movement ledger |
| | `GET /api/stock/movements/:productId` | Movements for a specific product |
| **Suppliers** | `GET /api/suppliers` | List suppliers with product & PO counts |
| | `GET /api/suppliers/:id` | Supplier details, products & purchase history |
| | `POST /api/suppliers` | Add supplier |
| | `PUT /api/suppliers/:id` | Update supplier |
| | `DELETE /api/suppliers/:id` | Delete supplier |
| **Reorder** | `GET /api/reorder/suggestions` | Low-stock items with recommended reorder quantities |
| | `POST /api/reorder/generate` | Generate consolidated purchase order |
| **Orders** | `GET /api/purchase-orders` | List purchase orders |
| | `POST /api/purchase-orders` | Create purchase order |
| | `GET /api/purchase-orders/:id` | Get purchase order with line items |
| | `PUT /api/purchase-orders/:id` | Update PO status or receive stock atomically |
| **Expiry** | `GET /api/expiry` | List tracked expiry items (`?days=7\|15\|30`) |
| | `GET /api/expiry/alerts` | Grouped expiry buckets (`expired`, `7d`, `15d`, `30d`, `safe`) |
| **Settings** | `GET /api/settings`, `PUT /api/settings` | Read/update store profile |
| | `POST /api/demo/reset` | Restore the 60-product sample dataset |

---

## Testing

Run the automated Vitest + Supertest suite (tests 60-product seeding, the hackathon demo scenario, negative stock prevention, duplicate SKU rejection, offline idempotency & version conflict detection, PO stock receiving, expiry alerts, and SQLite disk persistence):

```powershell
npm test
```

Type-check & production build check:

```powershell
npm run lint
npm run build
```

---

## Hackathon Demonstration Workflow

1. Open **StockSherpa** at `http://localhost:3000`.
2. Observe the **Dashboard** displaying **60 sample kirana products** and live inventory valuation (`Cost Value`, `Expected Retail Turnover`, `Expected Gross Profit`).
3. Navigate to **Product Catalog** and search for **`Atta`**.
4. Locate **Aashirvaad Shudh Chakki Atta (5kg)** with quantity **`6`**.
5. Click **Adjust**, deduct **`4`** units as **`Sale`**, and apply -> quantity becomes **`2`** and an immediate **Low Stock** alert triggers.
6. Navigate to **Reorder Assistant** -> verify **Atta** automatically appears under **Annapurna Wholesale Grains** with recommended quantity **`18`**.
7. Click **Generate WhatsApp Order** (or **Generate Purchase Order**) -> preview the consolidated PO and formatted WhatsApp supplier message.
8. Navigate to **Stock Ledger** -> verify the **`-4` Sale** transaction is recorded (`6 → 2`).
9. Return to **Dashboard** -> verify **Low-Stock Products**, **Pending Purchase Orders**, and **Inventory Valuation** KPIs have updated in real time from SQLite.

---

## Troubleshooting

- **Camera scanner unavailable**: Browsers require HTTPS (or `localhost`) for `navigator.mediaDevices.getUserMedia`. If camera permissions are denied or no webcam is present, use the built-in manual barcode/SKU input or quick-lookup buttons inside the Scanner dialog.
- **Native module build on Windows (`better-sqlite3`)**: Ensure Node.js LTS is installed; prebuilt binaries are downloaded automatically during `npm install`. If compilation is triggered, install Windows Build Tools (`winget install Microsoft.VisualStudio.2022.BuildTools`).
- **Port 3000 already in use**: Set `PORT=3001` in `.env` and restart with `npm run dev`.
