import { useCallback, useEffect, useState } from 'react';
import {
  type QueuedStockOperation,
  readOfflineQueue,
  removeQueuedOperation,
  syncOfflineQueue,
} from '../services/offlineQueue.ts';

export type SyncState = 'online' | 'offline' | 'syncing' | 'sync_failed';

export function useOnlineSync(onSynced?: () => void) {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [queue, setQueue] = useState<QueuedStockOperation[]>(() => readOfflineQueue());
  const [syncState, setSyncState] = useState<SyncState>(
    typeof navigator !== 'undefined' && !navigator.onLine ? 'offline' : 'online'
  );

  const refreshQueue = useCallback(() => {
    const current = readOfflineQueue();
    setQueue(current);
    return current;
  }, []);

  const runSync = useCallback(
    async (forceOperationId?: string) => {
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        setIsOnline(false);
        setSyncState('offline');
        return { synced: 0, conflicts: 0, failed: 0 };
      }

      const currentQueue = readOfflineQueue();
      if (currentQueue.length === 0) {
        setSyncState('online');
        return { synced: 0, conflicts: 0, failed: 0 };
      }

      setSyncState('syncing');
      const result = await syncOfflineQueue({ forceOperationId });
      const updated = refreshQueue();

      if (result.conflicts > 0 || result.failed > 0 || updated.length > 0) {
        setSyncState('sync_failed');
      } else {
        setSyncState('online');
      }

      if (result.synced > 0 && onSynced) {
        onSynced();
      }
      return result;
    },
    [onSynced, refreshQueue]
  );

  const discardOperation = useCallback(
    (operationId: string) => {
      removeQueuedOperation(operationId);
      const updated = refreshQueue();
      if (updated.length === 0) {
        setSyncState(isOnline ? 'online' : 'offline');
      }
    },
    [isOnline, refreshQueue]
  );

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      void runSync();
    };
    const handleOffline = () => {
      setIsOnline(false);
      setSyncState('offline');
    };
    const handleQueueUpdated = () => {
      const q = refreshQueue();
      if (!navigator.onLine) {
        setSyncState('offline');
      } else if (q.some((item) => item.status === 'conflict' || item.status === 'failed')) {
        setSyncState('sync_failed');
      }
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('stocksherpa:queue-updated', handleQueueUpdated);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('stocksherpa:queue-updated', handleQueueUpdated);
    };
  }, [refreshQueue, runSync]);

  return {
    isOnline,
    syncState,
    queue,
    runSync,
    discardOperation,
    refreshQueue,
  };
}
