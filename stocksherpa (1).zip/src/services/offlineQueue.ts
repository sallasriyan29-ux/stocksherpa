import type { MovementType, Product } from '../types/inventory.ts';
import { ApiError, api } from './api.ts';

export interface QueuedStockOperation {
  operationId: string;
  productId: number;
  productName: string;
  productSku: string;
  quantityChanged: number;
  movementType: MovementType;
  reason: string;
  expectedVersion: number;
  queuedAt: string;
  retries: number;
  status: 'pending' | 'syncing' | 'conflict' | 'failed';
  errorMessage?: string;
  conflictDetails?: {
    server_quantity?: number;
    server_version?: number;
    expected_version?: number;
  };
}

const QUEUE_KEY = 'stocksherpa_offline_queue_v1';
const CACHE_PRODUCTS_KEY = 'stocksherpa_cached_products_v1';

export function readOfflineQueue(): QueuedStockOperation[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function writeOfflineQueue(queue: QueuedStockOperation[]): void {
  try {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
    window.dispatchEvent(new CustomEvent('stocksherpa:queue-updated'));
  } catch {
    // ignore storage quota errors
  }
}

export function enqueueStockOperation(input: {
  product: Product;
  quantityChanged: number;
  movementType: MovementType;
  reason: string;
}): QueuedStockOperation {
  const op: QueuedStockOperation = {
    operationId: `op_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    productId: input.product.id,
    productName: input.product.name,
    productSku: input.product.sku,
    quantityChanged: input.quantityChanged,
    movementType: input.movementType,
    reason: input.reason,
    expectedVersion: input.product.version,
    queuedAt: new Date().toISOString(),
    retries: 0,
    status: 'pending',
  };

  const queue = readOfflineQueue();
  queue.push(op);
  writeOfflineQueue(queue);
  return op;
}

export function removeQueuedOperation(operationId: string): void {
  const queue = readOfflineQueue().filter((q) => q.operationId !== operationId);
  writeOfflineQueue(queue);
}

export function cacheProductsSnapshot(products: Product[]): void {
  try {
    localStorage.setItem(CACHE_PRODUCTS_KEY, JSON.stringify(products));
  } catch {
    // ignore storage errors
  }
}

export function readCachedProducts(): Product[] {
  try {
    const raw = localStorage.getItem(CACHE_PRODUCTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export async function syncOfflineQueue(options?: {
  forceOperationId?: string;
}): Promise<{ synced: number; conflicts: number; failed: number }> {
  const queue = readOfflineQueue();
  if (queue.length === 0) {
    return { synced: 0, conflicts: 0, failed: 0 };
  }

  let synced = 0;
  let conflicts = 0;
  let failed = 0;
  const remaining: QueuedStockOperation[] = [];

  for (const op of queue) {
    // Skip conflicted items unless user explicitly clicked Force Resolve for that operation
    if (op.status === 'conflict' && options?.forceOperationId !== op.operationId) {
      conflicts++;
      remaining.push(op);
      continue;
    }

    const isForced = options?.forceOperationId === op.operationId;
    try {
      await api.adjustStock({
        product_id: op.productId,
        quantity_changed: op.quantityChanged,
        movement_type: op.movementType,
        reason: op.reason,
        client_operation_id: op.operationId,
        expected_version: isForced ? undefined : op.expectedVersion,
      });
      synced++;
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        conflicts++;
        remaining.push({
          ...op,
          status: 'conflict',
          errorMessage: err.message,
          conflictDetails: err.details as QueuedStockOperation['conflictDetails'],
        });
      } else {
        failed++;
        remaining.push({
          ...op,
          retries: op.retries + 1,
          status: 'failed',
          errorMessage: err instanceof Error ? err.message : 'Sync failed',
        });
      }
    }
  }

  writeOfflineQueue(remaining);
  return { synced, conflicts, failed };
}
