import type {
  DashboardAnalytics,
  DashboardSummary,
  ExpiryRecord,
  MovementType,
  Product,
  PurchaseOrder,
  PurchaseOrderStatus,
  ReorderSuggestion,
  StockMovement,
  StoreSettings,
  Supplier,
} from '../types/inventory.ts';

export class ApiError extends Error {
  status: number;
  code: string;
  details?: unknown;

  constructor(message: string, status: number, code = 'API_ERROR', details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

async function requestJson<T>(url: string, options?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {}),
      },
    });
  } catch {
    throw new ApiError('Network unavailable. Check your connection.', 0, 'NETWORK_ERROR');
  }

  let payload: Record<string, unknown> = {};
  try {
    payload = (await response.json()) as Record<string, unknown>;
  } catch {
    // non-json response
  }

  if (!response.ok) {
    throw new ApiError(
      (payload.message as string) || `Request failed (${response.status})`,
      response.status,
      (payload.error as string) || 'API_ERROR',
      payload.details
    );
  }

  return payload as T;
}

export const api = {
  health: () => requestJson<{ status: string; products_count: number }>('/api/health'),

  // Dashboard
  getDashboardSummary: () =>
    requestJson<{ data: DashboardSummary }>('/api/dashboard/summary').then((r) => r.data),
  getDashboardAnalytics: () =>
    requestJson<{ data: DashboardAnalytics }>('/api/dashboard/analytics').then((r) => r.data),

  // Products
  listProducts: (params?: {
    search?: string;
    category?: string;
    status?: string;
    sort?: string;
    supplier_id?: number;
  }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.category && params.category !== 'All') qs.set('category', params.category);
    if (params?.status && params.status !== 'All') qs.set('status', params.status);
    if (params?.sort) qs.set('sort', params.sort);
    if (params?.supplier_id) qs.set('supplier_id', String(params.supplier_id));
    const query = qs.toString();
    return requestJson<{ data: Product[]; count: number }>(
      `/api/products${query ? `?${query}` : ''}`
    ).then((r) => r.data);
  },

  getProduct: (id: number) =>
    requestJson<{ data: Product }>(`/api/products/${id}`).then((r) => r.data),

  lookupBarcode: (code: string) =>
    requestJson<{ data: Product }>(`/api/products/barcode/${encodeURIComponent(code)}`).then(
      (r) => r.data
    ),

  createProduct: (body: {
    name: string;
    sku: string;
    barcode?: string | null;
    category: string;
    cost_price: number;
    selling_price: number;
    current_quantity: number;
    minimum_stock_threshold: number;
    target_stock_level?: number;
    unit: string;
    supplier_id?: number | null;
    expiry_date?: string | null;
  }) =>
    requestJson<{ data: Product; message: string }>('/api/products', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  updateProduct: (id: number, body: Record<string, unknown>) =>
    requestJson<{ data: Product; message: string }>(`/api/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(body),
    }),

  deleteProduct: (id: number) =>
    requestJson<{ data: { deleted: boolean; id: number }; message: string }>(
      `/api/products/${id}`,
      { method: 'DELETE' }
    ),

  // Stock Adjustments & Movements
  adjustStock: (body: {
    product_id: number;
    quantity_changed: number;
    movement_type: MovementType;
    reason: string;
    client_operation_id?: string;
    expected_version?: number;
  }) =>
    requestJson<{
      data: { product: Product; movement: StockMovement; already_processed?: boolean };
      message: string;
    }>('/api/stock/adjust', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  listMovements: (params?: {
    search?: string;
    movement_type?: string;
    product_id?: number;
    date_from?: string;
    date_to?: string;
    limit?: number;
  }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.movement_type && params.movement_type !== 'All')
      qs.set('movement_type', params.movement_type);
    if (params?.product_id) qs.set('product_id', String(params.product_id));
    if (params?.date_from) qs.set('date_from', params.date_from);
    if (params?.date_to) qs.set('date_to', params.date_to);
    if (params?.limit) qs.set('limit', String(params.limit));
    const query = qs.toString();
    return requestJson<{ data: StockMovement[] }>(
      `/api/stock/movements${query ? `?${query}` : ''}`
    ).then((r) => r.data);
  },

  listProductMovements: (productId: number) =>
    requestJson<{ data: StockMovement[] }>(`/api/stock/movements/${productId}`).then((r) => r.data),

  // Suppliers
  listSuppliers: (search?: string) =>
    requestJson<{ data: Supplier[] }>(
      `/api/suppliers${search ? `?search=${encodeURIComponent(search)}` : ''}`
    ).then((r) => r.data),

  getSupplier: (id: number) =>
    requestJson<{ data: Supplier }>(`/api/suppliers/${id}`).then((r) => r.data),

  createSupplier: (body: {
    name: string;
    contact_person: string;
    phone: string;
    email?: string | null;
    address?: string | null;
  }) =>
    requestJson<{ data: Supplier; message: string }>('/api/suppliers', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  updateSupplier: (id: number, body: Record<string, unknown>) =>
    requestJson<{ data: Supplier; message: string }>(`/api/suppliers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(body),
    }),

  deleteSupplier: (id: number) =>
    requestJson<{ data: { deleted: boolean }; message: string }>(`/api/suppliers/${id}`, {
      method: 'DELETE',
    }),

  // Reorder & Purchase Orders
  getReorderSuggestions: () =>
    requestJson<{ data: ReorderSuggestion[] }>('/api/reorder/suggestions').then((r) => r.data),

  generatePurchaseOrder: (body: {
    supplier_id: number;
    status?: 'Draft' | 'Pending' | 'Sent';
    notes?: string | null;
    items: Array<{ product_id: number; quantity_ordered: number; unit_cost?: number }>;
  }) =>
    requestJson<{ data: PurchaseOrder; message: string }>('/api/reorder/generate', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  listPurchaseOrders: (status?: string) =>
    requestJson<{ data: PurchaseOrder[] }>(
      `/api/purchase-orders${status && status !== 'All' ? `?status=${encodeURIComponent(status)}` : ''}`
    ).then((r) => r.data),

  getPurchaseOrder: (id: number) =>
    requestJson<{ data: PurchaseOrder }>(`/api/purchase-orders/${id}`).then((r) => r.data),

  updatePurchaseOrder: (
    id: number,
    body: {
      status?: PurchaseOrderStatus;
      notes?: string | null;
      received_items?: Array<{ product_id: number; quantity_received: number }>;
    }
  ) =>
    requestJson<{ data: PurchaseOrder; message: string }>(`/api/purchase-orders/${id}`, {
      method: 'PUT',
      body: JSON.stringify(body),
    }),

  // Expiry
  listExpiry: (days?: number) =>
    requestJson<{ data: ExpiryRecord[] }>(
      `/api/expiry${days !== undefined ? `?days=${days}` : ''}`
    ).then((r) => r.data),

  getExpiryAlerts: () =>
    requestJson<{
      data: {
        expired: ExpiryRecord[];
        within_7_days: ExpiryRecord[];
        within_15_days: ExpiryRecord[];
        within_30_days: ExpiryRecord[];
        safe: ExpiryRecord[];
        counts: { expired: number; days_7: number; days_15: number; days_30: number; safe: number };
      };
    }>('/api/expiry/alerts').then((r) => r.data),

  // Settings & Demo
  getSettings: () => requestJson<{ data: StoreSettings }>('/api/settings').then((r) => r.data),

  updateSettings: (body: Partial<StoreSettings>) =>
    requestJson<{ data: StoreSettings; message: string }>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(body),
    }),

  resetDemoData: () =>
    requestJson<{ data: { seeded: boolean; productsCount: number }; message: string }>(
      '/api/demo/reset',
      { method: 'POST' }
    ),
};
