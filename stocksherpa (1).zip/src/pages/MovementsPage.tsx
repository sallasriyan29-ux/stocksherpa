import { History, Search } from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { useDebounce } from '../hooks/useDebounce.ts';
import type { MovementType, Product, StockMovement } from '../types/inventory.ts';
import { formatDateTime } from '../utils/format.ts';

interface MovementsPageProps {
  movements: StockMovement[];
  products: Product[];
  loading: boolean;
}

const MOVEMENT_TYPES: Array<'All' | MovementType> = [
  'All',
  'Sale',
  'Supplier delivery',
  'Manual correction',
  'Damaged goods',
  'Returned goods',
];

export function MovementsPage({ movements, products, loading }: MovementsPageProps) {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [productFilter, setProductFilter] = useState<string>('All');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const debounced = useDebounce(search, 180);

  const filtered = useMemo(() => {
    const q = debounced.trim().toLowerCase();
    return movements.filter((m) => {
      if (typeFilter !== 'All' && m.movement_type !== typeFilter) return false;
      if (productFilter !== 'All' && String(m.product_id) !== productFilter) return false;

      const movDate = m.created_at.slice(0, 10);
      if (dateFrom && movDate < dateFrom) return false;
      if (dateTo && movDate > dateTo) return false;

      if (q) {
        const hay = `${m.product_name || ''} ${m.product_sku || ''} ${m.reason} ${m.reference_order_number || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [movements, debounced, typeFilter, productFilter, dateFrom, dateTo]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-4"
    >
      {/* Filters */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
          <div className="relative md:col-span-2">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by product, SKU, reason, or PO number..."
              className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
            />
          </div>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800"
          >
            {MOVEMENT_TYPES.map((t) => (
              <option key={t} value={t}>
                Type: {t}
              </option>
            ))}
          </select>

          <select
            value={productFilter}
            onChange={(e) => setProductFilter(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800"
          >
            <option value="All">Product: All Items</option>
            {products.map((p) => (
              <option key={p.id} value={String(p.id)}>
                {p.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
            <label className="flex items-center gap-1.5">
              <span>From</span>
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="rounded-md border border-slate-300 px-2 py-1 font-mono text-xs"
              />
            </label>
            <label className="flex items-center gap-1.5">
              <span>To</span>
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="rounded-md border border-slate-300 px-2 py-1 font-mono text-xs"
              />
            </label>
            {(search || typeFilter !== 'All' || productFilter !== 'All' || dateFrom || dateTo) && (
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setTypeFilter('All');
                  setProductFilter('All');
                  setDateFrom('');
                  setDateTo('');
                }}
                className="font-semibold text-emerald-700 hover:underline"
              >
                Clear filters
              </button>
            )}
          </div>
          <span className="font-mono text-xs text-slate-500 tabular-nums">
            {filtered.length} ledger entries
          </span>
        </div>
      </div>

      {loading && movements.length === 0 ? (
        <div className="h-48 animate-pulse rounded-xl border border-slate-200 bg-white" />
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <History className="mx-auto h-9 w-9 text-slate-400" />
          <h3 className="mt-3 font-display text-base font-bold text-slate-900">
            No stock movements match these filters
          </h3>
          <p className="mt-1 text-sm text-slate-500">
            Stock sales, deliveries, and corrections are logged here automatically.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
              <tr>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-3 py-3">Product</th>
                <th className="px-3 py-3">Movement Type</th>
                <th className="px-3 py-3 text-right">Change</th>
                <th className="px-3 py-3 text-right">Previous → New</th>
                <th className="px-4 py-3">Reason / Reference PO</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((m) => (
                <tr key={m.id} className="hover:bg-slate-50/70">
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-500 whitespace-nowrap">
                    {formatDateTime(m.created_at)}
                  </td>
                  <td className="px-3 py-2.5">
                    <p className="font-medium text-slate-900">{m.product_name}</p>
                    <p className="font-mono text-xs text-slate-500">{m.product_sku}</p>
                  </td>
                  <td className="px-3 py-2.5 text-xs font-medium text-slate-700 whitespace-nowrap">
                    {m.movement_type}
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono font-bold tabular-nums">
                    <span className={m.quantity_changed > 0 ? 'text-emerald-700' : 'text-red-600'}>
                      {m.quantity_changed > 0 ? `+${m.quantity_changed}` : m.quantity_changed}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs text-slate-700 tabular-nums whitespace-nowrap">
                    {m.previous_quantity} → <strong className="text-slate-900">{m.new_quantity}</strong>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-slate-600">
                    <span>{m.reason}</span>
                    {m.reference_order_number && (
                      <span className="ml-2 font-mono font-semibold text-emerald-700">
                        ({m.reference_order_number})
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  );
}
