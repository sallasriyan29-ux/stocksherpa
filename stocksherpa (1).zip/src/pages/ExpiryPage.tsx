import { AlertTriangle, CheckCircle2, Clock, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { ExpiryStatusBadge } from '../components/StatusBadge.tsx';
import type { ExpiryRecord, MovementType, Product } from '../types/inventory.ts';
import { formatDate, formatINR } from '../utils/format.ts';

interface ExpiryPageProps {
  records: ExpiryRecord[];
  products: Product[];
  loading: boolean;
  onQuickAdjust: (
    product: Product,
    delta: number,
    type: MovementType,
    reason: string
  ) => Promise<void>;
}

type ExpiryWindowFilter = 'all' | 'expired' | '7' | '15' | '30' | 'safe';

export function ExpiryPage({ records, products, loading, onQuickAdjust }: ExpiryPageProps) {
  const [filter, setFilter] = useState<ExpiryWindowFilter>('30');

  const counts = useMemo(
    () => ({
      expired: records.filter((r) => r.days_remaining < 0).length,
      days7: records.filter((r) => r.days_remaining >= 0 && r.days_remaining <= 7).length,
      days15: records.filter((r) => r.days_remaining >= 0 && r.days_remaining <= 15).length,
      days30: records.filter((r) => r.days_remaining >= 0 && r.days_remaining <= 30).length,
      safe: records.filter((r) => r.days_remaining > 30).length,
    }),
    [records]
  );

  const filtered = useMemo(() => {
    switch (filter) {
      case 'expired':
        return records.filter((r) => r.days_remaining < 0);
      case '7':
        return records.filter((r) => r.days_remaining <= 7);
      case '15':
        return records.filter((r) => r.days_remaining <= 15);
      case '30':
        return records.filter((r) => r.days_remaining <= 30);
      case 'safe':
        return records.filter((r) => r.days_remaining > 30);
      case 'all':
      default:
        return records;
    }
  }, [records, filter]);

  const handleWriteOff = (record: ExpiryRecord) => {
    const prod = products.find((p) => p.id === record.product_id);
    if (!prod || prod.current_quantity <= 0) return;
    void onQuickAdjust(
      prod,
      -prod.current_quantity,
      'Damaged goods',
      `Expired batch write-off (${record.batch_code})`
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-5"
    >
      {/* Window Summary Cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        <button
          type="button"
          onClick={() => setFilter('expired')}
          className={`rounded-xl border p-4 text-left transition-colors ${
            filter === 'expired' ? 'border-red-500 bg-red-50/40' : 'border-slate-200 bg-white'
          }`}
        >
          <p className="text-xs font-medium text-slate-500">Expired</p>
          <p className="mt-1 font-mono text-2xl font-bold text-red-600 tabular-nums">
            {counts.expired}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setFilter('7')}
          className={`rounded-xl border p-4 text-left transition-colors ${
            filter === '7' ? 'border-red-500 bg-red-50/40' : 'border-slate-200 bg-white'
          }`}
        >
          <p className="text-xs font-medium text-slate-500">Critical (≤7d)</p>
          <p className="mt-1 font-mono text-2xl font-bold text-red-600 tabular-nums">
            {counts.days7}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setFilter('15')}
          className={`rounded-xl border p-4 text-left transition-colors ${
            filter === '15' ? 'border-amber-500 bg-amber-50/40' : 'border-slate-200 bg-white'
          }`}
        >
          <p className="text-xs font-medium text-slate-500">Alert (≤15d)</p>
          <p className="mt-1 font-mono text-2xl font-bold text-amber-700 tabular-nums">
            {counts.days15}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setFilter('30')}
          className={`rounded-xl border p-4 text-left transition-colors ${
            filter === '30' ? 'border-amber-500 bg-amber-50/40' : 'border-slate-200 bg-white'
          }`}
        >
          <p className="text-xs font-medium text-slate-500">Watch (≤30d)</p>
          <p className="mt-1 font-mono text-2xl font-bold text-amber-700 tabular-nums">
            {counts.days30}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setFilter('safe')}
          className={`col-span-2 sm:col-span-1 rounded-xl border p-4 text-left transition-colors ${
            filter === 'safe' ? 'border-emerald-600 bg-emerald-50/40' : 'border-slate-200 bg-white'
          }`}
        >
          <p className="text-xs font-medium text-slate-500">Safe (&gt;30d)</p>
          <p className="mt-1 font-mono text-2xl font-bold text-emerald-700 tabular-nums">
            {counts.safe}
          </p>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-5 py-3">
        <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1">
          {[
            { id: '30', label: 'Expiring ≤ 30 Days' },
            { id: '15', label: '≤ 15 Days' },
            { id: '7', label: '≤ 7 Days' },
            { id: 'expired', label: 'Expired Only' },
            { id: 'safe', label: 'Safe Stock' },
            { id: 'all', label: 'All Tracked' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilter(tab.id as ExpiryWindowFilter)}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                filter === tab.id
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <span className="font-mono text-xs text-slate-500 tabular-nums">
          {filtered.length} product{filtered.length === 1 ? '' : 's'}
        </span>
      </div>

      {loading && records.length === 0 ? (
        <div className="h-48 animate-pulse rounded-xl border border-slate-200 bg-white" />
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <CheckCircle2 className="mx-auto h-9 w-9 text-emerald-600" />
          <h3 className="mt-3 font-display text-base font-bold text-slate-900">
            No items in this expiry window
          </h3>
          <p className="mt-1 text-sm text-slate-500">
            Select another date interval above to inspect other perishable batches.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
              <tr>
                <th className="px-5 py-3">Product</th>
                <th className="px-3 py-3">Batch</th>
                <th className="px-3 py-3 text-right">Stock Qty</th>
                <th className="px-3 py-3 text-right">At-Risk Cost</th>
                <th className="px-3 py-3">Expiry Date</th>
                <th className="px-3 py-3 text-right">Days Remaining</th>
                <th className="px-3 py-3">Status</th>
                <th className="px-5 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((item) => {
                const isDanger = item.days_remaining <= 7;
                return (
                  <tr
                    key={`${item.product_id}-${item.batch_code}`}
                    className={isDanger ? 'bg-red-50/30' : 'hover:bg-slate-50/70'}
                  >
                    <td className="px-5 py-3">
                      <p className="font-medium text-slate-900">{item.product_name}</p>
                      <p className="font-mono text-xs text-slate-500">
                        {item.sku} · {item.category}
                      </p>
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-slate-600">
                      {item.batch_code}
                    </td>
                    <td className="px-3 py-3 text-right font-mono font-semibold text-slate-900 tabular-nums">
                      {item.current_quantity} {item.unit}
                    </td>
                    <td className="px-3 py-3 text-right font-mono text-xs text-slate-700 tabular-nums">
                      {formatINR(item.current_quantity * item.cost_price)}
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-slate-700">
                      {formatDate(item.expiry_date)}
                    </td>
                    <td className="px-3 py-3 text-right font-mono font-bold tabular-nums">
                      {item.days_remaining < 0 ? (
                        <span className="inline-flex items-center gap-1 text-red-600">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          {Math.abs(item.days_remaining)}d overdue
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-slate-800">
                          <Clock className="h-3.5 w-3.5 text-slate-400" />
                          {item.days_remaining}d
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-3">
                      <ExpiryStatusBadge status={item.expiry_status} />
                    </td>
                    <td className="px-5 py-3 text-right">
                      {item.days_remaining < 0 && item.current_quantity > 0 ? (
                        <button
                          type="button"
                          onClick={() => handleWriteOff(item)}
                          className="inline-flex items-center gap-1 rounded-lg border border-red-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          Write-off Stock
                        </button>
                      ) : (
                        <span className="text-xs text-slate-400">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  );
}
