import {
  AlertTriangle,
  ArrowRight,
  Boxes,
  Clock,
  IndianRupee,
  PackageX,
  Plus,
  ScanBarcode,
  ShoppingCart,
  TrendingUp,
} from 'lucide-react';
import { motion } from 'motion/react';
import { InventoryCharts } from '../components/charts/InventoryCharts.tsx';
import {
  ExpiryStatusBadge,
  PurchaseOrderStatusBadge,
  StockStatusBadge,
} from '../components/StatusBadge.tsx';
import type {
  AppPage,
  DashboardAnalytics,
  DashboardSummary,
  PurchaseOrder,
} from '../types/inventory.ts';
import { formatDateTime, formatINR, formatNumber } from '../utils/format.ts';

interface DashboardPageProps {
  summary: DashboardSummary | null;
  analytics: DashboardAnalytics | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onNavigate: (page: AppPage) => void;
  onOpenScanner: () => void;
  onAddProduct: () => void;
  onOpenOrder: (order: PurchaseOrder) => void;
}

export function DashboardPage({
  summary,
  analytics,
  loading,
  error,
  onRetry,
  onNavigate,
  onOpenScanner,
  onAddProduct,
  onOpenOrder,
}: DashboardPageProps) {
  if (loading && !summary) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-28 animate-pulse rounded-xl border border-slate-200 bg-white p-5" />
          ))}
        </div>
        <div className="h-72 animate-pulse rounded-xl border border-slate-200 bg-white" />
      </div>
    );
  }

  if (error && !summary) {
    return (
      <div className="rounded-xl border border-red-200 bg-white p-8 text-center">
        <AlertTriangle className="mx-auto h-8 w-8 text-red-600" />
        <h2 className="mt-3 font-display text-base font-bold text-slate-900">
          Unable to load dashboard metrics
        </h2>
        <p className="mt-1 text-sm text-slate-600">{error}</p>
        <button
          type="button"
          onClick={onRetry}
          className="mt-4 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
        >
          Retry
        </button>
      </div>
    );
  }

  if (!summary) return null;

  const kpis = [
    {
      label: 'Total Products',
      value: formatNumber(summary.total_products),
      sub: `${formatNumber(summary.total_units)} physical units on shelf`,
      icon: Boxes,
      tone: 'text-slate-900',
      onClick: () => onNavigate('catalog'),
    },
    {
      label: 'Inventory Value at Cost',
      value: formatINR(summary.inventory_value_cost),
      sub: 'Total capital invested in current stock',
      icon: IndianRupee,
      tone: 'text-slate-900',
      onClick: () => onNavigate('catalog'),
    },
    {
      label: 'Expected Retail Turnover',
      value: formatINR(summary.expected_retail_turnover),
      sub: 'Projected sell-through value at MRP',
      icon: TrendingUp,
      tone: 'text-emerald-700',
      onClick: () => onNavigate('catalog'),
    },
    {
      label: 'Expected Gross Profit',
      value: formatINR(summary.expected_gross_profit),
      sub: `${summary.gross_profit_margin.toFixed(1)}% projected margin (not realized revenue)`,
      icon: IndianRupee,
      tone: 'text-emerald-700',
      onClick: () => onNavigate('catalog'),
    },
    {
      label: 'Low-Stock Products',
      value: formatNumber(summary.low_stock_count),
      sub: 'At or below minimum stock threshold',
      icon: AlertTriangle,
      tone: summary.low_stock_count > 0 ? 'text-amber-700' : 'text-slate-900',
      onClick: () => onNavigate('reorder'),
    },
    {
      label: 'Out-of-Stock Products',
      value: formatNumber(summary.out_of_stock_count),
      sub: 'Zero units available for sale',
      icon: PackageX,
      tone: summary.out_of_stock_count > 0 ? 'text-red-600' : 'text-slate-900',
      onClick: () => onNavigate('reorder'),
    },
    {
      label: 'Pending Purchase Orders',
      value: formatNumber(summary.pending_purchase_orders),
      sub: 'Draft, pending, or awaiting delivery',
      icon: ShoppingCart,
      tone: 'text-slate-900',
      onClick: () => onNavigate('reorder'),
    },
    {
      label: 'Expiring Products (≤30d)',
      value: formatNumber(summary.expiring_products_count + summary.expired_products_count),
      sub: `${summary.expired_products_count} expired · ${summary.expiring_products_count} approaching`,
      icon: Clock,
      tone:
        summary.expired_products_count > 0
          ? 'text-red-600'
          : summary.expiring_products_count > 0
            ? 'text-amber-700'
            : 'text-slate-900',
      onClick: () => onNavigate('expiry'),
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-6"
    >
      {/* Quick Actions Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-5 py-3.5">
        <div>
          <p className="text-sm font-semibold text-slate-900">{summary.store_name}</p>
          <p className="text-xs text-slate-500">
            Live SQLite inventory valuation, replenishment alerts, and perishable tracking
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onAddProduct}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
          >
            <Plus className="h-3.5 w-3.5" />
            Add Product
          </button>
          <button
            type="button"
            onClick={onOpenScanner}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            <ScanBarcode className="h-3.5 w-3.5" />
            Scan Barcode
          </button>
          <button
            type="button"
            onClick={() => onNavigate('reorder')}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            <ShoppingCart className="h-3.5 w-3.5" />
            Reorder Assistant
          </button>
        </div>
      </div>

      {/* 8 KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <button
              key={kpi.label}
              type="button"
              onClick={kpi.onClick}
              className="group rounded-xl border border-slate-200 bg-white p-5 text-left transition-colors hover:border-slate-300 hover:bg-slate-50/40"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">{kpi.label}</span>
                <Icon className="h-4 w-4 text-slate-400 group-hover:text-slate-600" />
              </div>
              <p className={`mt-2 font-mono text-2xl font-bold tracking-tight tabular-nums ${kpi.tone}`}>
                {kpi.value}
              </p>
              <p className="mt-1.5 text-xs text-slate-500 truncate">{kpi.sub}</p>
            </button>
          );
        })}
      </div>

      {/* Real Charts */}
      {analytics && <InventoryCharts categories={analytics.category_breakdown} />}

      {/* Actionable Operational Lists */}
      {analytics && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Low Stock Priority List */}
          <div className="rounded-xl border border-slate-200 bg-white">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
              <div>
                <h2 className="font-display text-base font-semibold text-slate-900">
                  Low-Stock & Out-of-Stock Alerts
                </h2>
                <p className="text-xs text-slate-500">
                  Items at or below minimum threshold requiring supplier reorder
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('reorder')}
                className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:underline whitespace-nowrap"
              >
                Reorder All <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="divide-y divide-slate-100">
              {analytics.low_stock_products.length === 0 ? (
                <p className="p-6 text-center text-sm text-slate-500">
                  All products are adequately stocked above their thresholds.
                </p>
              ) : (
                analytics.low_stock_products.slice(0, 6).map((prod) => (
                  <div
                    key={prod.id}
                    className="flex items-center justify-between gap-3 px-5 py-3 text-sm"
                  >
                    <div className="min-w-0">
                      <p className="truncate font-medium text-slate-900">{prod.name}</p>
                      <p className="text-xs text-slate-500">
                        <span className="font-mono">{prod.sku}</span> · Min: {prod.minimum_stock_threshold}{' '}
                        {prod.unit}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                        {prod.current_quantity}
                      </span>
                      <StockStatusBadge status={prod.stock_status} />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Expiry Alerts */}
          <div className="rounded-xl border border-slate-200 bg-white">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
              <div>
                <h2 className="font-display text-base font-semibold text-slate-900">
                  Perishable Expiry Watch
                </h2>
                <p className="text-xs text-slate-500">
                  Products expired or expiring within the next 30 days
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('expiry')}
                className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:underline whitespace-nowrap"
              >
                View Tracker <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="divide-y divide-slate-100">
              {analytics.expiry_alerts.length === 0 ? (
                <p className="p-6 text-center text-sm text-slate-500">
                  No perishable items expiring within 30 days.
                </p>
              ) : (
                analytics.expiry_alerts.slice(0, 6).map((item) => (
                  <div
                    key={`${item.product_id}-${item.batch_code}`}
                    className="flex items-center justify-between gap-3 px-5 py-3 text-sm"
                  >
                    <div className="min-w-0">
                      <p className="truncate font-medium text-slate-900">{item.product_name}</p>
                      <p className="text-xs text-slate-500">
                        Stock: <span className="font-mono tabular-nums">{item.current_quantity}</span>{' '}
                        {item.unit} ·{' '}
                        {item.days_remaining < 0
                          ? `Expired ${Math.abs(item.days_remaining)}d ago`
                          : `${item.days_remaining}d remaining`}
                      </p>
                    </div>
                    <ExpiryStatusBadge status={item.expiry_status} />
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Recent Stock Movements */}
          <div className="rounded-xl border border-slate-200 bg-white">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
              <h2 className="font-display text-base font-semibold text-slate-900">
                Recent Stock Movements
              </h2>
              <button
                type="button"
                onClick={() => onNavigate('movements')}
                className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:underline whitespace-nowrap"
              >
                Full Ledger <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="divide-y divide-slate-100">
              {analytics.recent_movements.slice(0, 6).map((m) => (
                <div
                  key={m.id}
                  className="flex items-center justify-between gap-3 px-5 py-3 text-xs"
                >
                  <div className="min-w-0">
                    <p className="truncate font-medium text-slate-900">{m.product_name}</p>
                    <p className="truncate text-slate-500">
                      {m.movement_type} · {m.reason} · {formatDateTime(m.created_at)}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span
                      className={`font-mono text-sm font-bold tabular-nums ${
                        m.quantity_changed > 0 ? 'text-emerald-700' : 'text-red-600'
                      }`}
                    >
                      {m.quantity_changed > 0 ? `+${m.quantity_changed}` : m.quantity_changed}
                    </span>
                    <p className="font-mono text-[11px] text-slate-500 tabular-nums">
                      {m.previous_quantity} → {m.new_quantity}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Purchase Orders */}
          <div className="rounded-xl border border-slate-200 bg-white">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
              <h2 className="font-display text-base font-semibold text-slate-900">
                Recent Purchase Orders
              </h2>
              <button
                type="button"
                onClick={() => onNavigate('reorder')}
                className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:underline whitespace-nowrap"
              >
                Manage Orders <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="divide-y divide-slate-100">
              {analytics.recent_purchase_orders.length === 0 ? (
                <p className="p-6 text-center text-sm text-slate-500">
                  No purchase orders created yet.
                </p>
              ) : (
                analytics.recent_purchase_orders.map((po) => (
                  <button
                    key={po.id}
                    type="button"
                    onClick={() => onOpenOrder(po)}
                    className="flex w-full items-center justify-between gap-3 px-5 py-3 text-left text-xs hover:bg-slate-50"
                  >
                    <div className="min-w-0">
                      <p className="font-mono font-semibold text-slate-900">{po.order_number}</p>
                      <p className="truncate text-slate-500">
                        {po.supplier_name} · {(po.items || []).length} items
                      </p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="font-mono font-bold text-slate-900 tabular-nums">
                        {formatINR(po.total_cost)}
                      </span>
                      <PurchaseOrderStatusBadge status={po.status} />
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
