import {
  Edit3,
  Eye,
  Minus,
  PackagePlus,
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { StockStatusBadge } from '../components/StatusBadge.tsx';
import { useDebounce } from '../hooks/useDebounce.ts';
import type { MovementType, Product } from '../types/inventory.ts';
import { formatDate, formatINR } from '../utils/format.ts';

interface CatalogPageProps {
  products: Product[];
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onAddProduct: () => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onQuickAdjust: (
    product: Product,
    delta: number,
    type: MovementType,
    reason: string
  ) => Promise<void>;
  onOpenCustomAdjust: (product: Product) => void;
}

const CATEGORIES = ['All', 'Grains', 'Dairy', 'Snacks', 'Personal Care'] as const;
const STATUSES = ['All', 'In Stock', 'Low Stock', 'Out of Stock', 'Expiring Soon'] as const;

export function CatalogPage({
  products,
  loading,
  error,
  onRetry,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onSelectProduct,
  onQuickAdjust,
  onOpenCustomAdjust,
}: CatalogPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('recently_updated');
  const debouncedSearch = useDebounce(searchTerm, 180);

  const filteredProducts = useMemo(() => {
    const q = debouncedSearch.trim().toLowerCase();
    const list = products.filter((p) => {
      if (categoryFilter !== 'All' && p.category !== categoryFilter) return false;
      if (statusFilter === 'In Stock' && p.stock_status !== 'In Stock') return false;
      if (statusFilter === 'Low Stock' && p.stock_status !== 'Low Stock') return false;
      if (statusFilter === 'Out of Stock' && p.stock_status !== 'Out of Stock') return false;
      if (
        statusFilter === 'Expiring Soon' &&
        !(p.expiry_date && p.days_until_expiry !== null && p.days_until_expiry <= 30)
      ) {
        return false;
      }

      if (q) {
        const hay = `${p.name} ${p.sku} ${p.barcode || ''} ${p.category} ${p.supplier_name || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    return [...list].sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'highest_stock':
          return b.current_quantity - a.current_quantity;
        case 'lowest_stock':
          return a.current_quantity - b.current_quantity;
        case 'highest_cost':
          return b.cost_price - a.cost_price;
        case 'lowest_cost':
          return a.cost_price - b.cost_price;
        case 'recently_updated':
        default:
          return b.updated_at.localeCompare(a.updated_at) || b.id - a.id;
      }
    });
  }, [products, debouncedSearch, categoryFilter, statusFilter, sortBy]);

  if (error && products.length === 0) {
    return (
      <div className="rounded-xl border border-red-200 bg-white p-8 text-center">
        <p className="text-sm font-semibold text-red-700">{error}</p>
        <button
          type="button"
          onClick={onRetry}
          className="mt-4 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-4"
    >
      {/* Search, Filters & Sort Toolbar */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by product name, SKU, barcode, or category..."
              className="w-full rounded-lg border border-slate-300 py-2.5 pl-9 pr-3 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by stock status"
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800 focus:border-emerald-600 focus:outline-none"
            >
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  Status: {s}
                </option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              aria-label="Sort products"
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800 focus:border-emerald-600 focus:outline-none"
            >
              <option value="recently_updated">Sort: Recently Updated</option>
              <option value="name">Sort: Product Name (A–Z)</option>
              <option value="lowest_stock">Sort: Lowest Stock</option>
              <option value="highest_stock">Sort: Highest Stock</option>
              <option value="highest_cost">Sort: Highest Cost</option>
              <option value="lowest_cost">Sort: Lowest Cost</option>
            </select>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                  categoryFilter === cat
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <p className="font-mono text-xs text-slate-500 tabular-nums">
            Showing {filteredProducts.length} of {products.length} products
          </p>
        </div>
      </div>

      {/* Loading Skeleton */}
      {loading && products.length === 0 ? (
        <div className="space-y-2 rounded-xl border border-slate-200 bg-white p-4">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div key={idx} className="h-12 animate-pulse rounded-lg bg-slate-100" />
          ))}
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <PackagePlus className="mx-auto h-9 w-9 text-slate-400" />
          <h3 className="mt-3 font-display text-base font-bold text-slate-900">
            No matching products found
          </h3>
          <p className="mt-1 text-sm text-slate-500">
            Try clearing your search or status filter, or add a new item to your store catalog.
          </p>
          <div className="mt-4 flex justify-center gap-2">
            {(searchTerm || categoryFilter !== 'All' || statusFilter !== 'All') && (
              <button
                type="button"
                onClick={() => {
                  setSearchTerm('');
                  setCategoryFilter('All');
                  setStatusFilter('All');
                }}
                className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Reset Filters
              </button>
            )}
            <button
              type="button"
              onClick={onAddProduct}
              className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
            >
              Add Product
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Desktop High-Density Table */}
          <div className="hidden lg:block overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <tr>
                  <th className="px-4 py-3">Product</th>
                  <th className="px-3 py-3">Category · Supplier</th>
                  <th className="px-3 py-3 text-right">Cost</th>
                  <th className="px-3 py-3 text-right">Selling</th>
                  <th className="px-3 py-3 text-right">Stock</th>
                  <th className="px-3 py-3">Status</th>
                  <th className="px-3 py-3">Quick Stock In / Out</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-2.5">
                      <button
                        type="button"
                        onClick={() => onSelectProduct(p)}
                        className="text-left group"
                      >
                        <p className="font-medium text-slate-900 group-hover:text-emerald-700">
                          {p.name}
                        </p>
                        <p className="font-mono text-xs text-slate-500">
                          {p.sku}
                          {p.barcode ? ` · ${p.barcode}` : ''}
                          {p.expiry_date ? ` · Exp ${formatDate(p.expiry_date)}` : ''}
                        </p>
                      </button>
                    </td>
                    <td className="px-3 py-2.5 text-xs text-slate-600">
                      <p className="font-medium text-slate-800">{p.category}</p>
                      <p className="truncate max-w-[180px] text-slate-500">
                        {p.supplier_name || 'No supplier'}
                      </p>
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-xs text-slate-700 tabular-nums">
                      {formatINR(p.cost_price)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-xs font-semibold text-slate-900 tabular-nums">
                      {formatINR(p.selling_price)}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                        {p.current_quantity}
                      </span>{' '}
                      <span className="text-xs text-slate-500">{p.unit}</span>
                      <p className="font-mono text-[11px] text-slate-400 tabular-nums">
                        Min {p.minimum_stock_threshold}
                      </p>
                    </td>
                    <td className="px-3 py-2.5">
                      <StockStatusBadge status={p.stock_status} />
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          disabled={p.current_quantity <= 0}
                          onClick={() =>
                            void onQuickAdjust(p, -1, 'Sale', 'Quick counter sale (-1)')
                          }
                          title="Decrease stock by 1"
                          className="h-8 rounded-md border border-slate-200 bg-white px-2.5 font-mono text-xs font-semibold text-slate-700 hover:border-red-200 hover:bg-red-50 hover:text-red-700 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          -1
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            void onQuickAdjust(p, 1, 'Manual correction', 'Quick increment (+1)')
                          }
                          title="Increase stock by 1"
                          className="h-8 rounded-md border border-slate-200 bg-white px-2.5 font-mono text-xs font-semibold text-slate-700 hover:border-emerald-200 hover:bg-emerald-50 hover:text-emerald-700"
                        >
                          +1
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            void onQuickAdjust(p, 10, 'Supplier delivery', 'Quick restock (+10)')
                          }
                          title="Increase stock by 10"
                          className="h-8 rounded-md border border-slate-200 bg-white px-2.5 font-mono text-xs font-semibold text-slate-700 hover:border-emerald-200 hover:bg-emerald-50 hover:text-emerald-700"
                        >
                          +10
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenCustomAdjust(p)}
                          title="Custom quantity adjustment"
                          className="inline-flex h-8 items-center gap-1 rounded-md bg-slate-900 px-2.5 text-xs font-medium text-white hover:bg-slate-800"
                        >
                          <SlidersHorizontal className="h-3 w-3" />
                          Adjust
                        </button>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onSelectProduct(p)}
                          title="View product details & ledger"
                          className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onEditProduct(p)}
                          title="Edit product"
                          className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
                        >
                          <Edit3 className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteProduct(p)}
                          title="Delete product"
                          className="rounded-md p-1.5 text-slate-500 hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile & Tablet Touch-Friendly Cards (320px+) */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:hidden">
            {filteredProducts.map((p) => (
              <div
                key={p.id}
                className="rounded-xl border border-slate-200 bg-white p-4 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => onSelectProduct(p)}
                    className="min-w-0 text-left"
                  >
                    <p className="font-semibold text-slate-900">{p.name}</p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      <span className="font-mono">{p.sku}</span> · {p.category}
                    </p>
                  </button>
                  <StockStatusBadge status={p.stock_status} />
                </div>

                <div className="flex items-center justify-between text-xs text-slate-600">
                  <div>
                    <span className="text-slate-500">Stock: </span>
                    <strong className="font-mono text-base text-slate-900 tabular-nums">
                      {p.current_quantity}
                    </strong>{' '}
                    <span>{p.unit}</span>
                    <span className="text-slate-400"> (Min {p.minimum_stock_threshold})</span>
                  </div>
                  <div className="font-mono tabular-nums text-right">
                    <span className="text-slate-500">Cost {formatINR(p.cost_price)}</span>
                    <span className="mx-1">·</span>
                    <strong className="text-slate-900">{formatINR(p.selling_price)}</strong>
                  </div>
                </div>

                {/* One-handed 44px touch controls */}
                <div className="grid grid-cols-4 gap-2 pt-1">
                  <button
                    type="button"
                    disabled={p.current_quantity <= 0}
                    onClick={() =>
                      void onQuickAdjust(p, -1, 'Sale', 'Mobile quick sale (-1)')
                    }
                    className="flex h-11 items-center justify-center gap-0.5 rounded-lg border border-slate-200 bg-slate-50 font-mono text-xs font-bold text-slate-800 active:bg-red-50 disabled:opacity-40"
                  >
                    <Minus className="h-3.5 w-3.5" />1
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      void onQuickAdjust(p, 1, 'Manual correction', 'Mobile quick add (+1)')
                    }
                    className="flex h-11 items-center justify-center gap-0.5 rounded-lg border border-slate-200 bg-slate-50 font-mono text-xs font-bold text-slate-800 active:bg-emerald-50"
                  >
                    <Plus className="h-3.5 w-3.5" />1
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      void onQuickAdjust(p, 10, 'Supplier delivery', 'Mobile quick restock (+10)')
                    }
                    className="flex h-11 items-center justify-center gap-0.5 rounded-lg border border-slate-200 bg-slate-50 font-mono text-xs font-bold text-slate-800 active:bg-emerald-50"
                  >
                    <Plus className="h-3.5 w-3.5" />10
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenCustomAdjust(p)}
                    className="flex h-11 items-center justify-center rounded-lg bg-slate-900 text-xs font-semibold text-white"
                  >
                    Custom
                  </button>
                </div>

                <div className="flex items-center justify-between border-t border-slate-100 pt-2.5 text-xs">
                  <button
                    type="button"
                    onClick={() => onSelectProduct(p)}
                    className="font-medium text-emerald-700"
                  >
                    Details & History
                  </button>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => onEditProduct(p)}
                      className="font-medium text-slate-600"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteProduct(p)}
                      className="font-medium text-red-600"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </motion.div>
  );
}
