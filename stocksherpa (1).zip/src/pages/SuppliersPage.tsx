import {
  Building2,
  Edit3,
  Mail,
  MapPin,
  Phone,
  Plus,
  Search,
  Trash2,
  User,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import { PurchaseOrderStatusBadge } from '../components/StatusBadge.tsx';
import { useDebounce } from '../hooks/useDebounce.ts';
import { api } from '../services/api.ts';
import type { PurchaseOrder, Supplier } from '../types/inventory.ts';
import { formatDate, formatINR } from '../utils/format.ts';

interface SuppliersPageProps {
  suppliers: Supplier[];
  loading: boolean;
  saving: boolean;
  onCreateSupplier: (payload: {
    name: string;
    contact_person: string;
    phone: string;
    email: string | null;
    address: string | null;
  }) => Promise<void>;
  onUpdateSupplier: (
    id: number,
    payload: {
      name: string;
      contact_person: string;
      phone: string;
      email: string | null;
      address: string | null;
    }
  ) => Promise<void>;
  onDeleteSupplier: (supplier: Supplier) => void;
  onOpenOrder: (order: PurchaseOrder) => void;
}

export function SuppliersPage({
  suppliers,
  loading,
  saving,
  onCreateSupplier,
  onUpdateSupplier,
  onDeleteSupplier,
  onOpenOrder,
}: SuppliersPageProps) {
  const [search, setSearch] = useState('');
  const debounced = useDebounce(search, 180);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [detailSupplier, setDetailSupplier] = useState<Supplier | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);

  // Form fields
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [formError, setFormError] = useState('');

  const filtered = useMemo(() => {
    const q = debounced.trim().toLowerCase();
    if (!q) return suppliers;
    return suppliers.filter((s) =>
      `${s.name} ${s.contact_person} ${s.phone} ${s.email || ''}`.toLowerCase().includes(q)
    );
  }, [suppliers, debounced]);

  const openNew = () => {
    setEditing(null);
    setName('');
    setContact('');
    setPhone('');
    setEmail('');
    setAddress('');
    setFormError('');
    setModalOpen(true);
  };

  const openEdit = (sup: Supplier) => {
    setEditing(sup);
    setName(sup.name);
    setContact(sup.contact_person);
    setPhone(sup.phone);
    setEmail(sup.email || '');
    setAddress(sup.address || '');
    setFormError('');
    setModalOpen(true);
  };

  const openDetail = (sup: Supplier) => {
    setDetailSupplier(sup);
    setLoadingDetail(true);
    api
      .getSupplier(sup.id)
      .then((full) => setDetailSupplier(full))
      .catch(() => {})
      .finally(() => setLoadingDetail(false));
  };

  useEffect(() => {
    if (!detailSupplier) return;
    const updated = suppliers.find((s) => s.id === detailSupplier.id);
    if (updated) {
      setDetailSupplier((prev) => (prev ? { ...prev, ...updated } : updated));
    }
  }, [suppliers, detailSupplier?.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!name.trim() || !contact.trim()) {
      setFormError('Supplier name and contact person are required.');
      return;
    }
    if (!/^[+\d][\d\s-]{6,22}$/.test(phone.trim())) {
      setFormError('Enter a valid phone number (e.g., +91 98204 55120).');
      return;
    }
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setFormError('Enter a valid email address.');
      return;
    }

    try {
      const payload = {
        name: name.trim(),
        contact_person: contact.trim(),
        phone: phone.trim(),
        email: email.trim() || null,
        address: address.trim() || null,
      };
      if (editing) {
        await onUpdateSupplier(editing.id, payload);
      } else {
        await onCreateSupplier(payload);
      }
      setModalOpen(false);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to save supplier.');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-5"
    >
      {/* Toolbar */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search suppliers by name, contact person, or phone..."
            className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
          />
        </div>
        <button
          type="button"
          onClick={openNew}
          className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700 whitespace-nowrap"
        >
          <Plus className="h-4 w-4" />
          Add Supplier
        </button>
      </div>

      {loading && suppliers.length === 0 ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-36 animate-pulse rounded-xl border border-slate-200 bg-white" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <Building2 className="mx-auto h-9 w-9 text-slate-400" />
          <h3 className="mt-3 font-display text-base font-bold text-slate-900">
            No suppliers found
          </h3>
          <p className="mt-1 text-sm text-slate-500">
            Add wholesale distributors so you can generate purchase orders and WhatsApp dispatches.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((sup) => (
            <div
              key={sup.id}
              className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => openDetail(sup)}
                    className="text-left group"
                  >
                    <h3 className="font-display text-base font-bold text-slate-900 group-hover:text-emerald-700">
                      {sup.name}
                    </h3>
                  </button>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => openEdit(sup)}
                      title="Edit supplier"
                      className="rounded p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteSupplier(sup)}
                      title="Delete supplier"
                      className="rounded p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <div className="mt-3 space-y-1.5 text-xs text-slate-600">
                  <p className="flex items-center gap-2">
                    <User className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span>{sup.contact_person}</span>
                  </p>
                  <p className="flex items-center gap-2 font-mono">
                    <Phone className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span>{sup.phone}</span>
                  </p>
                  {sup.email && (
                    <p className="flex items-center gap-2 truncate">
                      <Mail className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{sup.email}</span>
                    </p>
                  )}
                  {sup.address && (
                    <p className="flex items-start gap-2">
                      <MapPin className="mt-0.5 h-3.5 w-3.5 text-slate-400 shrink-0" />
                      <span>{sup.address}</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 text-xs">
                <span className="font-mono text-slate-600 tabular-nums">
                  {sup.product_count || 0} products · {sup.outstanding_orders || 0} open POs
                </span>
                <button
                  type="button"
                  onClick={() => openDetail(sup)}
                  className="font-semibold text-emerald-700 hover:underline"
                >
                  View History
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-[75] flex items-center justify-center bg-slate-950/50 p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
              <h2 className="font-display text-base font-bold text-slate-900">
                {editing ? 'Edit Supplier' : 'Add Supplier'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {formError && (
                <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
                  {formError}
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-slate-700">Supplier Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700">Contact Person *</label>
                <input
                  type="text"
                  required
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700">Phone Number *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98204 55120"
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="orders@supplier.in"
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700">Address</label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Supplier'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Supplier Detail Drawer */}
      {detailSupplier && (
        <div className="fixed inset-0 z-[70] flex justify-end bg-slate-950/40">
          <div className="fixed inset-0" onClick={() => setDetailSupplier(null)} aria-hidden="true" />
          <div className="relative z-10 flex h-full w-full max-w-lg flex-col border-l border-slate-200 bg-white shadow-2xl">
            <div className="flex items-start justify-between border-b border-slate-200 px-6 py-4">
              <div>
                <h2 className="font-display text-lg font-bold text-slate-900">
                  {detailSupplier.name}
                </h2>
                <p className="text-xs text-slate-500">
                  {detailSupplier.contact_person} · {detailSupplier.phone}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDetailSupplier(null)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {loadingDetail ? (
                <div className="h-32 animate-pulse rounded-xl bg-slate-100" />
              ) : (
                <>
                  <div>
                    <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Supplied Products ({detailSupplier.products?.length || 0})
                    </h3>
                    <div className="divide-y divide-slate-100 rounded-lg border border-slate-200">
                      {(detailSupplier.products || []).length === 0 ? (
                        <p className="p-4 text-xs text-slate-500">No products assigned yet.</p>
                      ) : (
                        detailSupplier.products?.map((p) => (
                          <div
                            key={p.id}
                            className="flex items-center justify-between px-4 py-2.5 text-xs"
                          >
                            <div>
                              <p className="font-medium text-slate-900">{p.name}</p>
                              <p className="font-mono text-slate-500">{p.sku}</p>
                            </div>
                            <div className="text-right font-mono tabular-nums">
                              <p className="font-semibold text-slate-900">
                                {p.current_quantity} {p.unit}
                              </p>
                              <p className="text-slate-500">{formatINR(p.cost_price)}</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  <div>
                    <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Purchase History ({detailSupplier.purchase_orders?.length || 0})
                    </h3>
                    <div className="space-y-2">
                      {(detailSupplier.purchase_orders || []).length === 0 ? (
                        <p className="rounded-lg border border-slate-200 p-4 text-xs text-slate-500">
                          No purchase orders placed with this supplier yet.
                        </p>
                      ) : (
                        detailSupplier.purchase_orders?.map((po) => (
                          <button
                            key={po.id}
                            type="button"
                            onClick={() => {
                              setDetailSupplier(null);
                              onOpenOrder(po);
                            }}
                            className="flex w-full items-center justify-between rounded-lg border border-slate-200 px-4 py-3 text-left text-xs hover:bg-slate-50"
                          >
                            <div>
                              <p className="font-mono font-bold text-slate-900">{po.order_number}</p>
                              <p className="text-slate-500">{formatDate(po.order_date)}</p>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="font-mono font-semibold text-slate-900 tabular-nums">
                                {formatINR(po.total_cost)}
                              </span>
                              <PurchaseOrderStatusBadge status={po.status} />
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
