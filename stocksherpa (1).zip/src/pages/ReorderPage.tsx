import {
  CheckCircle2,
  ClipboardList,
  FileText,
  MessageSquare,
  ShoppingCart,
  Trash2,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import { PurchaseOrderStatusBadge, StockStatusBadge } from '../components/StatusBadge.tsx';
import type { PurchaseOrder, ReorderSuggestion, Supplier } from '../types/inventory.ts';
import { formatDate, formatINR } from '../utils/format.ts';

interface ReorderPageProps {
  suggestions: ReorderSuggestion[];
  purchaseOrders: PurchaseOrder[];
  suppliers: Supplier[];
  loading: boolean;
  saving: boolean;
  onGeneratePO: (payload: {
    supplier_id: number;
    status: 'Draft' | 'Pending' | 'Sent';
    notes?: string;
    items: Array<{ product_id: number; quantity_ordered: number; unit_cost: number }>;
    openWhatsApp?: boolean;
  }) => Promise<PurchaseOrder | void>;
  onOpenOrder: (order: PurchaseOrder, showWhatsApp?: boolean) => void;
}

interface EditableSuggestion extends ReorderSuggestion {
  customQty: number;
  selectedSupplierId: number | null;
}

export function ReorderPage({
  suggestions,
  purchaseOrders,
  suppliers,
  loading,
  saving,
  onGeneratePO,
  onOpenOrder,
}: ReorderPageProps) {
  const [activeTab, setActiveTab] = useState<'suggestions' | 'orders'>('suggestions');
  const [poStatusFilter, setPoStatusFilter] = useState<string>('All');
  const [items, setItems] = useState<EditableSuggestion[]>([]);

  useEffect(() => {
    setItems(
      suggestions.map((s) => ({
        ...s,
        customQty: s.recommended_quantity > 0 ? s.recommended_quantity : 10,
        selectedSupplierId: s.supplier_id ?? (suppliers[0]?.id || null),
      }))
    );
  }, [suggestions, suppliers]);

  const groupedBySupplier = useMemo(() => {
    const map = new Map<
      number,
      {
        supplier: Supplier | { id: number; name: string; phone: string; contact_person: string };
        lines: EditableSuggestion[];
        totalCost: number;
      }
    >();

    for (const item of items) {
      if (!item.selectedSupplierId) continue;
      const sup = suppliers.find((s) => s.id === item.selectedSupplierId) || {
        id: item.selectedSupplierId,
        name: item.supplier_name || 'Assigned Supplier',
        phone: item.supplier_phone || '',
        contact_person: '',
      };

      const entry = map.get(sup.id) || { supplier: sup, lines: [], totalCost: 0 };
      entry.lines.push(item);
      entry.totalCost += item.customQty * item.cost_price;
      map.set(sup.id, entry);
    }
    return Array.from(map.values());
  }, [items, suppliers]);

  const filteredOrders = useMemo(() => {
    if (poStatusFilter === 'All') return purchaseOrders;
    return purchaseOrders.filter((po) => po.status === poStatusFilter);
  }, [purchaseOrders, poStatusFilter]);

  const updateLineQty = (productId: number, qty: number) => {
    setItems((prev) =>
      prev.map((i) => (i.product_id === productId ? { ...i, customQty: Math.max(1, qty) } : i))
    );
  };

  const updateLineSupplier = (productId: number, supId: number) => {
    setItems((prev) =>
      prev.map((i) => (i.product_id === productId ? { ...i, selectedSupplierId: supId } : i))
    );
  };

  const removeLine = (productId: number) => {
    setItems((prev) => prev.filter((i) => i.product_id !== productId));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-5"
    >
      {/* Tab Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-5 py-3.5">
        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setActiveTab('suggestions')}
            className={`inline-flex items-center gap-2 rounded-md px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'suggestions'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShoppingCart className="h-3.5 w-3.5" />
            Reorder Suggestions ({items.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('orders')}
            className={`inline-flex items-center gap-2 rounded-md px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'orders'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ClipboardList className="h-3.5 w-3.5" />
            Purchase Orders ({purchaseOrders.length})
          </button>
        </div>

        <p className="text-xs text-slate-500">
          Consolidated by supplier · Formula: Target stock level − Current stock
        </p>
      </div>

      {activeTab === 'suggestions' ? (
        loading && items.length === 0 ? (
          <div className="h-48 animate-pulse rounded-xl border border-slate-200 bg-white" />
        ) : items.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
            <CheckCircle2 className="mx-auto h-9 w-9 text-emerald-600" />
            <h3 className="mt-3 font-display text-base font-bold text-slate-900">
              No immediate reorders needed
            </h3>
            <p className="mt-1 text-sm text-slate-500">
              All products are currently stocked above their minimum threshold levels.
            </p>
          </div>
        ) : (
          <div className="space-y-5">
            {groupedBySupplier.map((group) => (
              <div
                key={group.supplier.id}
                className="overflow-hidden rounded-xl border border-slate-200 bg-white"
              >
                {/* Supplier Batch Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-50 px-5 py-4">
                  <div>
                    <h3 className="font-display text-base font-bold text-slate-900">
                      {group.supplier.name}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {group.lines.length} product{group.lines.length === 1 ? '' : 's'} below
                      threshold · Est. Order Total:{' '}
                      <strong className="font-mono text-slate-900 tabular-nums">
                        {formatINR(group.totalCost)}
                      </strong>
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      disabled={saving}
                      onClick={() =>
                        void onGeneratePO({
                          supplier_id: group.supplier.id,
                          status: 'Pending',
                          notes: 'Generated from StockSherpa Reorder Assistant',
                          items: group.lines.map((l) => ({
                            product_id: l.product_id,
                            quantity_ordered: l.customQty,
                            unit_cost: l.cost_price,
                          })),
                          openWhatsApp: false,
                        }).then((po) => {
                          if (po) setActiveTab('orders');
                        })
                      }
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-100 disabled:opacity-50"
                    >
                      <FileText className="h-3.5 w-3.5" />
                      Generate Purchase Order
                    </button>

                    <button
                      type="button"
                      disabled={saving}
                      onClick={() =>
                        void onGeneratePO({
                          supplier_id: group.supplier.id,
                          status: 'Pending',
                          notes: 'Dispatched via StockSherpa WhatsApp Order',
                          items: group.lines.map((l) => ({
                            product_id: l.product_id,
                            quantity_ordered: l.customQty,
                            unit_cost: l.cost_price,
                          })),
                          openWhatsApp: true,
                        })
                      }
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                    >
                      <MessageSquare className="h-3.5 w-3.5" />
                      Generate WhatsApp Order
                    </button>
                  </div>
                </div>

                {/* Items Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs sm:text-sm">
                    <thead className="border-b border-slate-200 text-xs font-semibold text-slate-600">
                      <tr>
                        <th className="px-5 py-2.5">Product</th>
                        <th className="px-3 py-2.5 text-right">Current / Min</th>
                        <th className="px-3 py-2.5">Status</th>
                        <th className="px-3 py-2.5">Supplier</th>
                        <th className="px-3 py-2.5 text-right">Reorder Qty</th>
                        <th className="px-3 py-2.5 text-right">Est. Cost</th>
                        <th className="px-4 py-2.5 text-right">Remove</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {group.lines.map((line) => (
                        <tr key={line.product_id}>
                          <td className="px-5 py-3">
                            <p className="font-medium text-slate-900">{line.product_name}</p>
                            <p className="font-mono text-xs text-slate-500">
                              {line.sku} · Cost {formatINR(line.cost_price)}/{line.unit}
                            </p>
                          </td>
                          <td className="px-3 py-3 text-right font-mono tabular-nums">
                            <span className="font-bold text-slate-900">{line.current_quantity}</span>
                            <span className="text-slate-400"> / {line.minimum_stock_threshold}</span>
                          </td>
                          <td className="px-3 py-3">
                            <StockStatusBadge status={line.stock_status} />
                          </td>
                          <td className="px-3 py-3">
                            <select
                              value={line.selectedSupplierId || ''}
                              onChange={(e) =>
                                updateLineSupplier(line.product_id, Number(e.target.value))
                              }
                              className="max-w-[190px] rounded-md border border-slate-300 bg-white px-2 py-1 text-xs text-slate-800"
                            >
                              {suppliers.map((s) => (
                                <option key={s.id} value={s.id}>
                                  {s.name}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="px-3 py-3 text-right">
                            <input
                              type="number"
                              min="1"
                              value={line.customQty}
                              onChange={(e) =>
                                updateLineQty(line.product_id, Number(e.target.value) || 1)
                              }
                              className="w-20 rounded-md border border-slate-300 px-2 py-1 text-right font-mono text-xs font-bold text-slate-900 tabular-nums"
                            />
                          </td>
                          <td className="px-3 py-3 text-right font-mono font-semibold text-slate-900 tabular-nums">
                            {formatINR(line.customQty * line.cost_price)}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <button
                              type="button"
                              onClick={() => removeLine(line.product_id)}
                              title="Exclude from this purchase order"
                              className="rounded p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        /* Purchase Orders List */
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-5 py-3">
            <div className="flex flex-wrap items-center gap-1.5">
              {['All', 'Draft', 'Pending', 'Sent', 'Partially Received', 'Received', 'Cancelled'].map(
                (st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setPoStatusFilter(st)}
                    className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                      poStatusFilter === st
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {st}
                  </button>
                )
              )}
            </div>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-500">
              No purchase orders match the selected status.
            </div>
          ) : (
            <div className="space-y-3">
              {filteredOrders.map((po) => (
                <div
                  key={po.id}
                  className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className="font-mono text-sm font-bold text-slate-900">
                        {po.order_number}
                      </span>
                      <PurchaseOrderStatusBadge status={po.status} />
                    </div>
                    <p className="mt-1 text-xs text-slate-600">
                      Supplier: <strong className="text-slate-900">{po.supplier_name}</strong> ·{' '}
                      {(po.items || []).length} line items · {formatDate(po.order_date)}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <div className="text-right">
                      <p className="text-[11px] text-slate-500">Grand Total</p>
                      <p className="font-mono text-base font-bold text-slate-900 tabular-nums">
                        {formatINR(po.total_cost)}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onOpenOrder(po, true)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-600 bg-white px-3 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-50"
                    >
                      <MessageSquare className="h-3.5 w-3.5" />
                      WhatsApp
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenOrder(po, false)}
                      className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                    >
                      Manage Order
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
