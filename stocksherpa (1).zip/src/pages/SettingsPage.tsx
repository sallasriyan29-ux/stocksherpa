import { RotateCcw, Save } from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { PWAInstallButton } from '../components/PWAInstallButton.tsx';
import type { StoreSettings } from '../types/inventory.ts';

interface SettingsPageProps {
  settings: StoreSettings | null;
  saving: boolean;
  onSaveSettings: (payload: Partial<StoreSettings>) => Promise<void>;
  onRequestResetDemo: () => void;
}

export function SettingsPage({
  settings,
  saving,
  onSaveSettings,
  onRequestResetDemo,
}: SettingsPageProps) {
  const [storeName, setStoreName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [storePhone, setStorePhone] = useState('');
  const [storeAddress, setStoreAddress] = useState('');

  useEffect(() => {
    if (!settings) return;
    setStoreName(settings.store_name || '');
    setOwnerName(settings.owner_name || '');
    setStorePhone(settings.store_phone || '');
    setStoreAddress(settings.store_address || '');
  }, [settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveSettings({
      store_name: storeName.trim(),
      owner_name: ownerName.trim(),
      store_phone: storePhone.trim(),
      store_address: storeAddress.trim(),
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="mx-auto max-w-3xl space-y-6"
    >
      {/* Store Profile */}
      <form
        onSubmit={handleSubmit}
        className="rounded-xl border border-slate-200 bg-white p-6 space-y-4"
      >
        <div>
          <h2 className="font-display text-base font-bold text-slate-900">
            Store Profile & Purchase Order Header
          </h2>
          <p className="text-xs text-slate-500">
            Used on generated supplier purchase orders and WhatsApp order messages
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700">Store Name</label>
            <input
              type="text"
              required
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700">Owner / Manager</label>
            <input
              type="text"
              required
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700">Store Phone</label>
            <input
              type="text"
              value={storePhone}
              onChange={(e) => setStorePhone(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700">Store Address</label>
            <input
              type="text"
              value={storeAddress}
              onChange={(e) => setStoreAddress(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
        </div>

        <div className="flex justify-end border-t border-slate-100 pt-4">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            <Save className="h-3.5 w-3.5" />
            {saving ? 'Saving...' : 'Save Store Settings'}
          </button>
        </div>
      </form>

      {/* PWA Install & Demo Data Management */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-base font-bold text-slate-900">
              Progressive Web App & Sample Dataset
            </h2>
            <p className="text-xs text-slate-500">
              Install StockSherpa on mobile/desktop or restore the 60-product kirana demo dataset
            </p>
          </div>
          <PWAInstallButton />
        </div>

        <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-slate-900">
              Restore 60 Sample Kirana Products
            </p>
            <p className="mt-0.5 text-xs text-slate-600">
              Resets SQLite inventory, suppliers, and purchase orders to the clean 60-product
              demonstration state (including Atta at quantity 6).
            </p>
          </div>
          <button
            type="button"
            onClick={onRequestResetDemo}
            className="inline-flex items-center gap-1.5 rounded-lg border border-amber-300 bg-white px-4 py-2 text-xs font-semibold text-amber-800 hover:bg-amber-50 whitespace-nowrap"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset Demo Dataset
          </button>
        </div>
      </div>
    </motion.div>
  );
}
