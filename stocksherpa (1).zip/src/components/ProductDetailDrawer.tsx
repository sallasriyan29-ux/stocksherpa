import { Edit3, History, Minus, Plus, Trash2, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { api } from '../services/api.ts';
import type { MovementType, Product, StockMovement } from '../types/inventory.ts';
import { formatDate, formatDateTime, formatINR } from '../utils/format.ts';
import { ExpiryStatusBadge, StockStatusBadge } from './StatusBadge.tsx';

interface ProductDetailDrawerProps {
  product: Product | null;
  onClose: () => void;
  onEdit: (product: Product) => void;
  onDelete: (product: Product) => void;
  onQuickAdjust: (
    product: Product,
    delta: number,
    type: MovementType,
    reason: string
  ) => Promise<void>;
  onOpenCustomAdjust: (product: Product) => void;
}

export function ProductDetailDrawer({
  product,
  onClose,
  onEdit,
  onDelete,
  onQuickAdjust,
  onOpenCustomAdjust,
}: ProductDetailDrawerProps) {
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [loadingMovements, setLoadingMovements] = useState(false);

  useEffect(() => {
    if (!product) return;
    let active = true;
    setLoadingMovements(true);
    api
      .listProductMovements(product.id)
      .then((data) => {
        if (active) setMovements(data);
      })
      .catch(() => {
        if (active) setMovements([]);
      })
      .finally(() => {
        if (active) setLoadingMovements(false);
      });
    return () => {
      active = false;
    };
  }, [product]);

  if (!product) return null;

  const unitProfit = product.selling_price - product.cost_price;
  const totalCostVal = product.current_quantity * product.cost_price;
  const totalRetailVal = product.current_quantity * product.selling_price;

  return (
    <div className="fixed inset-0 z-[65] flex justify-end bg-slate-950/40">
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />
      <div className="relative z-10 flex h-full w-full max-w-lg flex-col border-l border-slate-200 bg-white shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-200 px-6 py-4">
          <div className="min-w-0 pr-4">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span className="font-mono">{product.sku}</span>
              <span aria-hidden="true">·</span>
              <span>{product.category}</span>
              {product.barcode && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{product.barcode}</span>
                </>
              )}
            </div>
            <h2 className="mt-1 font-display text-lg font-bold text-slate-900">
              {product.name}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
            aria-label="Close drawer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Status & Quick Adjust */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <StockStatusBadge status={product.stock_status} />
              <ExpiryStatusBadge status={product.expiry_status} />
            </div>

            <div className="flex items-baseline justify-between">
              <div>
                <p className="text-xs text-slate-500">Current Stock</p>
                <p className="font-mono text-3xl font-bold text-slate-900 tabular-nums">
                  {product.current_quantity}{' '}
                  <span className="text-sm font-normal text-slate-500">{product.unit}</span>
                </p>
              </div>
              <div className="text-right text-xs text-slate-600 space-y-0.5">
                <p>
                  Min Threshold:{' '}
                  <strong className="font-mono tabular-nums">{product.minimum_stock_threshold}</strong>
                </p>
                <p>
                  Target Level:{' '}
                  <strong className="font-mono tabular-nums">{product.target_stock_level}</strong>
                </p>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2">
              <button
                type="button"
                disabled={product.current_quantity <= 0}
                onClick={() => void onQuickAdjust(product, -1, 'Sale', 'Quick counter sale (-1)')}
                className="flex h-10 items-center justify-center gap-1 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-800 hover:bg-red-50 hover:border-red-200 hover:text-red-700 disabled:opacity-40"
              >
                <Minus className="h-3.5 w-3.5" />1
              </button>
              <button
                type="button"
                onClick={() =>
                  void onQuickAdjust(product, 1, 'Manual correction', 'Quick stock increment (+1)')
                }
                className="flex h-10 items-center justify-center gap-1 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-800 hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700"
              >
                <Plus className="h-3.5 w-3.5" />1
              </button>
              <button
                type="button"
                onClick={() =>
                  void onQuickAdjust(product, 10, 'Supplier delivery', 'Quick bulk restock (+10)')
                }
                className="flex h-10 items-center justify-center gap-1 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-800 hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700"
              >
                <Plus className="h-3.5 w-3.5" />10
              </button>
              <button
                type="button"
                onClick={() => onOpenCustomAdjust(product)}
                className="flex h-10 items-center justify-center rounded-lg bg-slate-900 text-xs font-semibold text-white hover:bg-slate-800"
              >
                Custom
              </button>
            </div>
          </div>

          {/* Pricing & Valuation */}
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs text-slate-500">Cost Price</p>
              <p className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums">
                {formatINR(product.cost_price)}
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs text-slate-500">Selling Price</p>
              <p className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums">
                {formatINR(product.selling_price)}
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs text-slate-500">Stock Value (Cost)</p>
              <p className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums">
                {formatINR(totalCostVal)}
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs text-slate-500">Expected Retail / Unit Profit</p>
              <p className="mt-0.5 font-mono font-semibold text-emerald-700 tabular-nums">
                {formatINR(totalRetailVal)} · +{formatINR(unitProfit)}
              </p>
            </div>
          </div>

          {/* Supplier & Expiry Metadata */}
          <div className="space-y-2 border-t border-slate-200 pt-4 text-xs text-slate-600">
            <div className="flex justify-between">
              <span>Preferred Supplier</span>
              <span className="font-medium text-slate-900">{product.supplier_name || 'Unassigned'}</span>
            </div>
            <div className="flex justify-between">
              <span>Expiry Date</span>
              <span className="font-mono text-slate-900">{formatDate(product.expiry_date)}</span>
            </div>
            <div className="flex justify-between">
              <span>Last Updated</span>
              <span className="font-mono text-slate-900">{formatDateTime(product.updated_at)}</span>
            </div>
          </div>

          {/* Stock Movement History */}
          <div className="border-t border-slate-200 pt-4">
            <div className="mb-3 flex items-center gap-2">
              <History className="h-4 w-4 text-slate-500" />
              <h3 className="text-sm font-semibold text-slate-900">Recent Stock Movements</h3>
            </div>
            {loadingMovements ? (
              <div className="space-y-2">
                <div className="h-12 animate-pulse rounded-lg bg-slate-100" />
                <div className="h-12 animate-pulse rounded-lg bg-slate-100" />
              </div>
            ) : movements.length === 0 ? (
              <p className="text-xs text-slate-500">No stock movements recorded yet.</p>
            ) : (
              <div className="space-y-2">
                {movements.slice(0, 12).map((m) => (
                  <div
                    key={m.id}
                    className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-xs"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="font-medium text-slate-900 truncate">{m.movement_type}</p>
                      <p className="text-slate-500 truncate">
                        {m.reason} · {formatDateTime(m.created_at)}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p
                        className={`font-mono font-bold tabular-nums ${
                          m.quantity_changed > 0 ? 'text-emerald-700' : 'text-red-600'
                        }`}
                      >
                        {m.quantity_changed > 0 ? `+${m.quantity_changed}` : m.quantity_changed}
                      </p>
                      <p className="font-mono text-[11px] text-slate-500 tabular-nums">
                        {m.previous_quantity} → {m.new_quantity}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between border-t border-slate-200 px-6 py-4">
          <button
            type="button"
            onClick={() => onDelete(product)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-white px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50"
          >
            <Trash2 className="h-3.5 w-3.5" />
            Delete
          </button>
          <button
            type="button"
            onClick={() => onEdit(product)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
          >
            <Edit3 className="h-3.5 w-3.5" />
            Edit Product
          </button>
        </div>
      </div>
    </div>
  );
}
