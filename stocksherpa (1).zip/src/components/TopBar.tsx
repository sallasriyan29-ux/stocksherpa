import { Menu, Plus, ScanBarcode } from 'lucide-react';
import type { SyncState } from '../hooks/useOnlineStatus.ts';
import type { QueuedStockOperation } from '../services/offlineQueue.ts';
import type { AppPage } from '../types/inventory.ts';
import { PWAInstallButton } from './PWAInstallButton.tsx';
import { SyncStatusBar } from './SyncStatusBar.tsx';

interface TopBarProps {
  currentPage: AppPage;
  onOpenMobileMenu: () => void;
  onOpenScanner: () => void;
  onAddProduct: () => void;
  isOnline: boolean;
  syncState: SyncState;
  queue: QueuedStockOperation[];
  onSyncNow: (forceOperationId?: string) => Promise<{ synced: number; conflicts: number; failed: number }>;
  onDiscardOp: (operationId: string) => void;
}

const pageTitles: Record<AppPage, string> = {
  dashboard: 'Store Overview',
  catalog: 'Product Catalog & Stock Ledger',
  reorder: 'Smart Reorder Assistant',
  expiry: 'Perishable Expiry Tracker',
  suppliers: 'Supplier Directory',
  movements: 'Stock Movement History',
  settings: 'Store Settings & Offline Sync',
};

export function TopBar({
  currentPage,
  onOpenMobileMenu,
  onOpenScanner,
  onAddProduct,
  isOnline,
  syncState,
  queue,
  onSyncNow,
  onDiscardOp,
}: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 flex h-14 sm:h-16 items-center justify-between gap-3 border-b border-slate-200 bg-white px-4 sm:px-6 no-print">
      {/* Left: mobile menu + contextual title */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 lg:hidden shrink-0"
          aria-label="Open menu"
        >
          <Menu className="h-5 w-5" />
        </button>
        <div className="min-w-0">
          <h1 className="font-display truncate text-base sm:text-lg font-bold text-slate-900">
            {pageTitles[currentPage]}
          </h1>
        </div>
      </div>

      {/* Right: utility controls & primary action */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        <SyncStatusBar
          isOnline={isOnline}
          syncState={syncState}
          queue={queue}
          onSyncNow={onSyncNow}
          onDiscard={onDiscardOp}
        />

        <div className="hidden md:block">
          <PWAInstallButton />
        </div>

        <button
          type="button"
          onClick={onOpenScanner}
          className="inline-flex h-10 sm:h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
          title="Scan product barcode"
        >
          <ScanBarcode className="h-4 w-4 text-slate-700" />
          <span className="hidden sm:inline">Scan Barcode</span>
        </button>

        <button
          type="button"
          onClick={onAddProduct}
          className="inline-flex h-10 sm:h-9 items-center gap-1.5 rounded-lg bg-emerald-600 px-3 sm:px-4 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Add Product</span>
        </button>
      </div>
    </header>
  );
}
