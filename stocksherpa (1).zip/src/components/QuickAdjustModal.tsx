import { Minus, Plus, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { MovementType, Product } from '../types/inventory.ts';

interface QuickAdjustModalProps {
  open: boolean;
  product: Product | null;
  saving: boolean;
  onClose: () => void;
  onSubmit: (
    product: Product,
    quantityChanged: number,
    movementType: MovementType,
    reason: string
  ) => Promise<void>;
}

const MOVEMENT_TYPES: MovementType[] = [
  'Sale',
  'Supplier delivery',
  'Manual correction',
  'Damaged goods',
  'Returned goods',
];

export function QuickAdjustModal({
  open,
  product,
  saving,
  onClose,
  onSubmit,
}: QuickAdjustModalProps) {
  const [direction, setDirection] = useState<'in' | 'out'>('out');
  const [amount, setAmount] = useState('1');
  const [movementType, setMovementType] = useState<MovementType>('Sale');
  const [reason, setReason] = useState('Counter sale');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    setDirection('out');
    setAmount('1');
    setMovementType('Sale');
    setReason('Counter sale');
    setError('');
  }, [open, product]);

  if (!open || !product) return null;

  const qtyNum = Number(amount);
  const delta = direction === 'out' ? -Math.abs(qtyNum) : Math.abs(qtyNum);
  const projected = Number.isInteger(qtyNum) && qtyNum > 0 ? product.current_quantity + delta : product.current_quantity;

  const handleTypeChange = (type: MovementType) => {
    setMovementType(type);
    if (type === 'Sale' || type === 'Damaged goods') {
      setDirection('out');
      setReason(type === 'Sale' ? 'Counter sale' : 'Damaged / spoiled stock write-off');
    } else if (type === 'Supplier delivery' || type === 'Returned goods') {
      setDirection('in');
      setReason(type === 'Supplier delivery' ? 'Supplier stock delivery' : 'Customer return to shelf');
    } else {
      setReason('Manual physical stock count adjustment');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!Number.isInteger(qtyNum) || qtyNum <= 0) {
      setError('Enter a positive whole quantity.');
      return;
    }
    if (product.current_quantity + delta < 0) {
      setError(`Cannot deduct ${qtyNum} ${product.unit}; only ${product.current_quantity} in stock.`);
      return;
    }
    if (!reason.trim()) {
      setError('Please enter a brief reason for the stock ledger.');
      return;
    }

    try {
      await onSubmit(product, delta, movementType, reason.trim());
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Stock adjustment failed.');
    }
  };

  return (
    <div className="fixed inset-0 z-[75] flex items-center justify-center bg-slate-950/50 p-4">
      <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <div className="min-w-0">
            <h2 className="font-display text-base font-bold text-slate-900 truncate">
              Adjust Stock: {product.name}
            </h2>
            <p className="text-xs text-slate-500">
              Current Stock:{' '}
              <span className="font-mono font-semibold text-slate-900 tabular-nums">
                {product.current_quantity} {product.unit}
              </span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700">Movement Type</label>
            <select
              value={movementType}
              onChange={(e) => handleTypeChange(e.target.value as MovementType)}
              className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
            >
              {MOVEMENT_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setDirection('out')}
              className={`flex items-center justify-center gap-1.5 rounded-lg border py-2.5 text-xs font-semibold transition-colors ${
                direction === 'out'
                  ? 'border-red-600 bg-red-50 text-red-700'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Minus className="h-3.5 w-3.5" />
              Remove Stock (-)
            </button>
            <button
              type="button"
              onClick={() => setDirection('in')}
              className={`flex items-center justify-center gap-1.5 rounded-lg border py-2.5 text-xs font-semibold transition-colors ${
                direction === 'in'
                  ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Plus className="h-3.5 w-3.5" />
              Add Stock (+)
            </button>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700">
              Quantity ({product.unit})
            </label>
            <input
              type="number"
              min="1"
              step="1"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-base font-semibold text-slate-900 tabular-nums focus:border-emerald-600 focus:outline-none"
            />
            <div className="mt-2 flex flex-wrap gap-1.5">
              {[1, 2, 4, 5, 10, 20].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setAmount(String(preset))}
                  className="rounded border border-slate-200 bg-slate-50 px-2.5 py-1 font-mono text-xs font-medium text-slate-700 hover:bg-slate-100"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700">Reason / Note</label>
            <input
              type="text"
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g., Walk-in sale or Morning delivery"
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs">
            <span className="text-slate-600">Resulting Stock:</span>
            <span
              className={`font-mono font-bold tabular-nums ${
                projected < 0
                  ? 'text-red-600'
                  : projected <= product.minimum_stock_threshold
                    ? 'text-amber-700'
                    : 'text-emerald-700'
              }`}
            >
              {projected} {product.unit}
            </span>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving || projected < 0}
              className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
            >
              {saving ? 'Updating...' : 'Apply Adjustment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
