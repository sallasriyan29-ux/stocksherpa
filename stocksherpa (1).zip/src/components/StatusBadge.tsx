import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  FileText,
  PackageCheck,
  Send,
  XCircle,
} from 'lucide-react';
import type { ExpiryStatus, PurchaseOrderStatus, StockAlertLevel } from '../types/inventory.ts';

export function StockStatusBadge({ status }: { status: StockAlertLevel }) {
  if (status === 'Out of Stock') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-red-50 px-2 py-0.5 text-xs font-semibold text-red-700 whitespace-nowrap">
        <XCircle className="h-3.5 w-3.5 shrink-0" />
        Out of Stock
      </span>
    );
  }
  if (status === 'Low Stock') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-800 whitespace-nowrap">
        <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
        Low Stock
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-xs font-semibold text-emerald-700 whitespace-nowrap">
      <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
      In Stock
    </span>
  );
}

export function ExpiryStatusBadge({ status }: { status: ExpiryStatus }) {
  if (status === 'Expired') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-red-50 px-2 py-0.5 text-xs font-semibold text-red-700 whitespace-nowrap">
        <XCircle className="h-3.5 w-3.5 shrink-0" />
        Expired
      </span>
    );
  }
  if (status === 'Critical') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-red-50 px-2 py-0.5 text-xs font-semibold text-red-700 whitespace-nowrap">
        <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
        Critical
      </span>
    );
  }
  if (status === 'Expiring Soon') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-800 whitespace-nowrap">
        <Clock className="h-3.5 w-3.5 shrink-0" />
        Expiring Soon
      </span>
    );
  }
  if (status === 'Safe') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-xs font-semibold text-emerald-700 whitespace-nowrap">
        <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
        Safe
      </span>
    );
  }
  return <span className="text-xs text-slate-400">No Expiry</span>;
}

export function PurchaseOrderStatusBadge({ status }: { status: PurchaseOrderStatus }) {
  switch (status) {
    case 'Received':
      return (
        <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-xs font-semibold text-emerald-700 whitespace-nowrap">
          <PackageCheck className="h-3.5 w-3.5 shrink-0" />
          Received
        </span>
      );
    case 'Partially Received':
      return (
        <span className="inline-flex items-center gap-1.5 rounded-md border border-sky-200 bg-sky-50 px-2 py-0.5 text-xs font-semibold text-sky-800 whitespace-nowrap">
          <PackageCheck className="h-3.5 w-3.5 shrink-0" />
          Partially Received
        </span>
      );
    case 'Sent':
      return (
        <span className="inline-flex items-center gap-1.5 rounded-md border border-indigo-200 bg-indigo-50 px-2 py-0.5 text-xs font-semibold text-indigo-700 whitespace-nowrap">
          <Send className="h-3.5 w-3.5 shrink-0" />
          Sent
        </span>
      );
    case 'Pending':
      return (
        <span className="inline-flex items-center gap-1.5 rounded-md border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-800 whitespace-nowrap">
          <Clock className="h-3.5 w-3.5 shrink-0" />
          Pending
        </span>
      );
    case 'Cancelled':
      return (
        <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-600 whitespace-nowrap">
          <XCircle className="h-3.5 w-3.5 shrink-0" />
          Cancelled
        </span>
      );
    default:
      return (
        <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-xs font-semibold text-slate-700 whitespace-nowrap">
          <FileText className="h-3.5 w-3.5 shrink-0" />
          Draft
        </span>
      );
  }
}
