import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  Tooltip,
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import type { CategoryBreakdown } from '../../types/inventory.ts';
import { formatINR } from '../../utils/format.ts';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

interface InventoryChartsProps {
  categories: CategoryBreakdown[];
}

export function InventoryCharts({ categories }: InventoryChartsProps) {
  if (!categories || categories.length === 0) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
        No category inventory data available yet.
      </div>
    );
  }

  const labels = categories.map((c) => c.category);

  const valuationData = {
    labels,
    datasets: [
      {
        label: 'Inventory Cost (₹)',
        data: categories.map((c) => c.cost_value),
        backgroundColor: '#0F172A',
        borderRadius: 6,
        barPercentage: 0.65,
      },
      {
        label: 'Expected Retail Turnover (₹)',
        data: categories.map((c) => c.retail_value),
        backgroundColor: '#059669',
        borderRadius: 6,
        barPercentage: 0.65,
      },
    ],
  };

  const distributionData = {
    labels,
    datasets: [
      {
        data: categories.map((c) => c.total_units),
        backgroundColor: ['#0F172A', '#059669', '#D97706', '#2563EB'],
        borderColor: '#FFFFFF',
        borderWidth: 2,
      },
    ],
  };

  return (
    <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
      {/* Valuation Bar Chart */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 xl:col-span-2">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900">
              Inventory Valuation by Category
            </h2>
            <p className="text-xs text-slate-500">
              Stock cost basis vs. expected retail value across store categories
            </p>
          </div>
        </div>
        <div className="h-64 w-full">
          <Bar
            data={valuationData}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              animation: { duration: 450 },
              plugins: {
                legend: {
                  position: 'bottom',
                  labels: {
                    boxWidth: 12,
                    font: { family: "'DM Sans', sans-serif", size: 12 },
                  },
                },
                tooltip: {
                  callbacks: {
                    label: (ctx) => `${ctx.dataset.label}: ${formatINR(Number(ctx.parsed.y))}`,
                  },
                },
              },
              scales: {
                x: {
                  grid: { display: false },
                  ticks: { font: { family: "'DM Sans', sans-serif", size: 12 } },
                },
                y: {
                  beginAtZero: true,
                  grid: { color: '#F1F5F9' },
                  ticks: {
                    font: { family: "'JetBrains Mono', monospace", size: 11 },
                    callback: (value) => `₹${Number(value).toLocaleString('en-IN')}`,
                  },
                },
              },
            }}
          />
        </div>
      </div>

      {/* Category Units Doughnut */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="mb-4">
          <h2 className="font-display text-base font-semibold text-slate-900">
            Stock Distribution
          </h2>
          <p className="text-xs text-slate-500">Total physical units on shelf by category</p>
        </div>
        <div className="h-48 w-full">
          <Doughnut
            data={distributionData}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              cutout: '64%',
              animation: { duration: 450 },
              plugins: {
                legend: { display: false },
                tooltip: {
                  callbacks: {
                    label: (ctx) => `${ctx.label}: ${Number(ctx.parsed).toLocaleString('en-IN')} units`,
                  },
                },
              },
            }}
          />
        </div>
        <div className="mt-4 space-y-2 border-t border-slate-100 pt-3">
          {categories.map((cat, idx) => {
            const colors = ['bg-slate-900', 'bg-emerald-600', 'bg-amber-600', 'bg-blue-600'];
            return (
              <div key={cat.category} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-2 text-slate-700">
                  <span className={`h-2.5 w-2.5 rounded-sm ${colors[idx % colors.length]}`} />
                  {cat.category}
                </span>
                <span className="font-mono font-medium text-slate-900 tabular-nums">
                  {cat.total_units} units · {cat.product_count} SKUs
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
