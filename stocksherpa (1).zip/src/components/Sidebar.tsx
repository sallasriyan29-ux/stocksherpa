import {
  AlertCircle,
  Boxes,
  ChevronLeft,
  ChevronRight,
  Clock,
  History,
  LayoutDashboard,
  PackagePlus,
  Settings,
  ShoppingCart,
  Truck,
  X,
} from 'lucide-react';
import type { AppPage } from '../types/inventory.ts';

interface SidebarProps {
  currentPage: AppPage;
  onNavigate: (page: AppPage) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  storeName: string;
  lowStockCount: number;
  expiringCount: number;
  onQuickAddProduct: () => void;
}

export function Sidebar({
  currentPage,
  onNavigate,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
  storeName,
  lowStockCount,
  expiringCount,
  onQuickAddProduct,
}: SidebarProps) {
  const navItems: Array<{
    id: AppPage;
    label: string;
    icon: typeof LayoutDashboard;
    count?: number;
    alert?: boolean;
  }> = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'catalog', label: 'Product Catalog', icon: Boxes },
    {
      id: 'reorder',
      label: 'Reorder Assistant',
      icon: ShoppingCart,
      count: lowStockCount > 0 ? lowStockCount : undefined,
      alert: lowStockCount > 0,
    },
    {
      id: 'expiry',
      label: 'Expiry Tracker',
      icon: Clock,
      count: expiringCount > 0 ? expiringCount : undefined,
      alert: expiringCount > 0,
    },
    { id: 'suppliers', label: 'Suppliers', icon: Truck },
    { id: 'movements', label: 'Stock Ledger', icon: History },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleNav = (page: AppPage) => {
    onNavigate(page);
    onCloseMobile();
  };

  const sidebarContent = (
    <div className="flex h-full flex-col bg-slate-900 text-slate-200 select-none">
      {/* Brand header */}
      <div className="flex h-16 items-center justify-between border-b border-slate-800 px-4">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-600 text-white">
            <Boxes className="h-5 w-5" />
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <p className="font-display text-base font-bold tracking-tight text-white whitespace-nowrap">
                StockSherpa
              </p>
              <p className="truncate text-xs text-slate-400">{storeName}</p>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onCloseMobile}
          className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
          aria-label="Close navigation menu"
        >
          <X className="h-5 w-5" />
        </button>

        <button
          type="button"
          onClick={onToggleCollapse}
          className="hidden rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white lg:inline-flex"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      {/* Navigation links */}
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4" aria-label="Primary navigation">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = currentPage === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNav(item.id)}
              title={collapsed ? item.label : undefined}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                active
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <span className="flex items-center gap-3 min-w-0">
                <Icon className="h-4 w-4 shrink-0" />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </span>
              {!collapsed && item.count !== undefined && (
                <span
                  className={`ml-2 font-mono text-xs tabular-nums ${
                    active
                      ? 'text-emerald-100'
                      : item.alert
                        ? 'text-amber-400'
                        : 'text-slate-400'
                  }`}
                >
                  {item.count}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom quick action */}
      <div className="border-t border-slate-800 p-3 space-y-2">
        {!collapsed && lowStockCount > 0 && (
          <button
            type="button"
            onClick={() => handleNav('reorder')}
            className="flex w-full items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-left text-xs text-amber-200 hover:bg-amber-500/20"
          >
            <AlertCircle className="h-4 w-4 shrink-0 text-amber-400" />
            <span className="truncate">
              <strong className="font-mono tabular-nums">{lowStockCount}</strong> items need reorder
            </span>
          </button>
        )}

        <button
          type="button"
          onClick={() => {
            onQuickAddProduct();
            onCloseMobile();
          }}
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-slate-800 px-3 py-2.5 text-xs font-semibold text-white hover:bg-slate-700 transition-colors whitespace-nowrap"
        >
          <PackagePlus className="h-4 w-4 shrink-0 text-emerald-400" />
          {!collapsed && <span>Add New Product</span>}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop fixed/collapsible sidebar */}
      <aside
        className={`hidden lg:block shrink-0 border-r border-slate-800 transition-[width] duration-200 no-print ${
          collapsed ? 'w-[74px]' : 'w-64'
        }`}
      >
        <div className="sticky top-0 h-screen">{sidebarContent}</div>
      </aside>

      {/* Mobile slide-over drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden no-print">
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative z-10 w-72 max-w-[85vw] shadow-2xl">{sidebarContent}</aside>
        </div>
      )}
    </>
  );
}
