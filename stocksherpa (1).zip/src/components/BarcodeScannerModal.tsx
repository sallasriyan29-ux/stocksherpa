import { Html5Qrcode } from 'html5-qrcode';
import { Camera, CameraOff, Minus, Plus, Search, X } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../services/api.ts';
import type { MovementType, Product } from '../types/inventory.ts';
import { formatINR } from '../utils/format.ts';
import { StockStatusBadge } from './StatusBadge.tsx';

interface BarcodeScannerModalProps {
  open: boolean;
  onClose: () => void;
  onQuickAdjust: (
    product: Product,
    delta: number,
    type: MovementType,
    reason: string
  ) => Promise<Product | void>;
}

const SAMPLE_BARCODES = [
  { label: 'Atta 5kg', code: '8901725123011' },
  { label: 'Maggi 70g', code: '8901058851014' },
  { label: 'Amul Milk', code: '8901262010016' },
];

export function BarcodeScannerModal({
  open,
  onClose,
  onQuickAdjust,
}: BarcodeScannerModalProps) {
  const [manualCode, setManualCode] = useState('');
  const [scanning, setScanning] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [lookingUp, setLookingUp] = useState(false);
  const [foundProduct, setFoundProduct] = useState<Product | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const regionId = 'stocksherpa-barcode-reader';

  const stopCamera = useCallback(async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
        scannerRef.current.clear();
      } catch {
        // ignore stop errors
      }
      scannerRef.current = null;
    }
    setScanning(false);
  }, []);

  const lookupCode = useCallback(async (code: string) => {
    const trimmed = code.trim();
    if (!trimmed) return;
    setLookingUp(true);
    setLookupError(null);
    try {
      const prod = await api.lookupBarcode(trimmed);
      setFoundProduct(prod);
    } catch (err) {
      setFoundProduct(null);
      setLookupError(err instanceof Error ? err.message : 'Product not found');
    } finally {
      setLookingUp(false);
    }
  }, []);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError(
        'Camera API is unavailable in this browser or context. Use manual barcode entry below.'
      );
      return;
    }

    try {
      await stopCamera();
      const html5Qr = new Html5Qrcode(regionId);
      scannerRef.current = html5Qr;
      setScanning(true);

      await html5Qr.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 250, height: 140 },
        },
        (decodedText) => {
          setManualCode(decodedText);
          void lookupCode(decodedText);
          void stopCamera();
        },
        () => {
          // frame decode miss is expected while scanning
        }
      );
    } catch (err) {
      setScanning(false);
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('notallowed')) {
        setCameraError(
          'Camera permission denied. Allow camera access in browser settings or enter the barcode manually below.'
        );
      } else {
        setCameraError(
          'No accessible camera device detected. You can scan or enter any EAN/SKU manually below.'
        );
      }
    }
  }, [lookupCode, stopCamera]);

  useEffect(() => {
    if (!open) {
      void stopCamera();
      setFoundProduct(null);
      setLookupError(null);
      setCameraError(null);
      setManualCode('');
    }
  }, [open, stopCamera]);

  if (!open) return null;

  const handleAdjust = async (delta: number, type: MovementType, reason: string) => {
    if (!foundProduct) return;
    const updated = await onQuickAdjust(foundProduct, delta, type, reason);
    if (updated) {
      setFoundProduct(updated);
    } else {
      const refreshed = await api.getProduct(foundProduct.id).catch(() => null);
      if (refreshed) setFoundProduct(refreshed);
    }
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/60 p-4 overflow-y-auto">
      <div className="my-8 w-full max-w-lg rounded-xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <div>
            <h2 className="font-display text-base font-bold text-slate-900">
              Barcode Scanner & Lookup
            </h2>
            <p className="text-xs text-slate-500">
              Scan EAN-13 / UPC barcode via camera or enter barcode / SKU manually
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Camera viewport */}
          <div className="overflow-hidden rounded-xl border border-slate-200 bg-slate-950">
            <div id={regionId} className={scanning ? 'min-h-[220px] w-full' : 'hidden'} />
            {!scanning && (
              <div className="flex flex-col items-center justify-center px-6 py-8 text-center text-slate-300">
                {cameraError ? (
                  <>
                    <CameraOff className="h-8 w-8 text-amber-400" />
                    <p className="mt-2 max-w-sm text-xs leading-relaxed text-amber-200">
                      {cameraError}
                    </p>
                  </>
                ) : (
                  <>
                    <Camera className="h-8 w-8 text-emerald-400" />
                    <p className="mt-2 text-xs text-slate-300">
                      Start device camera to scan EAN-13, EAN-8, or UPC barcodes
                    </p>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => void startCamera()}
                  className="mt-4 inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                >
                  <Camera className="h-4 w-4" />
                  {cameraError ? 'Retry Camera' : 'Start Camera Scanner'}
                </button>
              </div>
            )}
            {scanning && (
              <div className="flex justify-center border-t border-slate-800 bg-slate-900 py-2">
                <button
                  type="button"
                  onClick={() => void stopCamera()}
                  className="text-xs font-semibold text-slate-300 hover:text-white"
                >
                  Stop Camera
                </button>
              </div>
            )}
          </div>

          {/* Manual Barcode Entry Fallback */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void lookupCode(manualCode);
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="Enter barcode or SKU (e.g. 8901725123011)"
                className="w-full rounded-lg border border-slate-300 py-2.5 pl-9 pr-3 font-mono text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={lookingUp || !manualCode.trim()}
              className="rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
            >
              {lookingUp ? 'Finding...' : 'Lookup'}
            </button>
          </form>

          {/* Quick Test Barcodes */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <span>Quick lookup:</span>
            {SAMPLE_BARCODES.map((sample) => (
              <button
                key={sample.code}
                type="button"
                onClick={() => {
                  setManualCode(sample.code);
                  void lookupCode(sample.code);
                }}
                className="rounded border border-slate-200 bg-slate-50 px-2 py-1 font-mono text-[11px] text-slate-700 hover:bg-slate-100"
              >
                {sample.label}
              </button>
            ))}
          </div>

          {lookupError && (
            <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700">
              {lookupError}
            </div>
          )}

          {foundProduct && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-xs text-slate-500">
                    {foundProduct.sku} · {foundProduct.category}
                  </p>
                  <h3 className="text-sm font-bold text-slate-900">{foundProduct.name}</h3>
                </div>
                <StockStatusBadge status={foundProduct.stock_status} />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-600">
                <span>
                  Stock:{' '}
                  <strong className="font-mono text-base text-slate-900 tabular-nums">
                    {foundProduct.current_quantity} {foundProduct.unit}
                  </strong>
                </span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  MRP {formatINR(foundProduct.selling_price)}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-1">
                <button
                  type="button"
                  disabled={foundProduct.current_quantity <= 0}
                  onClick={() =>
                    void handleAdjust(-1, 'Sale', 'Barcode scanner quick sale (-1)')
                  }
                  className="flex h-10 items-center justify-center gap-1 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-800 hover:bg-red-50 hover:text-red-700 disabled:opacity-40"
                >
                  <Minus className="h-3.5 w-3.5" />1 Sale
                </button>
                <button
                  type="button"
                  onClick={() =>
                    void handleAdjust(1, 'Manual correction', 'Barcode scanner quick add (+1)')
                  }
                  className="flex h-10 items-center justify-center gap-1 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-800 hover:bg-emerald-50 hover:text-emerald-700"
                >
                  <Plus className="h-3.5 w-3.5" />1 Add
                </button>
                <button
                  type="button"
                  onClick={() =>
                    void handleAdjust(10, 'Supplier delivery', 'Barcode scanner restock (+10)')
                  }
                  className="flex h-10 items-center justify-center gap-1 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-700"
                >
                  <Plus className="h-3.5 w-3.5" />10 Restock
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
