import { X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { Product, ProductCategory, Supplier } from '../types/inventory.ts';
import { formatINR } from '../utils/format.ts';

interface ProductModalProps {
  open: boolean;
  product: Product | null;
  suppliers: Supplier[];
  saving: boolean;
  onClose: () => void;
  onSave: (payload: {
    name: string;
    sku: string;
    barcode: string | null;
    category: ProductCategory;
    cost_price: number;
    selling_price: number;
    current_quantity: number;
    minimum_stock_threshold: number;
    target_stock_level: number;
    unit: string;
    supplier_id: number | null;
    expiry_date: string | null;
  }) => Promise<void>;
}

const CATEGORIES: ProductCategory[] = ['Grains', 'Dairy', 'Snacks', 'Personal Care'];
const UNITS = ['pack', 'bag', 'pouch', 'bottle', 'jar', 'cup', 'bar', 'tube', 'pcs', 'kg', 'L'];

export function ProductModal({
  open,
  product,
  suppliers,
  saving,
  onClose,
  onSave,
}: ProductModalProps) {
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState<ProductCategory>('Grains');
  const [costPrice, setCostPrice] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [currentQty, setCurrentQty] = useState('0');
  const [minThreshold, setMinThreshold] = useState('5');
  const [targetStock, setTargetStock] = useState('20');
  const [unit, setUnit] = useState('pack');
  const [supplierId, setSupplierId] = useState<string>('');
  const [expiryDate, setExpiryDate] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    setError('');
    if (product) {
      setName(product.name);
      setSku(product.sku);
      setBarcode(product.barcode || '');
      setCategory(product.category);
      setCostPrice(String(product.cost_price));
      setSellingPrice(String(product.selling_price));
      setCurrentQty(String(product.current_quantity));
      setMinThreshold(String(product.minimum_stock_threshold));
      setTargetStock(String(product.target_stock_level));
      setUnit(product.unit);
      setSupplierId(product.supplier_id ? String(product.supplier_id) : '');
      setExpiryDate(product.expiry_date || '');
    } else {
      setName('');
      setSku('');
      setBarcode('');
      setCategory('Grains');
      setCostPrice('');
      setSellingPrice('');
      setCurrentQty('10');
      setMinThreshold('5');
      setTargetStock('20');
      setUnit('pack');
      setSupplierId(suppliers[0] ? String(suppliers[0].id) : '');
      setExpiryDate('');
    }
  }, [open, product, suppliers]);

  if (!open) return null;

  const generateSku = () => {
    const prefixMap: Record<ProductCategory, string> = {
      Grains: 'GRN',
      Dairy: 'DRY',
      Snacks: 'SNK',
      'Personal Care': 'PRC',
    };
    const word = name
      .replace(/[^a-zA-Z0-9]/g, '')
      .slice(0, 3)
      .toUpperCase() || 'ITM';
    const rand = String(Math.floor(100 + Math.random() * 900));
    setSku(`${prefixMap[category]}-${word}-${rand}`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cost = Number(costPrice);
    const sell = Number(sellingPrice);
    const qty = Number(currentQty);
    const min = Number(minThreshold);
    const target = Number(targetStock);

    if (!name.trim()) {
      setError('Product name is required.');
      return;
    }
    if (!sku.trim() || sku.trim().length < 2) {
      setError('SKU must be at least 2 characters.');
      return;
    }
    if (!Number.isFinite(cost) || cost < 0) {
      setError('Cost price must be a non-negative number.');
      return;
    }
    if (!Number.isFinite(sell) || sell < 0) {
      setError('Selling price must be a non-negative number.');
      return;
    }
    if (!Number.isInteger(qty) || qty < 0) {
      setError('Current quantity must be a non-negative whole number.');
      return;
    }
    if (!Number.isInteger(min) || min < 0) {
      setError('Minimum stock threshold must be a non-negative whole number.');
      return;
    }
    if (!Number.isInteger(target) || target < 0) {
      setError('Target stock level must be a non-negative whole number.');
      return;
    }

    try {
      await onSave({
        name: name.trim(),
        sku: sku.trim().toUpperCase(),
        barcode: barcode.trim() || null,
        category,
        cost_price: cost,
        selling_price: sell,
        current_quantity: qty,
        minimum_stock_threshold: min,
        target_stock_level: target,
        unit,
        supplier_id: supplierId ? Number(supplierId) : null,
        expiry_date: expiryDate || null,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save product.');
    }
  };

  const costNum = Number(costPrice) || 0;
  const sellNum = Number(sellingPrice) || 0;
  const unitMargin = sellNum - costNum;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/50 p-4 overflow-y-auto">
      <div className="my-8 w-full max-w-2xl rounded-xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900">
              {product ? 'Edit Product' : 'Add New Product'}
            </h2>
            <p className="text-xs text-slate-500">
              {product
                ? `Updating ${product.sku} · Version ${product.version}`
                : 'Add a store item with pricing, reorder thresholds, and supplier details'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-xs font-medium text-red-700">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Aashirvaad Shudh Chakki Atta (5kg)"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold text-slate-700">SKU *</label>
                <button
                  type="button"
                  onClick={generateSku}
                  className="text-xs font-medium text-emerald-700 hover:underline"
                >
                  Auto-generate
                </button>
              </div>
              <input
                type="text"
                required
                value={sku}
                onChange={(e) => setSku(e.target.value.toUpperCase())}
                placeholder="GRN-ATT-101"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Barcode (EAN / UPC)
              </label>
              <input
                type="text"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                placeholder="8901725123011 (optional)"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ProductCategory)}
                className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Preferred Supplier
              </label>
              <select
                value={supplierId}
                onChange={(e) => setSupplierId(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
              >
                <option value="">No supplier assigned</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Cost Price (₹) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={costPrice}
                onChange={(e) => setCostPrice(e.target.value)}
                placeholder="215"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 tabular-nums focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Selling Price (₹) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
                placeholder="255"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 tabular-nums focus:border-emerald-600 focus:outline-none"
              />
              {sellNum > 0 && (
                <p className={`mt-1 text-xs font-mono tabular-nums ${unitMargin >= 0 ? 'text-emerald-700' : 'text-red-600'}`}>
                  Margin per unit: {formatINR(unitMargin)} ({((unitMargin / sellNum) * 100).toFixed(1)}%)
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Current Stock Quantity *
              </label>
              <input
                type="number"
                min="0"
                step="1"
                required
                value={currentQty}
                onChange={(e) => setCurrentQty(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 tabular-nums focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Unit of Measurement *
              </label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
              >
                {UNITS.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Minimum Stock Threshold *
              </label>
              <input
                type="number"
                min="0"
                step="1"
                required
                value={minThreshold}
                onChange={(e) => setMinThreshold(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 tabular-nums focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Target Reorder Level
              </label>
              <input
                type="number"
                min="0"
                step="1"
                value={targetStock}
                onChange={(e) => setTargetStock(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 tabular-nums focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700">
                Expiry Date (for perishables & packaged food)
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-emerald-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-200 pt-4">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : product ? 'Save Changes' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
