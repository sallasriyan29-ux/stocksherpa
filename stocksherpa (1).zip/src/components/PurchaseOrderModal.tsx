import {
  Check,
  Copy,
  Download,
  ExternalLink,
  MessageSquare,
  PackageCheck,
  Printer,
  X,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import type { PurchaseOrder, PurchaseOrderStatus } from '../types/inventory.ts';
import {
  buildWhatsAppOrderMessage,
  buildWhatsAppUrl,
  exportPurchaseOrderCsv,
  formatDate,
  formatINR,
} from '../utils/format.ts';
import { PurchaseOrderStatusBadge } from './StatusBadge.tsx';

interface PurchaseOrderModalProps {
  order: PurchaseOrder | null;
  saving: boolean;
  initialShowWhatsApp?: boolean;
  onClose: () => void;
  onUpdateStatus: (
    orderId: number,
    payload: {
      status?: PurchaseOrderStatus;
      received_items?: Array<{ product_id: number; quantity_received: number }>;
    }
  ) => Promise<void>;
}

export function PurchaseOrderModal({
  order,
  saving,
  initialShowWhatsApp = false,
  onClose,
  onUpdateStatus,
}: PurchaseOrderModalProps) {
  const [showWhatsApp, setShowWhatsApp] = useState(initialShowWhatsApp);
  const [showReceive, setShowReceive] = useState(false);
  const [copied, setCopied] = useState(false);
  const [receiveCounts, setReceiveCounts] = useState<Record<number, number>>({});

  useEffect(() => {
    setShowWhatsApp(initialShowWhatsApp);
    setShowReceive(false);
    setCopied(false);
    if (order?.items) {
      const defaults: Record<number, number> = {};
      for (const item of order.items) {
        defaults[item.product_id] = Math.max(0, item.quantity_ordered - item.quantity_received);
      }
      setReceiveCounts(defaults);
    }
  }, [order, initialShowWhatsApp]);

  if (!order) return null;

  const whatsappMessage = buildWhatsAppOrderMessage(order);
  const whatsappUrl = buildWhatsAppUrl(order.supplier_phone, whatsappMessage);
  const canReceive =
    order.status !== 'Received' && order.status !== 'Cancelled' && (order.items?.length || 0) > 0;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(whatsappMessage);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore clipboard errors
    }
  };

  const handleReceiveSubmit = async () => {
    const received_items = (order.items || [])
      .map((item) => ({
        product_id: item.product_id,
        quantity_received: Number(receiveCounts[item.product_id] || 0),
      }))
      .filter((r) => r.quantity_received > 0);

    if (received_items.length === 0) return;
    await onUpdateStatus(order.id, { received_items });
    setShowReceive(false);
  };

  return (
    <div className="fixed inset-0 z-[75] flex items-center justify-center bg-slate-950/50 p-4 overflow-y-auto">
      <div className="my-8 w-full max-w-3xl rounded-xl border border-slate-200 bg-white shadow-xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-6 py-4 no-print">
          <div className="flex items-center gap-3">
            <h2 className="font-display text-lg font-bold text-slate-900">
              {order.order_number}
            </h2>
            <PurchaseOrderStatusBadge status={order.status} />
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => exportPurchaseOrderCsv(order)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              <Download className="h-3.5 w-3.5" />
              Export CSV
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              <Printer className="h-3.5 w-3.5" />
              Print
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Printable Purchase Order Document */}
        <div className="p-6 space-y-5">
          <div className="grid grid-cols-1 gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4 sm:grid-cols-2 text-xs">
            <div>
              <p className="font-semibold text-slate-500">From Store</p>
              <p className="mt-1 text-sm font-bold text-slate-900">{order.store_name}</p>
              <p className="mt-1 text-slate-600">Order Date: {formatDate(order.order_date)}</p>
            </div>
            <div>
              <p className="font-semibold text-slate-500">To Supplier</p>
              <p className="mt-1 text-sm font-bold text-slate-900">{order.supplier_name}</p>
              <p className="mt-1 font-mono text-slate-600">
                {order.supplier_contact ? `${order.supplier_contact} · ` : ''}
                {order.supplier_phone || 'No phone on file'}
              </p>
            </div>
          </div>

          {/* Line items table */}
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <tr>
                  <th className="px-4 py-2.5">Product</th>
                  <th className="px-3 py-2.5">SKU</th>
                  <th className="px-3 py-2.5 text-right">Ordered</th>
                  <th className="px-3 py-2.5 text-right">Received</th>
                  <th className="px-3 py-2.5 text-right">Unit Cost</th>
                  <th className="px-4 py-2.5 text-right">Line Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(order.items || []).map((item) => (
                  <tr key={item.id}>
                    <td className="px-4 py-2.5 font-medium text-slate-900">{item.product_name}</td>
                    <td className="px-3 py-2.5 font-mono text-xs text-slate-500">{item.sku}</td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums">
                      {item.quantity_ordered}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-600">
                      {item.quantity_received}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums">
                      {formatINR(item.unit_cost)}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono font-semibold text-slate-900 tabular-nums">
                      {formatINR(item.line_total)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="border-t border-slate-200 bg-slate-50">
                <tr>
                  <td colSpan={5} className="px-4 py-3 text-right text-xs font-semibold text-slate-600">
                    Grand Total (Estimated Cost)
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-base font-bold text-slate-900 tabular-nums">
                    {formatINR(order.total_cost)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {order.notes && (
            <p className="text-xs text-slate-600">
              <strong className="text-slate-800">Notes:</strong> {order.notes}
            </p>
          )}

          {/* Receive Stock Panel */}
          {showReceive && canReceive && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-4 space-y-3 no-print">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900">
                  Confirm Received Stock Quantities
                </h3>
                <span className="text-xs text-slate-600">
                  Inventory & movement ledger update atomically on confirmation
                </span>
              </div>
              <div className="space-y-2">
                {(order.items || []).map((item) => {
                  const remaining = Math.max(0, item.quantity_ordered - item.quantity_received);
                  return (
                    <div
                      key={item.id}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                    >
                      <div>
                        <p className="font-semibold text-slate-900">{item.product_name}</p>
                        <p className="text-slate-500">Remaining to receive: {remaining}</p>
                      </div>
                      <input
                        type="number"
                        min="0"
                        max={remaining}
                        value={receiveCounts[item.product_id] ?? 0}
                        onChange={(e) =>
                          setReceiveCounts((prev) => ({
                            ...prev,
                            [item.product_id]: Math.min(
                              remaining,
                              Math.max(0, Number(e.target.value) || 0)
                            ),
                          }))
                        }
                        className="w-24 rounded-lg border border-slate-300 px-2.5 py-1.5 text-right font-mono font-semibold tabular-nums"
                      />
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowReceive(false)}
                  className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void handleReceiveSubmit()}
                  className="rounded-lg bg-emerald-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                >
                  {saving ? 'Updating Inventory...' : 'Confirm Delivery & Add to Stock'}
                </button>
              </div>
            </div>
          )}

          {/* WhatsApp Preview Panel */}
          {showWhatsApp && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-4 space-y-3 no-print">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900">
                  WhatsApp Supplier Message Preview
                </h3>
                <button
                  type="button"
                  onClick={() => void handleCopy()}
                  className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied ? 'Copied' : 'Copy Text'}
                </button>
              </div>
              <pre className="whitespace-pre-wrap rounded-lg border border-slate-200 bg-white p-3 font-mono text-xs leading-relaxed text-slate-800">
                {whatsappMessage}
              </pre>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-xs text-slate-600">
                  Clicking below opens WhatsApp click-to-chat. Please confirm and send the message inside WhatsApp.
                </p>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    if (order.status === 'Draft' || order.status === 'Pending') {
                      void onUpdateStatus(order.id, { status: 'Sent' });
                    }
                  }}
                  className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                >
                  <MessageSquare className="h-4 w-4" />
                  Open in WhatsApp
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 px-6 py-4 no-print">
          <div className="flex flex-wrap items-center gap-2">
            {order.status !== 'Received' && order.status !== 'Cancelled' && (
              <>
                <select
                  value={order.status}
                  disabled={saving}
                  onChange={(e) =>
                    void onUpdateStatus(order.id, {
                      status: e.target.value as PurchaseOrderStatus,
                    })
                  }
                  className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800"
                >
                  <option value="Draft">Draft</option>
                  <option value="Pending">Pending</option>
                  <option value="Sent">Sent</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowWhatsApp((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-600 bg-white px-4 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-50"
            >
              <MessageSquare className="h-4 w-4" />
              Generate WhatsApp Order
            </button>

            {canReceive && (
              <button
                type="button"
                onClick={() => setShowReceive((v) => !v)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
              >
                <PackageCheck className="h-4 w-4" />
                Receive Stock
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
