import { AlertTriangle, CloudOff, RefreshCw, Trash2, Wifi, X } from 'lucide-react';
import { useState } from 'react';
import type { SyncState } from '../hooks/useOnlineStatus.ts';
import type { QueuedStockOperation } from '../services/offlineQueue.ts';
import { formatDateTime } from '../utils/format.ts';

interface SyncStatusBarProps {
  isOnline: boolean;
  syncState: SyncState;
  queue: QueuedStockOperation[];
  onSyncNow: (forceOperationId?: string) => Promise<{ synced: number; conflicts: number; failed: number }>;
  onDiscard: (operationId: string) => void;
}

export function SyncStatusBar({
  isOnline,
  syncState,
  queue,
  onSyncNow,
  onDiscard,
}: SyncStatusBarProps) {
  const [modalOpen, setModalOpen] = useState(false);

  const label =
    syncState === 'syncing'
      ? 'Syncing...'
      : syncState === 'offline'
        ? `Offline${queue.length > 0 ? ` (${queue.length})` : ''}`
        : syncState === 'sync_failed'
          ? `Sync Failed (${queue.length})`
          : queue.length > 0
            ? `Pending Sync (${queue.length})`
            : 'Online';

  const styleClass =
    syncState === 'offline'
      ? 'border-amber-200 bg-amber-50 text-amber-800'
      : syncState === 'sync_failed'
        ? 'border-red-200 bg-red-50 text-red-700'
        : syncState === 'syncing'
          ? 'border-sky-200 bg-sky-50 text-sky-800'
          : 'border-emerald-200 bg-emerald-50 text-emerald-700';

  const Icon =
    syncState === 'offline'
      ? CloudOff
      : syncState === 'sync_failed'
        ? AlertTriangle
        : syncState === 'syncing'
          ? RefreshCw
          : Wifi;

  return (
    <>
      <button
        type="button"
        onClick={() => setModalOpen(true)}
        className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${styleClass}`}
        title="View connectivity and offline synchronization queue"
      >
        <Icon className={`h-3.5 w-3.5 shrink-0 ${syncState === 'syncing' ? 'animate-spin' : ''}`} />
        <span>{label}</span>
      </button>

      {modalOpen && (
        <div className="fixed inset-0 z-[85] flex items-center justify-center bg-slate-950/50 p-4">
          <div className="w-full max-w-xl rounded-xl border border-slate-200 bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
              <div>
                <h3 className="text-base font-semibold text-slate-900">
                  Offline Queue & Synchronization
                </h3>
                <p className="mt-0.5 text-xs text-slate-500">
                  Connection: {isOnline ? 'Online (Server reachable)' : 'Offline (Local queue active)'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="max-h-[60vh] overflow-y-auto p-6">
              {queue.length === 0 ? (
                <div className="rounded-lg border border-slate-200 bg-slate-50 p-6 text-center">
                  <Wifi className="mx-auto h-7 w-7 text-emerald-600" />
                  <p className="mt-2 text-sm font-semibold text-slate-900">
                    All inventory changes synchronized
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    Offline stock adjustments are queued with unique operation IDs and version checks
                    so server data is never silently overwritten.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {queue.map((op) => (
                    <div
                      key={op.operationId}
                      className={`rounded-lg border p-4 ${
                        op.status === 'conflict'
                          ? 'border-red-200 bg-red-50/50'
                          : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <p className="text-sm font-semibold text-slate-900">
                            {op.productName}{' '}
                            <span className="font-mono text-xs text-slate-500">({op.productSku})</span>
                          </p>
                          <p className="mt-0.5 text-xs text-slate-600">
                            {op.movementType}:{' '}
                            <span className="font-mono font-semibold tabular-nums">
                              {op.quantityChanged > 0 ? `+${op.quantityChanged}` : op.quantityChanged}
                            </span>{' '}
                            · Queued {formatDateTime(op.queuedAt)}
                          </p>
                        </div>
                        <span className="rounded border border-slate-200 bg-white px-2 py-0.5 text-xs font-medium text-slate-700">
                          {op.status === 'conflict'
                            ? 'Conflict Detected'
                            : op.status === 'failed'
                              ? 'Retry Pending'
                              : 'Pending'}
                        </span>
                      </div>

                      {op.errorMessage && (
                        <p className="mt-2 text-xs text-red-700">{op.errorMessage}</p>
                      )}

                      <div className="mt-3 flex flex-wrap items-center justify-end gap-2">
                        {op.status === 'conflict' && isOnline && (
                          <button
                            type="button"
                            onClick={() => void onSyncNow(op.operationId)}
                            className="rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-700"
                          >
                            Apply Anyway (Force)
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onDiscard(op.operationId)}
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          Discard
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between border-t border-slate-200 px-6 py-4">
              <span className="font-mono text-xs text-slate-500">
                {queue.length} queued operation{queue.length === 1 ? '' : 's'}
              </span>
              <div className="flex items-center gap-2">
                {queue.length > 0 && (
                  <button
                    type="button"
                    disabled={!isOnline || syncState === 'syncing'}
                    onClick={() => void onSyncNow()}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${syncState === 'syncing' ? 'animate-spin' : ''}`} />
                    Sync Now
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
