import type { PurchaseOrder } from '../types/inventory.ts';

const inrFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

const intFormatter = new Intl.NumberFormat('en-IN');

export function formatINR(amount: number): string {
  if (!Number.isFinite(amount)) return '₹0';
  return inrFormatter.format(amount);
}

export function formatNumber(val: number): string {
  if (!Number.isFinite(val)) return '0';
  return intFormatter.format(val);
}

export function formatDate(isoOrDate: string | null | undefined): string {
  if (!isoOrDate) return '—';
  const d = new Date(isoOrDate.includes('T') ? isoOrDate : `${isoOrDate}T00:00:00`);
  if (Number.isNaN(d.getTime())) return isoOrDate;
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  const normalized = iso.includes('T') ? iso : `${iso.replace(' ', 'T')}Z`;
  const d = new Date(normalized);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function normalizeIndianPhone(rawPhone?: string | null): string {
  if (!rawPhone) return '';
  const digits = rawPhone.replace(/\D/g, '');
  if (digits.length === 10) return `91${digits}`;
  return digits;
}

export function buildWhatsAppOrderMessage(po: PurchaseOrder): string {
  const lines: string[] = [
    `*PURCHASE ORDER — ${po.order_number}*`,
    `From: ${po.store_name}`,
    `To: ${po.supplier_name || 'Supplier'}`,
    `Date: ${formatDate(po.order_date)}`,
    '',
    '*Items Required:*',
  ];

  const items = po.items || [];
  items.forEach((item, idx) => {
    lines.push(
      `${idx + 1}. ${item.product_name} (${item.sku}) — Qty: ${item.quantity_ordered} @ ${formatINR(item.unit_cost)} = ${formatINR(item.line_total)}`
    );
  });

  lines.push('');
  lines.push(`*Total Estimated Cost: ${formatINR(po.total_cost)}*`);
  if (po.notes) {
    lines.push(`Notes: ${po.notes}`);
  }
  lines.push('');
  lines.push('Please confirm stock availability and delivery slot. Thank you!');

  return lines.join('\n');
}

export function buildWhatsAppUrl(phone: string | null | undefined, message: string): string {
  const normalized = normalizeIndianPhone(phone);
  const encoded = encodeURIComponent(message);
  if (normalized.length >= 10) {
    return `https://wa.me/${normalized}?text=${encoded}`;
  }
  return `https://wa.me/?text=${encoded}`;
}

export function exportPurchaseOrderCsv(po: PurchaseOrder): void {
  const headers = ['Order Number', 'Store Name', 'Supplier', 'SKU', 'Product Name', 'Qty Ordered', 'Qty Received', 'Unit Cost (INR)', 'Line Total (INR)'];
  const rows = (po.items || []).map((item) => [
    po.order_number,
    po.store_name,
    po.supplier_name || '',
    item.sku,
    item.product_name,
    String(item.quantity_ordered),
    String(item.quantity_received),
    String(item.unit_cost),
    String(item.line_total),
  ]);

  const csvContent = [headers, ...rows]
    .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${po.order_number}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
