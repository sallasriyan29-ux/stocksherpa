export type ProductCategory = 'Grains' | 'Dairy' | 'Snacks' | 'Personal Care';

export type StockAlertLevel = 'In Stock' | 'Low Stock' | 'Out of Stock';

export type ExpiryStatus = 'Expired' | 'Critical' | 'Expiring Soon' | 'Safe' | 'N/A';

export type MovementType =
  | 'Sale'
  | 'Supplier delivery'
  | 'Manual correction'
  | 'Damaged goods'
  | 'Returned goods';

export type PurchaseOrderStatus =
  | 'Draft'
  | 'Pending'
  | 'Sent'
  | 'Partially Received'
  | 'Received'
  | 'Cancelled';

export interface Product {
  id: number;
  name: string;
  sku: string;
  barcode: string | null;
  category: ProductCategory;
  cost_price: number;
  selling_price: number;
  current_quantity: number;
  minimum_stock_threshold: number;
  target_stock_level: number;
  unit: string;
  supplier_id: number | null;
  supplier_name?: string | null;
  supplier_phone?: string | null;
  expiry_date: string | null;
  is_sample: number;
  version: number;
  created_at: string;
  updated_at: string;
  stock_status: StockAlertLevel;
  expiry_status: ExpiryStatus;
  days_until_expiry: number | null;
}

export interface Supplier {
  id: number;
  name: string;
  contact_person: string;
  phone: string;
  email: string | null;
  address: string | null;
  is_sample: number;
  created_at: string;
  updated_at: string;
  product_count?: number;
  outstanding_orders?: number;
  total_order_value?: number;
  products?: Array<{
    id: number;
    name: string;
    sku: string;
    current_quantity: number;
    minimum_stock_threshold: number;
    cost_price: number;
    unit: string;
  }>;
  purchase_orders?: PurchaseOrder[];
}

export interface StockMovement {
  id: number;
  product_id: number;
  product_name?: string;
  product_sku?: string;
  movement_type: MovementType;
  quantity_changed: number;
  previous_quantity: number;
  new_quantity: number;
  reason: string;
  reference_po_id: number | null;
  reference_order_number?: string | null;
  client_operation_id: string | null;
  created_at: string;
}

export interface PurchaseOrderItem {
  id: number;
  purchase_order_id: number;
  product_id: number;
  product_name: string;
  sku: string;
  quantity_ordered: number;
  quantity_received: number;
  unit_cost: number;
  line_total: number;
}

export interface PurchaseOrder {
  id: number;
  order_number: string;
  supplier_id: number;
  supplier_name?: string;
  supplier_phone?: string;
  supplier_contact?: string;
  store_name: string;
  status: PurchaseOrderStatus;
  total_cost: number;
  notes: string | null;
  order_date: string;
  received_at: string | null;
  created_at: string;
  updated_at: string;
  items?: PurchaseOrderItem[];
}

export interface ReorderSuggestion {
  product_id: number;
  product_name: string;
  sku: string;
  category: ProductCategory;
  unit: string;
  current_quantity: number;
  minimum_stock_threshold: number;
  target_stock_level: number;
  recommended_quantity: number;
  cost_price: number;
  estimated_cost: number;
  stock_status: StockAlertLevel;
  supplier_id: number | null;
  supplier_name: string | null;
  supplier_phone: string | null;
}

export interface ExpiryRecord {
  id: number;
  product_id: number;
  product_name: string;
  sku: string;
  category: ProductCategory;
  batch_code: string;
  quantity: number;
  current_quantity: number;
  unit: string;
  cost_price: number;
  expiry_date: string;
  days_remaining: number;
  expiry_status: ExpiryStatus;
  notes: string | null;
}

export interface DashboardSummary {
  total_products: number;
  total_units: number;
  inventory_value_cost: number;
  expected_retail_turnover: number;
  expected_gross_profit: number;
  gross_profit_margin: number;
  low_stock_count: number;
  out_of_stock_count: number;
  pending_purchase_orders: number;
  expiring_products_count: number;
  expired_products_count: number;
  store_name: string;
}

export interface CategoryBreakdown {
  category: string;
  product_count: number;
  total_units: number;
  cost_value: number;
  retail_value: number;
  expected_profit: number;
  alert_count: number;
}

export interface DashboardAnalytics {
  category_breakdown: CategoryBreakdown[];
  low_stock_products: Product[];
  recent_movements: StockMovement[];
  recent_purchase_orders: PurchaseOrder[];
  expiry_alerts: ExpiryRecord[];
}

export interface StoreSettings {
  store_name: string;
  owner_name: string;
  store_phone: string;
  store_address: string;
  currency_symbol: string;
}

export type AppPage =
  | 'dashboard'
  | 'catalog'
  | 'reorder'
  | 'expiry'
  | 'suppliers'
  | 'movements'
  | 'settings';
