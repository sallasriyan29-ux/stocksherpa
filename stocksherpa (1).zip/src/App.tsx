import { useCallback, useEffect, useState } from 'react';
import { BarcodeScannerModal } from './components/BarcodeScannerModal.tsx';
import { ConfirmDialog } from './components/ConfirmDialog.tsx';
import { CursorFollower } from './components/CursorFollower.tsx';
import { ProductDetailDrawer } from './components/ProductDetailDrawer.tsx';
import { ProductModal } from './components/ProductModal.tsx';
import { PurchaseOrderModal } from './components/PurchaseOrderModal.tsx';
import { QuickAdjustModal } from './components/QuickAdjustModal.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { ToastContainer } from './components/ToastContainer.tsx';
import { TopBar } from './components/TopBar.tsx';
import { useOnlineSync } from './hooks/useOnlineStatus.ts';
import { useToast } from './hooks/useToast.ts';
import { CatalogPage } from './pages/CatalogPage.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { ExpiryPage } from './pages/ExpiryPage.tsx';
import { MovementsPage } from './pages/MovementsPage.tsx';
import { ReorderPage } from './pages/ReorderPage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';
import { SuppliersPage } from './pages/SuppliersPage.tsx';
import { ApiError, api } from './services/api.ts';
import {
  cacheProductsSnapshot,
  enqueueStockOperation,
  readCachedProducts,
} from './services/offlineQueue.ts';
import type {
  AppPage,
  DashboardAnalytics,
  DashboardSummary,
  ExpiryRecord,
  MovementType,
  Product,
  ProductCategory,
  PurchaseOrder,
  PurchaseOrderStatus,
  ReorderSuggestion,
  StockMovement,
  StoreSettings,
  Supplier,
} from './types/inventory.ts';

export default function App() {
  const [currentPage, setCurrentPage] = useState<AppPage>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Core data state
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [analytics, setAnalytics] = useState<DashboardAnalytics | null>(null);
  const [products, setProducts] = useState<Product[]>(() => readCachedProducts());
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [suggestions, setSuggestions] = useState<ReorderSuggestion[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [expiryRecords, setExpiryRecords] = useState<ExpiryRecord[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Modals & Drawers
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [activeOrder, setActiveOrder] = useState<PurchaseOrder | null>(null);
  const [orderModalWhatsApp, setOrderModalWhatsApp] = useState(false);

  // Confirmation dialogs
  const [deleteProductTarget, setDeleteProductTarget] = useState<Product | null>(null);
  const [deleteSupplierTarget, setDeleteSupplierTarget] = useState<Supplier | null>(null);
  const [resetDemoConfirmOpen, setResetDemoConfirmOpen] = useState(false);

  const { toasts, showToast, dismissToast } = useToast();

  const fetchAllData = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const [sumData, anaData, prodData, supData, sugData, poData, expData, movData, setData] =
        await Promise.all([
          api.getDashboardSummary(),
          api.getDashboardAnalytics(),
          api.listProducts(),
          api.listSuppliers(),
          api.getReorderSuggestions(),
          api.listPurchaseOrders(),
          api.listExpiry(),
          api.listMovements({ limit: 250 }),
          api.getSettings(),
        ]);

      setSummary(sumData);
      setAnalytics(anaData);
      setProducts(prodData);
      cacheProductsSnapshot(prodData);
      setSuppliers(supData);
      setSuggestions(sugData);
      setPurchaseOrders(poData);
      setExpiryRecords(expData);
      setMovements(movData);
      setSettings(setData);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load store data';
      setLoadError(msg);
      const cached = readCachedProducts();
      if (cached.length > 0 && products.length === 0) {
        setProducts(cached);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const { isOnline, syncState, queue, runSync, discardOperation } = useOnlineSync(() => {
    showToast('Offline changes synchronized', 'success', 'Server inventory is up to date.');
    void fetchAllData();
  });

  useEffect(() => {
    void fetchAllData();
  }, [fetchAllData]);

  // Keep open drawer product synced after refreshes
  useEffect(() => {
    if (selectedProduct) {
      const updated = products.find((p) => p.id === selectedProduct.id);
      if (updated) setSelectedProduct(updated);
    }
  }, [products, selectedProduct?.id]);

  // Stock Adjustment (online or offline queue)
  const handleAdjustStock = async (
    product: Product,
    quantityChanged: number,
    movementType: MovementType,
    reason: string
  ): Promise<Product | void> => {
    if (product.current_quantity + quantityChanged < 0) {
      showToast(
        'Insufficient stock',
        'error',
        `Cannot reduce below 0 (${product.current_quantity} ${product.unit} available).`
      );
      return;
    }

    if (!isOnline) {
      enqueueStockOperation({ product, quantityChanged, movementType, reason });
      const nextQty = product.current_quantity + quantityChanged;
      const nextStatus =
        nextQty === 0
          ? 'Out of Stock'
          : nextQty <= product.minimum_stock_threshold
            ? 'Low Stock'
            : 'In Stock';

      const updatedLocal: Product = {
        ...product,
        current_quantity: nextQty,
        stock_status: nextStatus,
      };
      setProducts((prev) => {
        const next = prev.map((p) => (p.id === product.id ? updatedLocal : p));
        cacheProductsSnapshot(next);
        return next;
      });
      showToast(
        'Queued offline adjustment',
        'warning',
        `${product.name} (${quantityChanged > 0 ? `+${quantityChanged}` : quantityChanged}) will sync when back online.`
      );
      return updatedLocal;
    }

    try {
      const res = await api.adjustStock({
        product_id: product.id,
        quantity_changed: quantityChanged,
        movement_type: movementType,
        reason,
      });

      const updated = res.data.product;
      await fetchAllData();

      if (updated.stock_status === 'Out of Stock') {
        showToast(
          `${updated.name} is now Out of Stock`,
          'error',
          'Added automatically to Smart Reorder Assistant.'
        );
      } else if (updated.stock_status === 'Low Stock') {
        showToast(
          `Low Stock Alert: ${updated.name}`,
          'warning',
          `Only ${updated.current_quantity} ${updated.unit} left (min ${updated.minimum_stock_threshold}). Added to Reorder Assistant.`
        );
      } else {
        showToast('Stock updated', 'success', res.message);
      }
      return updated;
    } catch (err) {
      if (err instanceof ApiError && err.status === 0) {
        enqueueStockOperation({ product, quantityChanged, movementType, reason });
        showToast(
          'Connection lost — queued offline',
          'warning',
          'Adjustment saved locally and will sync once server responds.'
        );
        return;
      }
      showToast(
        'Stock adjustment failed',
        'error',
        err instanceof Error ? err.message : 'Unable to adjust stock'
      );
      throw err;
    }
  };

  // Save Product (Add / Edit)
  const handleSaveProduct = async (payload: {
    name: string;
    sku: string;
    barcode: string | null;
    category: ProductCategory;
    cost_price: number;
    selling_price: number;
    current_quantity: number;
    minimum_stock_threshold: number;
    target_stock_level: number;
    unit: string;
    supplier_id: number | null;
    expiry_date: string | null;
  }) => {
    setSaving(true);
    try {
      if (editingProduct) {
        const res = await api.updateProduct(editingProduct.id, payload);
        showToast('Product updated', 'success', res.message);
      } else {
        const res = await api.createProduct(payload);
        showToast('Product created', 'success', res.message);
      }
      setProductModalOpen(false);
      setEditingProduct(null);
      await fetchAllData();
    } finally {
      setSaving(false);
    }
  };

  // Delete Product
  const handleConfirmDeleteProduct = async () => {
    if (!deleteProductTarget) return;
    setSaving(true);
    try {
      await api.deleteProduct(deleteProductTarget.id);
      showToast('Product deleted', 'success', `${deleteProductTarget.name} removed from catalog.`);
      if (selectedProduct?.id === deleteProductTarget.id) {
        setSelectedProduct(null);
      }
      setDeleteProductTarget(null);
      await fetchAllData();
    } catch (err) {
      showToast(
        'Cannot delete product',
        'error',
        err instanceof Error ? err.message : 'Delete failed'
      );
    } finally {
      setSaving(false);
    }
  };

  // Generate PO & optionally open WhatsApp Preview
  const handleGeneratePO = async (payload: {
    supplier_id: number;
    status: 'Draft' | 'Pending' | 'Sent';
    notes?: string;
    items: Array<{ product_id: number; quantity_ordered: number; unit_cost: number }>;
    openWhatsApp?: boolean;
  }) => {
    setSaving(true);
    try {
      const res = await api.generatePurchaseOrder({
        supplier_id: payload.supplier_id,
        status: payload.status,
        notes: payload.notes,
        items: payload.items,
      });
      await fetchAllData();
      showToast('Purchase order generated', 'success', res.message);
      setOrderModalWhatsApp(Boolean(payload.openWhatsApp));
      setActiveOrder(res.data);
      return res.data;
    } catch (err) {
      showToast(
        'Failed to generate purchase order',
        'error',
        err instanceof Error ? err.message : 'Order generation error'
      );
    } finally {
      setSaving(false);
    }
  };

  // Update PO status / Receive Stock
  const handleUpdateOrder = async (
    orderId: number,
    payload: {
      status?: PurchaseOrderStatus;
      received_items?: Array<{ product_id: number; quantity_received: number }>;
    }
  ) => {
    setSaving(true);
    try {
      const res = await api.updatePurchaseOrder(orderId, payload);
      setActiveOrder(res.data);
      await fetchAllData();
      showToast('Purchase order updated', 'success', res.message);
    } catch (err) {
      showToast(
        'Order update failed',
        'error',
        err instanceof Error ? err.message : 'Unable to update purchase order'
      );
    } finally {
      setSaving(false);
    }
  };

  // Suppliers CRUD
  const handleCreateSupplier = async (payload: {
    name: string;
    contact_person: string;
    phone: string;
    email: string | null;
    address: string | null;
  }) => {
    setSaving(true);
    try {
      const res = await api.createSupplier(payload);
      showToast('Supplier added', 'success', res.message);
      await fetchAllData();
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateSupplier = async (
    id: number,
    payload: {
      name: string;
      contact_person: string;
      phone: string;
      email: string | null;
      address: string | null;
    }
  ) => {
    setSaving(true);
    try {
      const res = await api.updateSupplier(id, payload);
      showToast('Supplier updated', 'success', res.message);
      await fetchAllData();
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDeleteSupplier = async () => {
    if (!deleteSupplierTarget) return;
    setSaving(true);
    try {
      await api.deleteSupplier(deleteSupplierTarget.id);
      showToast('Supplier deleted', 'success', `${deleteSupplierTarget.name} removed.`);
      setDeleteSupplierTarget(null);
      await fetchAllData();
    } catch (err) {
      showToast(
        'Cannot delete supplier',
        'error',
        err instanceof Error ? err.message : 'Delete failed'
      );
    } finally {
      setSaving(false);
    }
  };

  // Settings & Demo Reset
  const handleSaveSettings = async (payload: Partial<StoreSettings>) => {
    setSaving(true);
    try {
      const res = await api.updateSettings(payload);
      setSettings(res.data);
      showToast('Store settings saved', 'success', res.message);
      await fetchAllData();
    } catch (err) {
      showToast(
        'Failed to save settings',
        'error',
        err instanceof Error ? err.message : 'Error saving settings'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleResetDemo = async () => {
    setSaving(true);
    try {
      const res = await api.resetDemoData();
      setResetDemoConfirmOpen(false);
      await fetchAllData();
      showToast('Demo dataset restored', 'success', res.message);
    } catch (err) {
      showToast(
        'Reset failed',
        'error',
        err instanceof Error ? err.message : 'Unable to reset demo dataset'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleSyncNow = async (forceOperationId?: string) => {
    const res = await runSync(forceOperationId);
    if (res.synced > 0) {
      showToast('Sync complete', 'success', `${res.synced} operation(s) confirmed by server.`);
      await fetchAllData();
    } else if (res.conflicts > 0) {
      showToast(
        'Sync conflict detected',
        'warning',
        'Review server vs. local stock in the Sync Queue dialog.'
      );
    } else if (res.failed > 0) {
      showToast('Sync failed', 'error', 'Some queued operations could not reach the server.');
    }
    return res;
  };

  const lowStockBadgeCount =
    (summary?.low_stock_count || 0) + (summary?.out_of_stock_count || 0);
  const expiringBadgeCount =
    (summary?.expiring_products_count || 0) + (summary?.expired_products_count || 0);

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      <CursorFollower />

      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed((c) => !c)}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        storeName={summary?.store_name || settings?.store_name || 'StockSherpa'}
        lowStockCount={lowStockBadgeCount}
        expiringCount={expiringBadgeCount}
        onQuickAddProduct={() => {
          setEditingProduct(null);
          setProductModalOpen(true);
        }}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar
          currentPage={currentPage}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onOpenScanner={() => setScannerOpen(true)}
          onAddProduct={() => {
            setEditingProduct(null);
            setProductModalOpen(true);
          }}
          isOnline={isOnline}
          syncState={syncState}
          queue={queue}
          onSyncNow={handleSyncNow}
          onDiscardOp={discardOperation}
        />

        <main className="mx-auto w-full max-w-[1440px] flex-1 p-4 sm:p-6">
          {currentPage === 'dashboard' && (
            <DashboardPage
              summary={summary}
              analytics={analytics}
              loading={loading}
              error={loadError}
              onRetry={() => void fetchAllData()}
              onNavigate={setCurrentPage}
              onOpenScanner={() => setScannerOpen(true)}
              onAddProduct={() => {
                setEditingProduct(null);
                setProductModalOpen(true);
              }}
              onOpenOrder={(order) => {
                setOrderModalWhatsApp(false);
                setActiveOrder(order);
              }}
            />
          )}

          {currentPage === 'catalog' && (
            <CatalogPage
              products={products}
              loading={loading}
              error={loadError}
              onRetry={() => void fetchAllData()}
              onAddProduct={() => {
                setEditingProduct(null);
                setProductModalOpen(true);
              }}
              onEditProduct={(p) => {
                setEditingProduct(p);
                setProductModalOpen(true);
              }}
              onDeleteProduct={(p) => setDeleteProductTarget(p)}
              onSelectProduct={(p) => setSelectedProduct(p)}
              onQuickAdjust={async (p, d, t, r) => {
                await handleAdjustStock(p, d, t, r);
              }}
              onOpenCustomAdjust={(p) => setAdjustingProduct(p)}
            />
          )}

          {currentPage === 'reorder' && (
            <ReorderPage
              suggestions={suggestions}
              purchaseOrders={purchaseOrders}
              suppliers={suppliers}
              loading={loading}
              saving={saving}
              onGeneratePO={handleGeneratePO}
              onOpenOrder={(order, showWA = false) => {
                setOrderModalWhatsApp(showWA);
                setActiveOrder(order);
              }}
            />
          )}

          {currentPage === 'expiry' && (
            <ExpiryPage
              records={expiryRecords}
              products={products}
              loading={loading}
              onQuickAdjust={async (p, d, t, r) => {
                await handleAdjustStock(p, d, t, r);
              }}
            />
          )}

          {currentPage === 'suppliers' && (
            <SuppliersPage
              suppliers={suppliers}
              loading={loading}
              saving={saving}
              onCreateSupplier={handleCreateSupplier}
              onUpdateSupplier={handleUpdateSupplier}
              onDeleteSupplier={(s) => setDeleteSupplierTarget(s)}
              onOpenOrder={(order) => {
                setOrderModalWhatsApp(false);
                setActiveOrder(order);
              }}
            />
          )}

          {currentPage === 'movements' && (
            <MovementsPage movements={movements} products={products} loading={loading} />
          )}

          {currentPage === 'settings' && (
            <SettingsPage
              settings={settings}
              saving={saving}
              onSaveSettings={handleSaveSettings}
              onRequestResetDemo={() => setResetDemoConfirmOpen(true)}
            />
          )}
        </main>
      </div>

      {/* Interactive Modals & Drawers */}
      <ProductModal
        open={productModalOpen}
        product={editingProduct}
        suppliers={suppliers}
        saving={saving}
        onClose={() => {
          setProductModalOpen(false);
          setEditingProduct(null);
        }}
        onSave={handleSaveProduct}
      />

      <ProductDetailDrawer
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onEdit={(p) => {
          setEditingProduct(p);
          setProductModalOpen(true);
        }}
        onDelete={(p) => setDeleteProductTarget(p)}
        onQuickAdjust={async (p, d, t, r) => {
          await handleAdjustStock(p, d, t, r);
        }}
        onOpenCustomAdjust={(p) => setAdjustingProduct(p)}
      />

      <QuickAdjustModal
        open={Boolean(adjustingProduct)}
        product={adjustingProduct}
        saving={saving}
        onClose={() => setAdjustingProduct(null)}
        onSubmit={async (p, d, t, r) => {
          await handleAdjustStock(p, d, t, r);
        }}
      />

      <BarcodeScannerModal
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onQuickAdjust={handleAdjustStock}
      />

      <PurchaseOrderModal
        order={activeOrder}
        saving={saving}
        initialShowWhatsApp={orderModalWhatsApp}
        onClose={() => {
          setActiveOrder(null);
          setOrderModalWhatsApp(false);
        }}
        onUpdateStatus={handleUpdateOrder}
      />

      <ConfirmDialog
        open={Boolean(deleteProductTarget)}
        title="Delete Product"
        message={`Are you sure you want to permanently remove "${deleteProductTarget?.name}" (${deleteProductTarget?.sku}) from your store catalog?`}
        confirmLabel="Delete Product"
        loading={saving}
        onCancel={() => setDeleteProductTarget(null)}
        onConfirm={() => void handleConfirmDeleteProduct()}
      />

      <ConfirmDialog
        open={Boolean(deleteSupplierTarget)}
        title="Remove Supplier"
        message={`Are you sure you want to remove "${deleteSupplierTarget?.name}" from your supplier directory?`}
        confirmLabel="Remove Supplier"
        loading={saving}
        onCancel={() => setDeleteSupplierTarget(null)}
        onConfirm={() => void handleConfirmDeleteSupplier()}
      />

      <ConfirmDialog
        open={resetDemoConfirmOpen}
        title="Restore 60 Sample Kirana Products"
        message="This will reset all products, stock movements, and purchase orders to the original 60-product kirana sample dataset. Custom store additions will be replaced."
        confirmLabel="Restore Sample Dataset"
        destructive={false}
        loading={saving}
        onCancel={() => setResetDemoConfirmOpen(false)}
        onConfirm={() => void handleResetDemo()}
      />

      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
