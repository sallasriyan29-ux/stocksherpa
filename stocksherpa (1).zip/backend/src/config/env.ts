import dotenv from 'dotenv';
import path from 'path';

dotenv.config();

export const env = {
  port: Number(process.env.PORT || 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  dbPath: process.env.DB_PATH || path.resolve(process.cwd(), 'data', 'stocksherpa.db'),
  corsOrigin: process.env.CORS_ORIGIN || '*',
  defaultStoreName: process.env.DEFAULT_STORE_NAME || 'Shree Ganesh Kirana & General Store',
};
