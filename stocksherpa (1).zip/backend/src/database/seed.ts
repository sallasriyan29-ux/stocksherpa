import type Database from 'better-sqlite3';
import { env } from '../config/env.ts';

function addDaysIso(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

interface SeedProduct {
  name: string;
  sku: string;
  barcode: string;
  category: 'Grains' | 'Dairy' | 'Snacks' | 'Personal Care';
  cost_price: number;
  selling_price: number;
  current_quantity: number;
  minimum_stock_threshold: number;
  target_stock_level: number;
  unit: string;
  supplierIndex: number;
  expiryDaysOffset: number | null;
}

export function seedDatabase(db: Database.Database, forceReset = false): { seeded: boolean; productsCount: number } {
  const existingCountRow = db.prepare('SELECT COUNT(*) as count FROM products').get() as { count: number };
  if (existingCountRow.count > 0 && !forceReset) {
    return { seeded: false, productsCount: existingCountRow.count };
  }

  const runSeed = db.transaction(() => {
    if (forceReset) {
      db.exec(`
        DELETE FROM stock_movements;
        DELETE FROM purchase_order_items;
        DELETE FROM purchase_orders;
        DELETE FROM expiry_records;
        DELETE FROM products;
        DELETE FROM suppliers;
        DELETE FROM categories;
        DELETE FROM app_settings;
      `);
    }

    // Categories
    const categories = [
      ['Grains', 'Staple grains, pulses, flours, rice, sugar, and salts'],
      ['Dairy', 'Fresh milk, curd, paneer, butter, cheese, and ghee'],
      ['Snacks', 'Biscuits, instant noodles, namkeen, chips, and packaged snacks'],
      ['Personal Care', 'Soaps, shampoos, oral care, detergents, and hygiene essentials'],
    ];
    const insertCat = db.prepare('INSERT OR IGNORE INTO categories (name, description) VALUES (?, ?)');
    for (const [name, desc] of categories) {
      insertCat.run(name, desc);
    }

    // Settings
    const insertSetting = db.prepare(
      `INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))`
    );
    insertSetting.run('store_name', env.defaultStoreName);
    insertSetting.run('owner_name', 'Rajesh Sharma');
    insertSetting.run('store_phone', '+91 98201 44510');
    insertSetting.run('store_address', 'Shop 14, Station Road, Andheri West, Mumbai 400058');
    insertSetting.run('currency_symbol', '₹');

    // Suppliers (5 realistic Indian Kirana distributors)
    const suppliersData = [
      {
        name: 'Annapurna Wholesale Grains',
        contact_person: 'Mahesh Agrawal',
        phone: '+91 98204 55120',
        email: 'orders@annapurnagrains.in',
        address: 'Plot 42, APMC Grain Market, Vashi, Navi Mumbai',
      },
      {
        name: 'Gokul Fresh Dairy Distributors',
        contact_person: 'Vikram Patel',
        phone: '+91 98211 77340',
        email: 'dispatch@gokuldairy.co.in',
        address: 'Unit 9, Goregaon Milk Colony, Mumbai',
      },
      {
        name: 'Mahavir FMCG & Snacks Agency',
        contact_person: 'Suresh Jain',
        phone: '+91 98670 31890',
        email: 'sales@mahavirfmcg.in',
        address: 'Gala 18, Saki Naka Industrial Estate, Mumbai',
      },
      {
        name: 'Swastik Personal Care Depot',
        contact_person: 'Nitin Kulkarni',
        phone: '+91 97690 88215',
        email: 'supply@swastikcare.in',
        address: '214, Bhiwandi Logistics Park, Thane',
      },
      {
        name: 'Bharati General Traders',
        contact_person: 'Deepak Gupta',
        phone: '+91 99203 19450',
        email: 'bharati.traders@gmail.com',
        address: '12, Crawford Market Wholesale Lane, Mumbai',
      },
    ];

    const insertSupplier = db.prepare(`
      INSERT INTO suppliers (name, contact_person, phone, email, address, is_sample)
      VALUES (?, ?, ?, ?, ?, 1)
    `);
    const supplierIds: number[] = [];
    for (const s of suppliersData) {
      const info = insertSupplier.run(s.name, s.contact_person, s.phone, s.email, s.address);
      supplierIds.push(Number(info.lastInsertRowid));
    }

    // 60 Realistic Indian Kirana Products
    const productsData: SeedProduct[] = [
      // GRAINS (18 items)
      {
        name: 'Aashirvaad Shudh Chakki Atta (5kg)',
        sku: 'GRN-ATT-001',
        barcode: '8901725123011',
        category: 'Grains',
        cost_price: 215,
        selling_price: 255,
        current_quantity: 6,
        minimum_stock_threshold: 4,
        target_stock_level: 20,
        unit: 'bag',
        supplierIndex: 0,
        expiryDaysOffset: 95,
      },
      {
        name: 'India Gate Basmati Rice Classic (1kg)',
        sku: 'GRN-RIC-002',
        barcode: '8901595100014',
        category: 'Grains',
        cost_price: 118,
        selling_price: 145,
        current_quantity: 24,
        minimum_stock_threshold: 8,
        target_stock_level: 30,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 240,
      },
      {
        name: 'Daawat Rozana Regular Rice (5kg)',
        sku: 'GRN-RIC-003',
        barcode: '8901595200028',
        category: 'Grains',
        cost_price: 310,
        selling_price: 365,
        current_quantity: 12,
        minimum_stock_threshold: 5,
        target_stock_level: 18,
        unit: 'bag',
        supplierIndex: 0,
        expiryDaysOffset: 210,
      },
      {
        name: 'Tata Sampann Toor Dal (1kg)',
        sku: 'GRN-DAL-004',
        barcode: '8904043901015',
        category: 'Grains',
        cost_price: 148,
        selling_price: 178,
        current_quantity: 18,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 160,
      },
      {
        name: 'Tata Sampann Moong Dal Yellow (1kg)',
        sku: 'GRN-DAL-005',
        barcode: '8904043901022',
        category: 'Grains',
        cost_price: 126,
        selling_price: 152,
        current_quantity: 14,
        minimum_stock_threshold: 5,
        target_stock_level: 20,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 150,
      },
      {
        name: 'Organic Chana Dal (1kg)',
        sku: 'GRN-DAL-006',
        barcode: '8904043901039',
        category: 'Grains',
        cost_price: 88,
        selling_price: 110,
        current_quantity: 3,
        minimum_stock_threshold: 6,
        target_stock_level: 20,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 145,
      },
      {
        name: 'Madhur Pure Refined Sugar (1kg)',
        sku: 'GRN-SUG-007',
        barcode: '8906009870012',
        category: 'Grains',
        cost_price: 44,
        selling_price: 52,
        current_quantity: 35,
        minimum_stock_threshold: 12,
        target_stock_level: 45,
        unit: 'pack',
        supplierIndex: 4,
        expiryDaysOffset: 300,
      },
      {
        name: 'Tata Salt Iodized (1kg)',
        sku: 'GRN-SLT-008',
        barcode: '8904043900018',
        category: 'Grains',
        cost_price: 22,
        selling_price: 28,
        current_quantity: 42,
        minimum_stock_threshold: 15,
        target_stock_level: 50,
        unit: 'pack',
        supplierIndex: 4,
        expiryDaysOffset: null,
      },
      {
        name: 'Fortune Chakki Fresh Besan (500g)',
        sku: 'GRN-BSN-009',
        barcode: '8901552010019',
        category: 'Grains',
        cost_price: 48,
        selling_price: 60,
        current_quantity: 16,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 75,
      },
      {
        name: 'Rajdhani Sooji / Rava (500g)',
        sku: 'GRN-SOJ-010',
        barcode: '8906010320018',
        category: 'Grains',
        cost_price: 32,
        selling_price: 42,
        current_quantity: 19,
        minimum_stock_threshold: 6,
        target_stock_level: 25,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 85,
      },
      {
        name: 'Tata Sampann Poha Thick (500g)',
        sku: 'GRN-POH-011',
        barcode: '8904043904016',
        category: 'Grains',
        cost_price: 38,
        selling_price: 48,
        current_quantity: 22,
        minimum_stock_threshold: 8,
        target_stock_level: 28,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 110,
      },
      {
        name: 'Masoor Dal Red Split (1kg)',
        sku: 'GRN-DAL-012',
        barcode: '8904043901053',
        category: 'Grains',
        cost_price: 96,
        selling_price: 118,
        current_quantity: 11,
        minimum_stock_threshold: 5,
        target_stock_level: 18,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 180,
      },
      {
        name: 'Urad Dal White Whole (1kg)',
        sku: 'GRN-DAL-013',
        barcode: '8904043901060',
        category: 'Grains',
        cost_price: 135,
        selling_price: 162,
        current_quantity: 0,
        minimum_stock_threshold: 5,
        target_stock_level: 16,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 165,
      },
      {
        name: 'Rajma Chitra Premium (500g)',
        sku: 'GRN-RJM-014',
        barcode: '8904043901077',
        category: 'Grains',
        cost_price: 78,
        selling_price: 96,
        current_quantity: 15,
        minimum_stock_threshold: 5,
        target_stock_level: 20,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 200,
      },
      {
        name: 'Kabuli Chana Bold (500g)',
        sku: 'GRN-CHN-015',
        barcode: '8904043901084',
        category: 'Grains',
        cost_price: 82,
        selling_price: 102,
        current_quantity: 9,
        minimum_stock_threshold: 4,
        target_stock_level: 15,
        unit: 'pack',
        supplierIndex: 0,
        expiryDaysOffset: 195,
      },
      {
        name: 'Fortune Sunlite Refined Oil (1L)',
        sku: 'GRN-OIL-016',
        barcode: '8901552020018',
        category: 'Grains',
        cost_price: 124,
        selling_price: 145,
        current_quantity: 20,
        minimum_stock_threshold: 8,
        target_stock_level: 30,
        unit: 'pouch',
        supplierIndex: 4,
        expiryDaysOffset: 170,
      },
      {
        name: 'Saffola Gold Cooking Oil (1L)',
        sku: 'GRN-OIL-017',
        barcode: '8901088001014',
        category: 'Grains',
        cost_price: 152,
        selling_price: 179,
        current_quantity: 4,
        minimum_stock_threshold: 6,
        target_stock_level: 18,
        unit: 'pouch',
        supplierIndex: 4,
        expiryDaysOffset: 160,
      },
      {
        name: 'Pillsbury Multigrain Atta (5kg)',
        sku: 'GRN-ATT-018',
        barcode: '8901719100017',
        category: 'Grains',
        cost_price: 245,
        selling_price: 290,
        current_quantity: 8,
        minimum_stock_threshold: 4,
        target_stock_level: 14,
        unit: 'bag',
        supplierIndex: 0,
        expiryDaysOffset: 65,
      },

      // DAIRY (12 items)
      {
        name: 'Amul Taaza Toned Milk (1L)',
        sku: 'DRY-MLK-019',
        barcode: '8901262010016',
        category: 'Dairy',
        cost_price: 50,
        selling_price: 54,
        current_quantity: 28,
        minimum_stock_threshold: 12,
        target_stock_level: 40,
        unit: 'pouch',
        supplierIndex: 1,
        expiryDaysOffset: 2,
      },
      {
        name: 'Amul Gold Full Cream Milk (500ml)',
        sku: 'DRY-MLK-020',
        barcode: '8901262010023',
        category: 'Dairy',
        cost_price: 31,
        selling_price: 34,
        current_quantity: 22,
        minimum_stock_threshold: 10,
        target_stock_level: 36,
        unit: 'pouch',
        supplierIndex: 1,
        expiryDaysOffset: 3,
      },
      {
        name: 'Amul Masti Dahi / Curd (400g)',
        sku: 'DRY-CRD-021',
        barcode: '8901262020015',
        category: 'Dairy',
        cost_price: 30,
        selling_price: 35,
        current_quantity: 14,
        minimum_stock_threshold: 6,
        target_stock_level: 20,
        unit: 'cup',
        supplierIndex: 1,
        expiryDaysOffset: 5,
      },
      {
        name: 'Amul Pasteurised Butter (100g)',
        sku: 'DRY-BTR-022',
        barcode: '8901262030014',
        category: 'Dairy',
        cost_price: 52,
        selling_price: 60,
        current_quantity: 18,
        minimum_stock_threshold: 8,
        target_stock_level: 25,
        unit: 'pack',
        supplierIndex: 1,
        expiryDaysOffset: 26,
      },
      {
        name: 'Amul Processed Cheese Slices (200g)',
        sku: 'DRY-CHS-023',
        barcode: '8901262040013',
        category: 'Dairy',
        cost_price: 118,
        selling_price: 138,
        current_quantity: 9,
        minimum_stock_threshold: 4,
        target_stock_level: 16,
        unit: 'pack',
        supplierIndex: 1,
        expiryDaysOffset: 19,
      },
      {
        name: 'Amul Fresh Malai Paneer (200g)',
        sku: 'DRY-PNR-024',
        barcode: '8901262050012',
        category: 'Dairy',
        cost_price: 78,
        selling_price: 92,
        current_quantity: 5,
        minimum_stock_threshold: 6,
        target_stock_level: 18,
        unit: 'pack',
        supplierIndex: 1,
        expiryDaysOffset: 6,
      },
      {
        name: 'Mother Dairy Classic Curd (200g)',
        sku: 'DRY-CRD-025',
        barcode: '8901648010018',
        category: 'Dairy',
        cost_price: 19,
        selling_price: 23,
        current_quantity: 4,
        minimum_stock_threshold: 5,
        target_stock_level: 15,
        unit: 'cup',
        supplierIndex: 1,
        expiryDaysOffset: -1,
      },
      {
        name: 'Amul Pure Cow Ghee (500ml)',
        sku: 'DRY-GHE-026',
        barcode: '8901262060011',
        category: 'Dairy',
        cost_price: 295,
        selling_price: 335,
        current_quantity: 10,
        minimum_stock_threshold: 4,
        target_stock_level: 15,
        unit: 'jar',
        supplierIndex: 1,
        expiryDaysOffset: 135,
      },
      {
        name: 'Amul Kool Elaichi Flavoured Milk (180ml)',
        sku: 'DRY-MLK-027',
        barcode: '8901262070010',
        category: 'Dairy',
        cost_price: 20,
        selling_price: 25,
        current_quantity: 25,
        minimum_stock_threshold: 10,
        target_stock_level: 36,
        unit: 'bottle',
        supplierIndex: 1,
        expiryDaysOffset: 14,
      },
      {
        name: 'Amul Mozzarella Diced Cheese (200g)',
        sku: 'DRY-CHS-028',
        barcode: '8901262040020',
        category: 'Dairy',
        cost_price: 112,
        selling_price: 130,
        current_quantity: 0,
        minimum_stock_threshold: 4,
        target_stock_level: 12,
        unit: 'pack',
        supplierIndex: 1,
        expiryDaysOffset: 24,
      },
      {
        name: 'Gowardhan Fresh Paneer (200g)',
        sku: 'DRY-PNR-029',
        barcode: '8906001020019',
        category: 'Dairy',
        cost_price: 80,
        selling_price: 95,
        current_quantity: 7,
        minimum_stock_threshold: 5,
        target_stock_level: 14,
        unit: 'pack',
        supplierIndex: 1,
        expiryDaysOffset: 9,
      },
      {
        name: 'Amul Fresh Cream (250ml)',
        sku: 'DRY-CRM-030',
        barcode: '8901262080019',
        category: 'Dairy',
        cost_price: 58,
        selling_price: 68,
        current_quantity: 11,
        minimum_stock_threshold: 5,
        target_stock_level: 16,
        unit: 'pack',
        supplierIndex: 1,
        expiryDaysOffset: 42,
      },

      // SNACKS (16 items)
      {
        name: 'Maggi 2-Minute Masala Noodles (70g)',
        sku: 'SNK-NDL-031',
        barcode: '8901058851014',
        category: 'Snacks',
        cost_price: 11.5,
        selling_price: 14,
        current_quantity: 48,
        minimum_stock_threshold: 15,
        target_stock_level: 60,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 180,
      },
      {
        name: 'Maggi Family Pack 4-in-1 (280g)',
        sku: 'SNK-NDL-032',
        barcode: '8901058851021',
        category: 'Snacks',
        cost_price: 46,
        selling_price: 56,
        current_quantity: 15,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 175,
      },
      {
        name: 'Parle-G Original Gluco Biscuits (800g)',
        sku: 'SNK-BSC-033',
        barcode: '8901719110016',
        category: 'Snacks',
        cost_price: 72,
        selling_price: 85,
        current_quantity: 20,
        minimum_stock_threshold: 8,
        target_stock_level: 30,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 120,
      },
      {
        name: 'Parle-G Gold Biscuits (100g)',
        sku: 'SNK-BSC-034',
        barcode: '8901719110023',
        category: 'Snacks',
        cost_price: 8.5,
        selling_price: 10,
        current_quantity: 55,
        minimum_stock_threshold: 20,
        target_stock_level: 72,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 130,
      },
      {
        name: 'Britannia Good Day Cashew Cookies (200g)',
        sku: 'SNK-BSC-035',
        barcode: '8901063091016',
        category: 'Snacks',
        cost_price: 34,
        selling_price: 42,
        current_quantity: 17,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 105,
      },
      {
        name: 'Britannia Marie Gold Biscuits (250g)',
        sku: 'SNK-BSC-036',
        barcode: '8901063092013',
        category: 'Snacks',
        cost_price: 29,
        selling_price: 35,
        current_quantity: 21,
        minimum_stock_threshold: 8,
        target_stock_level: 28,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 98,
      },
      {
        name: 'Kurkure Masala Munch (75g)',
        sku: 'SNK-CHP-037',
        barcode: '8901491101011',
        category: 'Snacks',
        cost_price: 16,
        selling_price: 20,
        current_quantity: 30,
        minimum_stock_threshold: 12,
        target_stock_level: 40,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 72,
      },
      {
        name: 'Lays India Magic Masala Chips (50g)',
        sku: 'SNK-CHP-038',
        barcode: '8901491102018',
        category: 'Snacks',
        cost_price: 16,
        selling_price: 20,
        current_quantity: 26,
        minimum_stock_threshold: 12,
        target_stock_level: 40,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 68,
      },
      {
        name: 'Lays Classic Salted Chips (50g)',
        sku: 'SNK-CHP-039',
        barcode: '8901491102025',
        category: 'Snacks',
        cost_price: 16,
        selling_price: 20,
        current_quantity: 4,
        minimum_stock_threshold: 10,
        target_stock_level: 36,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 60,
      },
      {
        name: 'Haldiram Aloo Bhujia Namkeen (200g)',
        sku: 'SNK-NMK-040',
        barcode: '8904063201010',
        category: 'Snacks',
        cost_price: 45,
        selling_price: 55,
        current_quantity: 14,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 88,
      },
      {
        name: 'Haldiram Khatta Meetha Mixture (200g)',
        sku: 'SNK-NMK-041',
        barcode: '8904063201027',
        category: 'Snacks',
        cost_price: 42,
        selling_price: 52,
        current_quantity: 11,
        minimum_stock_threshold: 5,
        target_stock_level: 20,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 80,
      },
      {
        name: 'Bikaji Bikaneri Bhujia (400g)',
        sku: 'SNK-NMK-042',
        barcode: '8904022901012',
        category: 'Snacks',
        cost_price: 88,
        selling_price: 108,
        current_quantity: 9,
        minimum_stock_threshold: 4,
        target_stock_level: 15,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 28,
      },
      {
        name: 'Cadbury Oreo Vanilla Creme (120g)',
        sku: 'SNK-BSC-043',
        barcode: '7622201420017',
        category: 'Snacks',
        cost_price: 28,
        selling_price: 35,
        current_quantity: 18,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 115,
      },
      {
        name: 'Sunfeast Dark Fantasy Choco Fills (75g)',
        sku: 'SNK-BSC-044',
        barcode: '8901725110011',
        category: 'Snacks',
        cost_price: 32,
        selling_price: 40,
        current_quantity: 12,
        minimum_stock_threshold: 5,
        target_stock_level: 20,
        unit: 'pack',
        supplierIndex: 2,
        expiryDaysOffset: 110,
      },
      {
        name: 'Tata Tea Gold (250g)',
        sku: 'SNK-BEV-045',
        barcode: '8901052010011',
        category: 'Snacks',
        cost_price: 125,
        selling_price: 148,
        current_quantity: 16,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'pack',
        supplierIndex: 4,
        expiryDaysOffset: 250,
      },
      {
        name: 'Nescafe Classic Instant Coffee (50g)',
        sku: 'SNK-BEV-046',
        barcode: '8901058860016',
        category: 'Snacks',
        cost_price: 145,
        selling_price: 175,
        current_quantity: 10,
        minimum_stock_threshold: 4,
        target_stock_level: 16,
        unit: 'jar',
        supplierIndex: 4,
        expiryDaysOffset: 290,
      },

      // PERSONAL CARE (14 items)
      {
        name: 'Lifebuoy Total 10 Bathing Soap (125g)',
        sku: 'PRC-SOP-047',
        barcode: '8901030701016',
        category: 'Personal Care',
        cost_price: 29,
        selling_price: 36,
        current_quantity: 32,
        minimum_stock_threshold: 12,
        target_stock_level: 45,
        unit: 'bar',
        supplierIndex: 3,
        expiryDaysOffset: 420,
      },
      {
        name: 'Dove Cream Beauty Bathing Bar (100g)',
        sku: 'PRC-SOP-048',
        barcode: '8901030702013',
        category: 'Personal Care',
        cost_price: 54,
        selling_price: 65,
        current_quantity: 18,
        minimum_stock_threshold: 8,
        target_stock_level: 28,
        unit: 'bar',
        supplierIndex: 3,
        expiryDaysOffset: 380,
      },
      {
        name: 'Dettol Original Germ Protection Soap (125g)',
        sku: 'PRC-SOP-049',
        barcode: '8901396310013',
        category: 'Personal Care',
        cost_price: 34,
        selling_price: 42,
        current_quantity: 24,
        minimum_stock_threshold: 10,
        target_stock_level: 36,
        unit: 'bar',
        supplierIndex: 3,
        expiryDaysOffset: 400,
      },
      {
        name: 'Clinic Plus Strong & Long Shampoo (175ml)',
        sku: 'PRC-SHM-050',
        barcode: '8901030711015',
        category: 'Personal Care',
        cost_price: 88,
        selling_price: 108,
        current_quantity: 12,
        minimum_stock_threshold: 5,
        target_stock_level: 20,
        unit: 'bottle',
        supplierIndex: 3,
        expiryDaysOffset: 360,
      },
      {
        name: 'Head & Shoulders Cool Menthol Shampoo (180ml)',
        sku: 'PRC-SHM-051',
        barcode: '4987176030016',
        category: 'Personal Care',
        cost_price: 158,
        selling_price: 192,
        current_quantity: 3,
        minimum_stock_threshold: 5,
        target_stock_level: 16,
        unit: 'bottle',
        supplierIndex: 3,
        expiryDaysOffset: 340,
      },
      {
        name: 'Colgate Strong Teeth Toothpaste (150g)',
        sku: 'PRC-ORL-052',
        barcode: '8901314010018',
        category: 'Personal Care',
        cost_price: 82,
        selling_price: 98,
        current_quantity: 22,
        minimum_stock_threshold: 8,
        target_stock_level: 30,
        unit: 'tube',
        supplierIndex: 3,
        expiryDaysOffset: 310,
      },
      {
        name: 'Pepsodent Germicheck Toothpaste (150g)',
        sku: 'PRC-ORL-053',
        barcode: '8901030721014',
        category: 'Personal Care',
        cost_price: 76,
        selling_price: 92,
        current_quantity: 14,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'tube',
        supplierIndex: 3,
        expiryDaysOffset: 295,
      },
      {
        name: 'Colgate ZigZag Medium Toothbrush',
        sku: 'PRC-ORL-054',
        barcode: '8901314020017',
        category: 'Personal Care',
        cost_price: 22,
        selling_price: 30,
        current_quantity: 28,
        minimum_stock_threshold: 10,
        target_stock_level: 40,
        unit: 'pcs',
        supplierIndex: 3,
        expiryDaysOffset: null,
      },
      {
        name: 'Surf Excel Easy Wash Detergent (1kg)',
        sku: 'PRC-DET-055',
        barcode: '8901030731013',
        category: 'Personal Care',
        cost_price: 112,
        selling_price: 134,
        current_quantity: 15,
        minimum_stock_threshold: 6,
        target_stock_level: 24,
        unit: 'pack',
        supplierIndex: 3,
        expiryDaysOffset: 450,
      },
      {
        name: 'Tide Plus Jasmine & Rose Detergent (1kg)',
        sku: 'PRC-DET-056',
        barcode: '4902430500012',
        category: 'Personal Care',
        cost_price: 104,
        selling_price: 125,
        current_quantity: 13,
        minimum_stock_threshold: 6,
        target_stock_level: 22,
        unit: 'pack',
        supplierIndex: 3,
        expiryDaysOffset: 430,
      },
      {
        name: 'Dettol Liquid Handwash Refill Pouch (750ml)',
        sku: 'PRC-HND-057',
        barcode: '8901396320012',
        category: 'Personal Care',
        cost_price: 94,
        selling_price: 115,
        current_quantity: 11,
        minimum_stock_threshold: 5,
        target_stock_level: 18,
        unit: 'pouch',
        supplierIndex: 3,
        expiryDaysOffset: 270,
      },
      {
        name: 'Savlon Moisture Shield Handwash (200ml)',
        sku: 'PRC-HND-058',
        barcode: '8901725140018',
        category: 'Personal Care',
        cost_price: 68,
        selling_price: 85,
        current_quantity: 0,
        minimum_stock_threshold: 4,
        target_stock_level: 14,
        unit: 'bottle',
        supplierIndex: 3,
        expiryDaysOffset: 240,
      },
      {
        name: 'Parachute Pure Coconut Hair Oil (200ml)',
        sku: 'PRC-OIL-059',
        barcode: '8901088010016',
        category: 'Personal Care',
        cost_price: 78,
        selling_price: 94,
        current_quantity: 19,
        minimum_stock_threshold: 7,
        target_stock_level: 25,
        unit: 'bottle',
        supplierIndex: 4,
        expiryDaysOffset: 365,
      },
      {
        name: 'Nivea Soft Light Moisturising Cream (100ml)',
        sku: 'PRC-CRM-060',
        barcode: '4005808730018',
        category: 'Personal Care',
        cost_price: 138,
        selling_price: 168,
        current_quantity: 8,
        minimum_stock_threshold: 4,
        target_stock_level: 15,
        unit: 'jar',
        supplierIndex: 4,
        expiryDaysOffset: 12,
      },
    ];

    const insertProduct = db.prepare(`
      INSERT INTO products (
        name, sku, barcode, category, cost_price, selling_price,
        current_quantity, minimum_stock_threshold, target_stock_level,
        unit, supplier_id, expiry_date, is_sample
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `);

    const insertMovement = db.prepare(`
      INSERT INTO stock_movements (
        product_id, movement_type, quantity_changed, previous_quantity,
        new_quantity, reason, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const insertExpiry = db.prepare(`
      INSERT INTO expiry_records (product_id, batch_code, quantity, expiry_date, notes)
      VALUES (?, ?, ?, ?, ?)
    `);

    const productIds: number[] = [];

    for (let i = 0; i < productsData.length; i++) {
      const p = productsData[i];
      const expiryDate = p.expiryDaysOffset !== null ? addDaysIso(p.expiryDaysOffset) : null;
      const supplierId = supplierIds[p.supplierIndex];

      const info = insertProduct.run(
        p.name,
        p.sku,
        p.barcode,
        p.category,
        p.cost_price,
        p.selling_price,
        p.current_quantity,
        p.minimum_stock_threshold,
        p.target_stock_level,
        p.unit,
        supplierId,
        expiryDate
      );

      const prodId = Number(info.lastInsertRowid);
      productIds.push(prodId);

      // Record initial opening stock movement
      if (p.current_quantity > 0) {
        insertMovement.run(
          prodId,
          'Supplier delivery',
          p.current_quantity,
          0,
          p.current_quantity,
          'Initial opening store inventory (Sample Seed)',
          new Date(Date.now() - (60 - i) * 3600 * 1000).toISOString()
        );
      }

      if (expiryDate) {
        insertExpiry.run(
          prodId,
          `BATCH-${String(101 + i)}`,
          p.current_quantity,
          expiryDate,
          'Primary shelf batch'
        );
      }
    }

    // Add a few realistic recent sale movements so dashboard movement feed is rich
    const recentSales = [
      { idx: 18, delta: -2, type: 'Sale', reason: 'Morning dairy counter sale' },
      { idx: 30, delta: -4, type: 'Sale', reason: 'Evening snacks rush billing' },
      { idx: 1, delta: -1, type: 'Sale', reason: 'Walk-in household purchase' },
      { idx: 46, delta: -3, type: 'Sale', reason: 'Weekly grocery basket sale' },
    ];
    for (const s of recentSales) {
      const p = productsData[s.idx];
      const prodId = productIds[s.idx];
      const prev = p.current_quantity - s.delta;
      insertMovement.run(
        prodId,
        s.type,
        s.delta,
        prev,
        p.current_quantity,
        s.reason,
        new Date(Date.now() - 1800 * 1000).toISOString()
      );
    }

    // Sample Purchase Orders (1 Pending, 1 Sent)
    const insertPO = db.prepare(`
      INSERT INTO purchase_orders (order_number, supplier_id, store_name, status, total_cost, notes, order_date)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const insertPOItem = db.prepare(`
      INSERT INTO purchase_order_items (
        purchase_order_id, product_id, product_name, sku,
        quantity_ordered, quantity_received, unit_cost, line_total
      ) VALUES (?, ?, ?, ?, ?, 0, ?, ?)
    `);

    const po1Total = 16 * 135 + 17 * 88;
    const po1 = insertPO.run(
      'PO-2026-1001',
      supplierIds[0],
      env.defaultStoreName,
      'Pending',
      po1Total,
      'Urgent pulse replenishment for weekend demand',
      new Date(Date.now() - 86400 * 1000).toISOString()
    );
    const po1Id = Number(po1.lastInsertRowid);
    insertPOItem.run(po1Id, productIds[12], productsData[12].name, productsData[12].sku, 16, 135, 16 * 135);
    insertPOItem.run(po1Id, productIds[5], productsData[5].name, productsData[5].sku, 17, 88, 17 * 88);

    const po2Total = 14 * 68 + 13 * 158;
    const po2 = insertPO.run(
      'PO-2026-1002',
      supplierIds[3],
      env.defaultStoreName,
      'Sent',
      po2Total,
      'Personal care monthly restock via WhatsApp',
      new Date(Date.now() - 43200 * 1000).toISOString()
    );
    const po2Id = Number(po2.lastInsertRowid);
    insertPOItem.run(po2Id, productIds[57], productsData[57].name, productsData[57].sku, 14, 68, 14 * 68);
    insertPOItem.run(po2Id, productIds[50], productsData[50].name, productsData[50].sku, 13, 158, 13 * 158);
  });

  runSeed();
  const finalCount = db.prepare('SELECT COUNT(*) as count FROM products').get() as { count: number };
  return { seeded: true, productsCount: finalCount.count };
}
