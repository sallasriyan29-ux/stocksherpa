import { getDb, closeDb } from './connection.ts';
import { seedDatabase } from './seed.ts';

const force = process.argv.includes('--force') || process.argv.includes('--reset');
const db = getDb();
const result = seedDatabase(db, force);
console.log(
  result.seeded
    ? `Seeded StockSherpa database with ${result.productsCount} products.`
    : `Database already has ${result.productsCount} products (pass --force to re-seed).`
);
closeDb();
