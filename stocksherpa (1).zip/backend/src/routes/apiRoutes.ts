import { Router } from 'express';
import type Database from 'better-sqlite3';
import { createControllers } from '../controllers/apiController.ts';
import { mutationRateLimiter } from '../middleware/security.ts';

export function createApiRouter(db: Database.Database): Router {
  const router = Router();
  const ctrl = createControllers(db);

  // Health
  router.get('/health', ctrl.health);

  // Products
  router.get('/products', ctrl.listProducts);
  router.get('/products/barcode/:code', ctrl.lookupBarcode);
  router.get('/products/:id', ctrl.getProduct);
  router.post('/products', mutationRateLimiter, ctrl.createProduct);
  router.put('/products/:id', mutationRateLimiter, ctrl.updateProduct);
  router.delete('/products/:id', mutationRateLimiter, ctrl.deleteProduct);

  // Stock
  router.post('/stock/adjust', mutationRateLimiter, ctrl.adjustStock);
  router.get('/stock/movements', ctrl.listMovements);
  router.get('/stock/movements/:productId', ctrl.listProductMovements);

  // Suppliers
  router.get('/suppliers', ctrl.listSuppliers);
  router.get('/suppliers/:id', ctrl.getSupplier);
  router.post('/suppliers', mutationRateLimiter, ctrl.createSupplier);
  router.put('/suppliers/:id', mutationRateLimiter, ctrl.updateSupplier);
  router.delete('/suppliers/:id', mutationRateLimiter, ctrl.deleteSupplier);

  // Purchase Orders
  router.get('/purchase-orders', ctrl.listPurchaseOrders);
  router.post('/purchase-orders', mutationRateLimiter, ctrl.generatePurchaseOrder);
  router.get('/purchase-orders/:id', ctrl.getPurchaseOrder);
  router.put('/purchase-orders/:id', mutationRateLimiter, ctrl.updatePurchaseOrder);

  // Reorder Assistant
  router.get('/reorder/suggestions', ctrl.reorderSuggestions);
  router.post('/reorder/generate', mutationRateLimiter, ctrl.generatePurchaseOrder);

  // Dashboard
  router.get('/dashboard/summary', ctrl.dashboardSummary);
  router.get('/dashboard/analytics', ctrl.dashboardAnalytics);

  // Expiry
  router.get('/expiry', ctrl.listExpiry);
  router.get('/expiry/alerts', ctrl.expiryAlerts);

  // Settings & Demo
  router.get('/settings', ctrl.getSettings);
  router.put('/settings', mutationRateLimiter, ctrl.updateSettings);
  router.post('/demo/reset', mutationRateLimiter, ctrl.resetDemoData);

  return router;
}
