import express from 'express';
import type Database from 'better-sqlite3';
import { errorHandler } from './middleware/errorHandler.ts';
import {
  buildCorsMiddleware,
  buildHelmetMiddleware,
  sanitizeBodyMiddleware,
} from './middleware/security.ts';
import { createApiRouter } from './routes/apiRoutes.ts';

export function createApiApp(db: Database.Database) {
  const app = express();

  app.use(buildHelmetMiddleware());
  app.use(buildCorsMiddleware());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));
  app.use(sanitizeBodyMiddleware);

  app.use('/api', createApiRouter(db));

  // Unmatched API routes return structured JSON 404
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'NOT_FOUND', message: 'API endpoint not found' });
  });

  app.use(errorHandler);
  return app;
}
