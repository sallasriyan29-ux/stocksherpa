import type { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';
import { AppError } from '../utils/errors.ts';

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction): void {
  if (err instanceof AppError) {
    res.status(err.statusCode).json({
      error: err.code,
      message: err.message,
      details: err.details,
    });
    return;
  }

  if (err instanceof ZodError) {
    res.status(400).json({
      error: 'VALIDATION_ERROR',
      message: err.issues.map((i) => i.message).join('; '),
      details: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
    });
    return;
  }

  if (err && typeof err === 'object' && 'code' in err) {
    const sqliteErr = err as { code?: string; message?: string };
    if (sqliteErr.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      const msg = sqliteErr.message || '';
      if (msg.includes('products.sku')) {
        res.status(409).json({ error: 'DUPLICATE_SKU', message: 'A product with this SKU already exists.' });
        return;
      }
      if (msg.includes('products.barcode')) {
        res.status(409).json({ error: 'DUPLICATE_BARCODE', message: 'A product with this barcode already exists.' });
        return;
      }
      res.status(409).json({ error: 'DUPLICATE_ENTRY', message: 'A record with this unique value already exists.' });
      return;
    }
    if (sqliteErr.code === 'SQLITE_CONSTRAINT_FOREIGNKEY') {
      res.status(409).json({
        error: 'CONSTRAINT_ERROR',
        message: 'Operation cannot complete because this record is referenced by existing orders or products.',
      });
      return;
    }
  }

  console.error('[API Error]', err);
  res.status(500).json({
    error: 'INTERNAL_SERVER_ERROR',
    message: 'An unexpected server error occurred. Please try again.',
  });
}
