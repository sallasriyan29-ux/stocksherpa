import type { Request, Response } from 'express';
import type Database from 'better-sqlite3';
import { env } from '../config/env.ts';
import { seedDatabase } from '../database/seed.ts';
import { getDashboardAnalytics, getDashboardSummary } from '../services/dashboardService.ts';
import { getExpiryAlerts, listExpiryRecords } from '../services/expiryService.ts';
import {
  createProduct,
  deleteProduct,
  findProductByBarcodeOrSku,
  getProductById,
  listProducts,
  updateProduct,
} from '../services/productService.ts';
import {
  createPurchaseOrder,
  getPurchaseOrderById,
  getReorderSuggestions,
  listPurchaseOrders,
  updatePurchaseOrder,
} from '../services/reorderService.ts';
import { adjustStock, listStockMovements } from '../services/stockService.ts';
import {
  createSupplier,
  deleteSupplier,
  getSupplierById,
  listSuppliers,
  updateSupplier,
} from '../services/supplierService.ts';
import { AppError } from '../utils/errors.ts';
import {
  createProductSchema,
  createPurchaseOrderSchema,
  createSupplierSchema,
  stockAdjustSchema,
  updateProductSchema,
  updatePurchaseOrderSchema,
  updateSettingsSchema,
  updateSupplierSchema,
} from '../validators/schemas.ts';

function parseNumericId(raw: string | string[] | undefined, label = 'ID'): number {
  const str = Array.isArray(raw) ? raw[0] : raw;
  const num = Number(str);
  if (!Number.isInteger(num) || num <= 0) {
    throw new AppError(`Invalid ${label}`, 400);
  }
  return num;
}

export function createControllers(db: Database.Database) {
  return {
    health: (_req: Request, res: Response) => {
      const row = db.prepare('SELECT COUNT(*) AS count FROM products').get() as { count: number };
      res.json({
        status: 'ok',
        service: 'StockSherpa API',
        database: 'sqlite',
        products_count: row.count,
        timestamp: new Date().toISOString(),
      });
    },

    // Products
    listProducts: (req: Request, res: Response) => {
      const products = listProducts(db, {
        search: typeof req.query.search === 'string' ? req.query.search : undefined,
        category: typeof req.query.category === 'string' ? req.query.category : undefined,
        status: typeof req.query.status === 'string' ? req.query.status : undefined,
        sort: typeof req.query.sort === 'string' ? req.query.sort : undefined,
        supplier_id: req.query.supplier_id ? Number(req.query.supplier_id) : undefined,
      });
      res.json({ data: products, count: products.length });
    },

    getProduct: (req: Request, res: Response) => {
      const id = parseNumericId(req.params.id, 'product ID');
      const product = getProductById(db, id);
      res.json({ data: product });
    },

    lookupBarcode: (req: Request, res: Response) => {
      const code = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;
      if (!code || code.trim().length === 0) {
        throw new AppError('Barcode or SKU is required', 400);
      }
      const product = findProductByBarcodeOrSku(db, code);
      res.json({ data: product });
    },

    createProduct: (req: Request, res: Response) => {
      const parsed = createProductSchema.parse(req.body);
      const product = createProduct(db, parsed);
      res.status(201).json({ data: product, message: 'Product added successfully' });
    },

    updateProduct: (req: Request, res: Response) => {
      const id = parseNumericId(req.params.id, 'product ID');
      const parsed = updateProductSchema.parse(req.body);
      const product = updateProduct(db, id, parsed);
      res.json({ data: product, message: 'Product updated successfully' });
    },

    deleteProduct: (req: Request, res: Response) => {
      const id = parseNumericId(req.params.id, 'product ID');
      const result = deleteProduct(db, id);
      res.json({ data: result, message: 'Product deleted successfully' });
    },

    // Stock & Movements
    adjustStock: (req: Request, res: Response) => {
      const parsed = stockAdjustSchema.parse(req.body);
      const result = adjustStock(db, parsed);
      res.json({
        data: result,
        message: `Stock updated to ${result.product.current_quantity} ${result.product.unit}`,
      });
    },

    listMovements: (req: Request, res: Response) => {
      const movements = listStockMovements(db, {
        search: typeof req.query.search === 'string' ? req.query.search : undefined,
        movement_type: typeof req.query.movement_type === 'string' ? req.query.movement_type : undefined,
        product_id: req.query.product_id ? Number(req.query.product_id) : undefined,
        date_from: typeof req.query.date_from === 'string' ? req.query.date_from : undefined,
        date_to: typeof req.query.date_to === 'string' ? req.query.date_to : undefined,
        limit: req.query.limit ? Number(req.query.limit) : undefined,
      });
      res.json({ data: movements, count: movements.length });
    },

    listProductMovements: (req: Request, res: Response) => {
      const productId = parseNumericId(req.params.productId, 'product ID');
      getProductById(db, productId);
      const movements = listStockMovements(db, { product_id: productId });
      res.json({ data: movements, count: movements.length });
    },

    // Suppliers
    listSuppliers: (req: Request, res: Response) => {
      const search = typeof req.query.search === 'string' ? req.query.search : undefined;
      const suppliers = listSuppliers(db, search);
      res.json({ data: suppliers, count: suppliers.length });
    },

    getSupplier: (req: Request, res: Response) => {
      const id = parseNumericId(req.params.id, 'supplier ID');
      const supplier = getSupplierById(db, id);
      res.json({ data: supplier });
    },

    createSupplier: (req: Request, res: Response) => {
      const parsed = createSupplierSchema.parse(req.body);
      const supplier = createSupplier(db, parsed);
      res.status(201).json({ data: supplier, message: 'Supplier added successfully' });
    },

    updateSupplier: (req: Request, res: Response) => {
      const id = parseNumericId(req.params.id, 'supplier ID');
      const parsed = updateSupplierSchema.parse(req.body);
      const supplier = updateSupplier(db, id, parsed);
      res.json({ data: supplier, message: 'Supplier updated successfully' });
    },

    deleteSupplier: (req: Request, res: Response) => {
      const id = parseNumericId(req.params.id, 'supplier ID');
      const result = deleteSupplier(db, id);
      res.json({ data: result, message: 'Supplier removed successfully' });
    },

    // Reorder & Purchase Orders
    reorderSuggestions: (_req: Request, res: Response) => {
      const suggestions = getReorderSuggestions(db);
      res.json({ data: suggestions, count: suggestions.length });
    },

    generatePurchaseOrder: (req: Request, res: Response) => {
      const parsed = createPurchaseOrderSchema.parse(req.body);
      const po = createPurchaseOrder(db, parsed);
      res.status(201).json({ data: po, message: `Purchase order ${po.order_number} generated` });
    },

    listPurchaseOrders: (req: Request, res: Response) => {
      const status = typeof req.query.status === 'string' ? req.query.status : undefined;
      const orders = listPurchaseOrders(db, status);
      res.json({ data: orders, count: orders.length });
    },

    getPurchaseOrder: (req: Request, res: Response) => {
      const id = parseNumericId(req.params.id, 'purchase order ID');
      const po = getPurchaseOrderById(db, id);
      res.json({ data: po });
    },

    updatePurchaseOrder: (req: Request, res: Response) => {
      const id = parseNumericId(req.params.id, 'purchase order ID');
      const parsed = updatePurchaseOrderSchema.parse(req.body);
      const po = updatePurchaseOrder(db, id, parsed);
      res.json({ data: po, message: `Purchase order ${po.order_number} updated (${po.status})` });
    },

    // Dashboard
    dashboardSummary: (_req: Request, res: Response) => {
      const summary = getDashboardSummary(db);
      res.json({ data: summary });
    },

    dashboardAnalytics: (_req: Request, res: Response) => {
      const analytics = getDashboardAnalytics(db);
      res.json({ data: analytics });
    },

    // Expiry
    listExpiry: (req: Request, res: Response) => {
      const days = req.query.days ? Number(req.query.days) : undefined;
      const records = listExpiryRecords(db, days);
      res.json({ data: records, count: records.length });
    },

    expiryAlerts: (_req: Request, res: Response) => {
      const alerts = getExpiryAlerts(db);
      res.json({ data: alerts });
    },

    // Settings & Demo Reset
    getSettings: (_req: Request, res: Response) => {
      const rows = db.prepare('SELECT key, value FROM app_settings').all() as Array<{
        key: string;
        value: string;
      }>;
      const settings: Record<string, string> = {
        store_name: env.defaultStoreName,
        owner_name: 'Rajesh Sharma',
        store_phone: '+91 98201 44510',
        store_address: 'Shop 14, Station Road, Andheri West, Mumbai 400058',
        currency_symbol: '₹',
      };
      for (const r of rows) {
        settings[r.key] = r.value;
      }
      res.json({ data: settings });
    },

    updateSettings: (req: Request, res: Response) => {
      const parsed = updateSettingsSchema.parse(req.body);
      const upsert = db.prepare(
        `INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))`
      );
      for (const [k, v] of Object.entries(parsed)) {
        if (v !== undefined) {
          upsert.run(k, v);
        }
      }
      const rows = db.prepare('SELECT key, value FROM app_settings').all() as Array<{
        key: string;
        value: string;
      }>;
      const out: Record<string, string> = {};
      for (const r of rows) out[r.key] = r.value;
      res.json({ data: out, message: 'Store settings saved' });
    },

    resetDemoData: (_req: Request, res: Response) => {
      const result = seedDatabase(db, true);
      res.json({
        data: result,
        message: `Sample kirana catalog restored (${result.productsCount} products).`,
      });
    },
  };
}
