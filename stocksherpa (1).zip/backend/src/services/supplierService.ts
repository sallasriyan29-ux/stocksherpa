import type Database from 'better-sqlite3';
import type { PurchaseOrder, Supplier } from '../types/index.ts';
import { ConflictError, NotFoundError } from '../utils/errors.ts';

export function listSuppliers(db: Database.Database, search?: string): Supplier[] {
  const conditions: string[] = [];
  const params: unknown[] = [];

  if (search && search.trim().length > 0) {
    const q = `%${search.trim()}%`;
    conditions.push('(s.name LIKE ? OR s.contact_person LIKE ? OR s.phone LIKE ? OR s.email LIKE ?)');
    params.push(q, q, q, q);
  }

  const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  return db
    .prepare(
      `
      SELECT
        s.*,
        (SELECT COUNT(*) FROM products p WHERE p.supplier_id = s.id) AS product_count,
        (SELECT COUNT(*) FROM purchase_orders po WHERE po.supplier_id = s.id AND po.status IN ('Draft', 'Pending', 'Sent', 'Partially Received')) AS outstanding_orders,
        (SELECT COALESCE(SUM(po.total_cost), 0) FROM purchase_orders po WHERE po.supplier_id = s.id AND po.status != 'Cancelled') AS total_order_value
      FROM suppliers s
      ${where}
      ORDER BY s.name ASC
    `
    )
    .all(...params) as Supplier[];
}

export function getSupplierById(db: Database.Database, id: number): Supplier & {
  products: Array<{ id: number; name: string; sku: string; current_quantity: number; minimum_stock_threshold: number; cost_price: number; unit: string }>;
  purchase_orders: PurchaseOrder[];
} {
  const supplier = db
    .prepare(
      `
      SELECT
        s.*,
        (SELECT COUNT(*) FROM products p WHERE p.supplier_id = s.id) AS product_count,
        (SELECT COUNT(*) FROM purchase_orders po WHERE po.supplier_id = s.id AND po.status IN ('Draft', 'Pending', 'Sent', 'Partially Received')) AS outstanding_orders,
        (SELECT COALESCE(SUM(po.total_cost), 0) FROM purchase_orders po WHERE po.supplier_id = s.id AND po.status != 'Cancelled') AS total_order_value
      FROM suppliers s
      WHERE s.id = ?
    `
    )
    .get(id) as Supplier | undefined;

  if (!supplier) {
    throw new NotFoundError('Supplier not found');
  }

  const products = db
    .prepare(
      `
      SELECT id, name, sku, current_quantity, minimum_stock_threshold, cost_price, unit
      FROM products
      WHERE supplier_id = ?
      ORDER BY name ASC
    `
    )
    .all(id) as Array<{
    id: number;
    name: string;
    sku: string;
    current_quantity: number;
    minimum_stock_threshold: number;
    cost_price: number;
    unit: string;
  }>;

  const purchaseOrders = db
    .prepare(
      `
      SELECT po.*, s.name AS supplier_name, s.phone AS supplier_phone
      FROM purchase_orders po
      JOIN suppliers s ON s.id = po.supplier_id
      WHERE po.supplier_id = ?
      ORDER BY po.order_date DESC, po.id DESC
    `
    )
    .all(id) as PurchaseOrder[];

  return {
    ...supplier,
    products,
    purchase_orders: purchaseOrders,
  };
}

export interface CreateSupplierInput {
  name: string;
  contact_person: string;
  phone: string;
  email?: string | null;
  address?: string | null;
}

export function createSupplier(db: Database.Database, input: CreateSupplierInput): Supplier {
  const res = db
    .prepare(
      `
      INSERT INTO suppliers (name, contact_person, phone, email, address, is_sample)
      VALUES (?, ?, ?, ?, ?, 0)
    `
    )
    .run(
      input.name,
      input.contact_person,
      input.phone,
      input.email ?? null,
      input.address ?? null
    );

  return getSupplierById(db, Number(res.lastInsertRowid));
}

export function updateSupplier(
  db: Database.Database,
  id: number,
  input: Partial<CreateSupplierInput>
): Supplier {
  const existing = getSupplierById(db, id);
  db.prepare(
    `
    UPDATE suppliers SET
      name = ?,
      contact_person = ?,
      phone = ?,
      email = ?,
      address = ?,
      updated_at = datetime('now')
    WHERE id = ?
  `
  ).run(
    input.name ?? existing.name,
    input.contact_person ?? existing.contact_person,
    input.phone ?? existing.phone,
    input.email !== undefined ? input.email : existing.email,
    input.address !== undefined ? input.address : existing.address,
    id
  );

  return getSupplierById(db, id);
}

export function deleteSupplier(db: Database.Database, id: number): { deleted: boolean; id: number } {
  getSupplierById(db, id);

  const poCount = db
    .prepare('SELECT COUNT(*) as count FROM purchase_orders WHERE supplier_id = ?')
    .get(id) as { count: number };

  if (poCount.count > 0) {
    throw new ConflictError(
      'Cannot delete supplier because they have linked purchase orders.'
    );
  }

  db.prepare('DELETE FROM suppliers WHERE id = ?').run(id);
  return { deleted: true, id };
}
