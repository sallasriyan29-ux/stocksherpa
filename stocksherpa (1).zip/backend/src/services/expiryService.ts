import type Database from 'better-sqlite3';
import type { ExpiryRecord } from '../types/index.ts';
import { computeExpiryMeta } from './productService.ts';

export function listExpiryRecords(db: Database.Database, windowDays?: number): ExpiryRecord[] {
  const rows = db
    .prepare(
      `
      SELECT
        COALESCE(er.id, p.id) AS id,
        p.id AS product_id,
        p.name AS product_name,
        p.sku,
        p.category,
        COALESCE(er.batch_code, 'BATCH-' || p.id) AS batch_code,
        COALESCE(er.quantity, p.current_quantity) AS quantity,
        p.current_quantity,
        p.unit,
        p.cost_price,
        p.expiry_date,
        er.notes
      FROM products p
      LEFT JOIN expiry_records er ON er.product_id = p.id
      WHERE p.expiry_date IS NOT NULL
      ORDER BY p.expiry_date ASC, p.name ASC
    `
    )
    .all() as Array<{
    id: number;
    product_id: number;
    product_name: string;
    sku: string;
    category: 'Grains' | 'Dairy' | 'Snacks' | 'Personal Care';
    batch_code: string;
    quantity: number;
    current_quantity: number;
    unit: string;
    cost_price: number;
    expiry_date: string;
    notes: string | null;
  }>;

  const enriched: ExpiryRecord[] = rows.map((r) => {
    const meta = computeExpiryMeta(r.expiry_date);
    return {
      ...r,
      days_remaining: meta.days_until_expiry ?? 0,
      expiry_status: meta.expiry_status,
    };
  });

  if (windowDays !== undefined && Number.isFinite(windowDays)) {
    return enriched.filter((e) => e.days_remaining <= windowDays);
  }

  return enriched;
}

export function getExpiryAlerts(db: Database.Database) {
  const all = listExpiryRecords(db);
  return {
    expired: all.filter((e) => e.days_remaining < 0),
    within_7_days: all.filter((e) => e.days_remaining >= 0 && e.days_remaining <= 7),
    within_15_days: all.filter((e) => e.days_remaining > 7 && e.days_remaining <= 15),
    within_30_days: all.filter((e) => e.days_remaining > 15 && e.days_remaining <= 30),
    safe: all.filter((e) => e.days_remaining > 30),
    counts: {
      expired: all.filter((e) => e.days_remaining < 0).length,
      days_7: all.filter((e) => e.days_remaining >= 0 && e.days_remaining <= 7).length,
      days_15: all.filter((e) => e.days_remaining >= 0 && e.days_remaining <= 15).length,
      days_30: all.filter((e) => e.days_remaining >= 0 && e.days_remaining <= 30).length,
      safe: all.filter((e) => e.days_remaining > 30).length,
    },
  };
}
