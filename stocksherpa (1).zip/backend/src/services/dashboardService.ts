import type Database from 'better-sqlite3';
import { env } from '../config/env.ts';
import type { DashboardSummary } from '../types/index.ts';
import { listExpiryRecords } from './expiryService.ts';
import { listProducts } from './productService.ts';
import { listPurchaseOrders } from './reorderService.ts';
import { listStockMovements } from './stockService.ts';

export function getDashboardSummary(db: Database.Database): DashboardSummary {
  const agg = db
    .prepare(
      `
      SELECT
        COUNT(*) AS total_products,
        COALESCE(SUM(current_quantity), 0) AS total_units,
        COALESCE(SUM(current_quantity * cost_price), 0) AS inventory_value_cost,
        COALESCE(SUM(current_quantity * selling_price), 0) AS expected_retail_turnover,
        COALESCE(SUM(current_quantity * (selling_price - cost_price)), 0) AS expected_gross_profit,
        SUM(CASE WHEN current_quantity > 0 AND current_quantity <= minimum_stock_threshold THEN 1 ELSE 0 END) AS low_stock_count,
        SUM(CASE WHEN current_quantity = 0 THEN 1 ELSE 0 END) AS out_of_stock_count
      FROM products
    `
    )
    .get() as {
    total_products: number;
    total_units: number;
    inventory_value_cost: number;
    expected_retail_turnover: number;
    expected_gross_profit: number;
    low_stock_count: number | null;
    out_of_stock_count: number | null;
  };

  const poRow = db
    .prepare(
      `
      SELECT COUNT(*) AS pending_count
      FROM purchase_orders
      WHERE status IN ('Draft', 'Pending', 'Sent', 'Partially Received')
    `
    )
    .get() as { pending_count: number };

  const storeRow = db
    .prepare("SELECT value FROM app_settings WHERE key = 'store_name'")
    .get() as { value: string } | undefined;

  const expiryRecords = listExpiryRecords(db);
  const expiredCount = expiryRecords.filter((e) => e.days_remaining < 0).length;
  const expiringCount = expiryRecords.filter((e) => e.days_remaining >= 0 && e.days_remaining <= 30).length;

  const costVal = Number((agg.inventory_value_cost || 0).toFixed(2));
  const retailVal = Number((agg.expected_retail_turnover || 0).toFixed(2));
  const profitVal = Number((agg.expected_gross_profit || 0).toFixed(2));
  const margin = retailVal > 0 ? Number(((profitVal / retailVal) * 100).toFixed(2)) : 0;

  return {
    total_products: agg.total_products || 0,
    total_units: agg.total_units || 0,
    inventory_value_cost: costVal,
    expected_retail_turnover: retailVal,
    expected_gross_profit: profitVal,
    gross_profit_margin: margin,
    low_stock_count: agg.low_stock_count || 0,
    out_of_stock_count: agg.out_of_stock_count || 0,
    pending_purchase_orders: poRow.pending_count || 0,
    expiring_products_count: expiringCount,
    expired_products_count: expiredCount,
    store_name: storeRow?.value || env.defaultStoreName,
  };
}

export function getDashboardAnalytics(db: Database.Database) {
  const categoryBreakdown = db
    .prepare(
      `
      SELECT
        category,
        COUNT(*) AS product_count,
        COALESCE(SUM(current_quantity), 0) AS total_units,
        ROUND(COALESCE(SUM(current_quantity * cost_price), 0), 2) AS cost_value,
        ROUND(COALESCE(SUM(current_quantity * selling_price), 0), 2) AS retail_value,
        ROUND(COALESCE(SUM(current_quantity * (selling_price - cost_price)), 0), 2) AS expected_profit,
        SUM(CASE WHEN current_quantity <= minimum_stock_threshold THEN 1 ELSE 0 END) AS alert_count
      FROM products
      GROUP BY category
      ORDER BY cost_value DESC
    `
    )
    .all() as Array<{
    category: string;
    product_count: number;
    total_units: number;
    cost_value: number;
    retail_value: number;
    expected_profit: number;
    alert_count: number;
  }>;

  const allProducts = listProducts(db);
  const lowStockProducts = allProducts
    .filter((p) => p.stock_status === 'Low Stock' || p.stock_status === 'Out of Stock')
    .sort((a, b) => a.current_quantity - b.current_quantity)
    .slice(0, 10);

  const recentMovements = listStockMovements(db, { limit: 10 });
  const recentOrders = listPurchaseOrders(db).slice(0, 5);
  const expiryAlerts = listExpiryRecords(db, 30).slice(0, 10);

  return {
    category_breakdown: categoryBreakdown,
    low_stock_products: lowStockProducts,
    recent_movements: recentMovements,
    recent_purchase_orders: recentOrders,
    expiry_alerts: expiryAlerts,
  };
}
