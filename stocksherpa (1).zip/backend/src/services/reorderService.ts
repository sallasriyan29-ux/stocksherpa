import type Database from 'better-sqlite3';
import { env } from '../config/env.ts';
import type {
  PurchaseOrder,
  PurchaseOrderItem,
  PurchaseOrderStatus,
  ReorderSuggestion,
} from '../types/index.ts';
import { AppError, NotFoundError } from '../utils/errors.ts';
import { computeStockStatus } from './productService.ts';

export function getReorderSuggestions(db: Database.Database): ReorderSuggestion[] {
  const rows = db
    .prepare(
      `
      SELECT
        p.id AS product_id,
        p.name AS product_name,
        p.sku,
        p.category,
        p.unit,
        p.current_quantity,
        p.minimum_stock_threshold,
        p.target_stock_level,
        p.cost_price,
        p.supplier_id,
        s.name AS supplier_name,
        s.phone AS supplier_phone
      FROM products p
      LEFT JOIN suppliers s ON s.id = p.supplier_id
      WHERE p.current_quantity <= p.minimum_stock_threshold
      ORDER BY p.current_quantity ASC, p.name ASC
    `
    )
    .all() as Array<{
    product_id: number;
    product_name: string;
    sku: string;
    category: 'Grains' | 'Dairy' | 'Snacks' | 'Personal Care';
    unit: string;
    current_quantity: number;
    minimum_stock_threshold: number;
    target_stock_level: number;
    cost_price: number;
    supplier_id: number | null;
    supplier_name: string | null;
    supplier_phone: string | null;
  }>;

  return rows.map((r) => {
    const effectiveTarget =
      r.target_stock_level > r.minimum_stock_threshold
        ? r.target_stock_level
        : Math.max(r.minimum_stock_threshold * 3, 12);
    const recommendedQty = Math.max(0, effectiveTarget - r.current_quantity);
    const estimatedCost = Number((recommendedQty * r.cost_price).toFixed(2));

    return {
      ...r,
      target_stock_level: effectiveTarget,
      recommended_quantity: recommendedQty,
      estimated_cost: estimatedCost,
      stock_status: computeStockStatus(r.current_quantity, r.minimum_stock_threshold),
    };
  });
}

function getStoreName(db: Database.Database): string {
  const row = db
    .prepare("SELECT value FROM app_settings WHERE key = 'store_name'")
    .get() as { value: string } | undefined;
  return row?.value || env.defaultStoreName;
}

function generateOrderNumber(db: Database.Database): string {
  const year = new Date().getFullYear();
  const row = db
    .prepare('SELECT COALESCE(MAX(id), 0) AS max_id FROM purchase_orders')
    .get() as { max_id: number };
  const seq = 1001 + row.max_id;
  return `PO-${year}-${seq}`;
}

export interface CreatePurchaseOrderInput {
  supplier_id: number;
  status?: 'Draft' | 'Pending' | 'Sent';
  notes?: string | null;
  items: Array<{
    product_id: number;
    quantity_ordered: number;
    unit_cost?: number;
  }>;
}

export function createPurchaseOrder(
  db: Database.Database,
  input: CreatePurchaseOrderInput
): PurchaseOrder {
  const supplier = db
    .prepare('SELECT id, name, phone, contact_person FROM suppliers WHERE id = ?')
    .get(input.supplier_id) as
    | { id: number; name: string; phone: string; contact_person: string }
    | undefined;

  if (!supplier) {
    throw new NotFoundError('Selected supplier not found');
  }

  const tx = db.transaction(() => {
    const storeName = getStoreName(db);
    const orderNumber = generateOrderNumber(db);

    let totalCost = 0;
    const preparedItems: Array<{
      product_id: number;
      product_name: string;
      sku: string;
      quantity_ordered: number;
      unit_cost: number;
      line_total: number;
    }> = [];

    for (const item of input.items) {
      const prod = db
        .prepare('SELECT id, name, sku, cost_price FROM products WHERE id = ?')
        .get(item.product_id) as
        | { id: number; name: string; sku: string; cost_price: number }
        | undefined;

      if (!prod) {
        throw new NotFoundError(`Product ID ${item.product_id} not found`);
      }

      const unitCost = item.unit_cost !== undefined ? item.unit_cost : prod.cost_price;
      const lineTotal = Number((unitCost * item.quantity_ordered).toFixed(2));
      totalCost += lineTotal;

      preparedItems.push({
        product_id: prod.id,
        product_name: prod.name,
        sku: prod.sku,
        quantity_ordered: item.quantity_ordered,
        unit_cost: unitCost,
        line_total: lineTotal,
      });
    }

    totalCost = Number(totalCost.toFixed(2));

    const poRes = db
      .prepare(
        `
        INSERT INTO purchase_orders (
          order_number, supplier_id, store_name, status, total_cost, notes
        ) VALUES (?, ?, ?, ?, ?, ?)
      `
      )
      .run(
        orderNumber,
        input.supplier_id,
        storeName,
        input.status || 'Pending',
        totalCost,
        input.notes ?? null
      );

    const poId = Number(poRes.lastInsertRowid);

    const insertItem = db.prepare(
      `
      INSERT INTO purchase_order_items (
        purchase_order_id, product_id, product_name, sku,
        quantity_ordered, quantity_received, unit_cost, line_total
      ) VALUES (?, ?, ?, ?, ?, 0, ?, ?)
    `
    );

    for (const item of preparedItems) {
      insertItem.run(
        poId,
        item.product_id,
        item.product_name,
        item.sku,
        item.quantity_ordered,
        item.unit_cost,
        item.line_total
      );
    }

    return poId;
  });

  const poId = tx();
  return getPurchaseOrderById(db, poId);
}

export function listPurchaseOrders(db: Database.Database, status?: string): PurchaseOrder[] {
  const conditions: string[] = [];
  const params: unknown[] = [];

  if (status && status !== 'All') {
    conditions.push('po.status = ?');
    params.push(status);
  }

  const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  const orders = db
    .prepare(
      `
      SELECT
        po.*,
        s.name AS supplier_name,
        s.phone AS supplier_phone,
        s.contact_person AS supplier_contact
      FROM purchase_orders po
      JOIN suppliers s ON s.id = po.supplier_id
      ${where}
      ORDER BY po.order_date DESC, po.id DESC
    `
    )
    .all(...params) as PurchaseOrder[];

  if (orders.length === 0) return [];

  const allItems = db
    .prepare('SELECT * FROM purchase_order_items ORDER BY id ASC')
    .all() as PurchaseOrderItem[];

  const itemsByPo = new Map<number, PurchaseOrderItem[]>();
  for (const item of allItems) {
    const arr = itemsByPo.get(item.purchase_order_id) || [];
    arr.push(item);
    itemsByPo.set(item.purchase_order_id, arr);
  }

  return orders.map((o) => ({
    ...o,
    items: itemsByPo.get(o.id) || [],
  }));
}

export function getPurchaseOrderById(db: Database.Database, id: number): PurchaseOrder {
  const order = db
    .prepare(
      `
      SELECT
        po.*,
        s.name AS supplier_name,
        s.phone AS supplier_phone,
        s.contact_person AS supplier_contact
      FROM purchase_orders po
      JOIN suppliers s ON s.id = po.supplier_id
      WHERE po.id = ?
    `
    )
    .get(id) as PurchaseOrder | undefined;

  if (!order) {
    throw new NotFoundError('Purchase order not found');
  }

  const items = db
    .prepare('SELECT * FROM purchase_order_items WHERE purchase_order_id = ? ORDER BY id ASC')
    .all(id) as PurchaseOrderItem[];

  return {
    ...order,
    items,
  };
}

export interface UpdatePurchaseOrderInput {
  status?: PurchaseOrderStatus;
  notes?: string | null;
  received_items?: Array<{
    product_id: number;
    quantity_received: number;
  }>;
}

export function updatePurchaseOrder(
  db: Database.Database,
  id: number,
  input: UpdatePurchaseOrderInput
): PurchaseOrder {
  const tx = db.transaction(() => {
    const existing = getPurchaseOrderById(db, id);
    const items = existing.items || [];

    if (existing.status === 'Cancelled' && input.status && input.status !== 'Cancelled') {
      throw new AppError('Cancelled purchase orders cannot be reopened.', 400);
    }

    if (existing.status === 'Received' && input.status && input.status !== 'Received') {
      throw new AppError('Received purchase orders cannot revert to an earlier status.', 400);
    }

    let nextStatus: PurchaseOrderStatus = input.status || existing.status;

    // If marking Received without explicit received_items, receive all remaining quantities
    const shouldReceiveAll =
      input.status === 'Received' &&
      (!input.received_items || input.received_items.length === 0);

    const receiveEntries: Array<{ product_id: number; qty_to_add: number }> = [];

    if (shouldReceiveAll) {
      for (const item of items) {
        const remaining = Math.max(0, item.quantity_ordered - item.quantity_received);
        if (remaining > 0) {
          receiveEntries.push({ product_id: item.product_id, qty_to_add: remaining });
        }
      }
    } else if (input.received_items && input.received_items.length > 0) {
      for (const rec of input.received_items) {
        const poItem = items.find((i) => i.product_id === rec.product_id);
        if (!poItem) {
          throw new AppError(`Product ID ${rec.product_id} is not in this purchase order.`, 400);
        }
        const remaining = Math.max(0, poItem.quantity_ordered - poItem.quantity_received);
        if (rec.quantity_received > remaining) {
          throw new AppError(
            `Cannot receive ${rec.quantity_received} units of ${poItem.product_name}; only ${remaining} remaining.`,
            400
          );
        }
        if (rec.quantity_received > 0) {
          receiveEntries.push({ product_id: rec.product_id, qty_to_add: rec.quantity_received });
        }
      }
    }

    // Apply actual inventory increments & stock movements before updating PO status!
    let stockUpdated = false;
    for (const entry of receiveEntries) {
      const prod = db
        .prepare('SELECT id, current_quantity FROM products WHERE id = ?')
        .get(entry.product_id) as { id: number; current_quantity: number } | undefined;

      if (!prod) continue;

      const newQty = prod.current_quantity + entry.qty_to_add;

      db.prepare(
        `
        UPDATE products
        SET current_quantity = ?,
            version = version + 1,
            updated_at = datetime('now')
        WHERE id = ?
      `
      ).run(newQty, entry.product_id);

      db.prepare(
        `
        UPDATE purchase_order_items
        SET quantity_received = quantity_received + ?
        WHERE purchase_order_id = ? AND product_id = ?
      `
      ).run(entry.qty_to_add, id, entry.product_id);

      db.prepare(
        `
        INSERT INTO stock_movements (
          product_id, movement_type, quantity_changed, previous_quantity,
          new_quantity, reason, reference_po_id
        ) VALUES (?, 'Supplier delivery', ?, ?, ?, ?, ?)
      `
      ).run(
        entry.product_id,
        entry.qty_to_add,
        prod.current_quantity,
        newQty,
        `Received via ${existing.order_number}`,
        id
      );

      stockUpdated = true;
    }

    // Recompute received totals to decide Received vs Partially Received
    if (stockUpdated || input.status === 'Received' || input.status === 'Partially Received') {
      const updatedItems = db
        .prepare('SELECT quantity_ordered, quantity_received FROM purchase_order_items WHERE purchase_order_id = ?')
        .all(id) as Array<{ quantity_ordered: number; quantity_received: number }>;

      const allReceived =
        updatedItems.length > 0 &&
        updatedItems.every((i) => i.quantity_received >= i.quantity_ordered);
      const anyReceived = updatedItems.some((i) => i.quantity_received > 0);

      if (allReceived) {
        nextStatus = 'Received';
      } else if (anyReceived) {
        nextStatus = 'Partially Received';
      } else if (input.status === 'Received' || input.status === 'Partially Received') {
        throw new AppError(
          'Purchase order cannot be marked received until inventory quantities are actually received.',
          400
        );
      }
    }

    db.prepare(
      `
      UPDATE purchase_orders
      SET status = ?,
          notes = ?,
          received_at = CASE WHEN ? = 'Received' AND received_at IS NULL THEN datetime('now') ELSE received_at END,
          updated_at = datetime('now')
      WHERE id = ?
    `
    ).run(
      nextStatus,
      input.notes !== undefined ? input.notes : existing.notes,
      nextStatus,
      id
    );
  });

  tx();
  return getPurchaseOrderById(db, id);
}
