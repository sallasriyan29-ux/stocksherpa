import type Database from 'better-sqlite3';
import type { ExpiryStatus, Product, StockAlertLevel } from '../types/index.ts';
import { AppError, ConflictError, NotFoundError } from '../utils/errors.ts';

export function computeStockStatus(currentQuantity: number, minThreshold: number): StockAlertLevel {
  if (currentQuantity <= 0) return 'Out of Stock';
  if (currentQuantity <= minThreshold) return 'Low Stock';
  return 'In Stock';
}

export function computeExpiryMeta(expiryDate: string | null): {
  expiry_status: ExpiryStatus;
  days_until_expiry: number | null;
} {
  if (!expiryDate) {
    return { expiry_status: 'N/A', days_until_expiry: null };
  }
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const exp = new Date(`${expiryDate}T00:00:00`);
  const diffDays = Math.ceil((exp.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return { expiry_status: 'Expired', days_until_expiry: diffDays };
  }
  if (diffDays <= 7) {
    return { expiry_status: 'Critical', days_until_expiry: diffDays };
  }
  if (diffDays <= 30) {
    return { expiry_status: 'Expiring Soon', days_until_expiry: diffDays };
  }
  return { expiry_status: 'Safe', days_until_expiry: diffDays };
}

interface RawProductRow {
  id: number;
  name: string;
  sku: string;
  barcode: string | null;
  category: 'Grains' | 'Dairy' | 'Snacks' | 'Personal Care';
  cost_price: number;
  selling_price: number;
  current_quantity: number;
  minimum_stock_threshold: number;
  target_stock_level: number;
  unit: string;
  supplier_id: number | null;
  supplier_name: string | null;
  supplier_phone: string | null;
  expiry_date: string | null;
  is_sample: number;
  version: number;
  created_at: string;
  updated_at: string;
}

function hydrateProduct(row: RawProductRow): Product {
  const expiryMeta = computeExpiryMeta(row.expiry_date);
  return {
    ...row,
    stock_status: computeStockStatus(row.current_quantity, row.minimum_stock_threshold),
    expiry_status: expiryMeta.expiry_status,
    days_until_expiry: expiryMeta.days_until_expiry,
  };
}

export interface ProductFilterOptions {
  search?: string;
  category?: string;
  status?: string;
  sort?: string;
  supplier_id?: number;
}

export function listProducts(db: Database.Database, filters: ProductFilterOptions = {}): Product[] {
  const conditions: string[] = [];
  const params: unknown[] = [];

  if (filters.search && filters.search.trim().length > 0) {
    const q = `%${filters.search.trim()}%`;
    conditions.push(`(p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ? OR p.category LIKE ?)`);
    params.push(q, q, q, q);
  }

  if (filters.category && filters.category !== 'All') {
    conditions.push(`p.category = ?`);
    params.push(filters.category);
  }

  if (filters.supplier_id) {
    conditions.push(`p.supplier_id = ?`);
    params.push(filters.supplier_id);
  }

  if (filters.status && filters.status !== 'All') {
    if (filters.status === 'Out of Stock') {
      conditions.push(`p.current_quantity = 0`);
    } else if (filters.status === 'Low Stock') {
      conditions.push(`p.current_quantity > 0 AND p.current_quantity <= p.minimum_stock_threshold`);
    } else if (filters.status === 'In Stock') {
      conditions.push(`p.current_quantity > p.minimum_stock_threshold`);
    } else if (filters.status === 'Expiring Soon') {
      conditions.push(`p.expiry_date IS NOT NULL AND julianday(p.expiry_date) - julianday('now', 'localtime') <= 30`);
    }
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  let orderBy = 'p.updated_at DESC, p.id DESC';
  switch (filters.sort) {
    case 'name_asc':
    case 'name':
      orderBy = 'p.name ASC';
      break;
    case 'highest_stock':
      orderBy = 'p.current_quantity DESC, p.name ASC';
      break;
    case 'lowest_stock':
      orderBy = 'p.current_quantity ASC, p.name ASC';
      break;
    case 'highest_cost':
      orderBy = 'p.cost_price DESC, p.name ASC';
      break;
    case 'lowest_cost':
      orderBy = 'p.cost_price ASC, p.name ASC';
      break;
    case 'recently_updated':
    default:
      orderBy = 'p.updated_at DESC, p.id DESC';
      break;
  }

  const rows = db
    .prepare(
      `
      SELECT p.*, s.name AS supplier_name, s.phone AS supplier_phone
      FROM products p
      LEFT JOIN suppliers s ON s.id = p.supplier_id
      ${whereClause}
      ORDER BY ${orderBy}
    `
    )
    .all(...params) as RawProductRow[];

  return rows.map(hydrateProduct);
}

export function getProductById(db: Database.Database, id: number): Product {
  const row = db
    .prepare(
      `
      SELECT p.*, s.name AS supplier_name, s.phone AS supplier_phone
      FROM products p
      LEFT JOIN suppliers s ON s.id = p.supplier_id
      WHERE p.id = ?
    `
    )
    .get(id) as RawProductRow | undefined;

  if (!row) {
    throw new NotFoundError('Product not found');
  }

  return hydrateProduct(row);
}

export function findProductByBarcodeOrSku(db: Database.Database, code: string): Product {
  const trimmed = code.trim();
  const row = db
    .prepare(
      `
      SELECT p.*, s.name AS supplier_name, s.phone AS supplier_phone
      FROM products p
      LEFT JOIN suppliers s ON s.id = p.supplier_id
      WHERE p.barcode = ? OR UPPER(p.sku) = UPPER(?)
      LIMIT 1
    `
    )
    .get(trimmed, trimmed) as RawProductRow | undefined;

  if (!row) {
    throw new NotFoundError(`No product found matching barcode or SKU "${trimmed}"`);
  }

  return hydrateProduct(row);
}

export interface CreateProductInput {
  name: string;
  sku: string;
  barcode?: string | null;
  category: 'Grains' | 'Dairy' | 'Snacks' | 'Personal Care';
  cost_price: number;
  selling_price: number;
  current_quantity: number;
  minimum_stock_threshold: number;
  target_stock_level?: number;
  unit?: string;
  supplier_id?: number | null;
  expiry_date?: string | null;
}

export function createProduct(db: Database.Database, input: CreateProductInput): Product {
  const duplicateSku = db.prepare('SELECT id FROM products WHERE UPPER(sku) = UPPER(?)').get(input.sku);
  if (duplicateSku) {
    throw new ConflictError(`SKU "${input.sku}" already exists.`);
  }

  if (input.barcode) {
    const duplicateBarcode = db.prepare('SELECT id FROM products WHERE barcode = ?').get(input.barcode);
    if (duplicateBarcode) {
      throw new ConflictError(`Barcode "${input.barcode}" is already assigned to another product.`);
    }
  }

  if (input.supplier_id) {
    const sup = db.prepare('SELECT id FROM suppliers WHERE id = ?').get(input.supplier_id);
    if (!sup) {
      throw new AppError('Selected supplier does not exist.', 400);
    }
  }

  const targetLevel =
    input.target_stock_level !== undefined
      ? input.target_stock_level
      : Math.max(input.minimum_stock_threshold * 3, 15);

  const insertTx = db.transaction(() => {
    const res = db
      .prepare(
        `
        INSERT INTO products (
          name, sku, barcode, category, cost_price, selling_price,
          current_quantity, minimum_stock_threshold, target_stock_level,
          unit, supplier_id, expiry_date, is_sample
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `
      )
      .run(
        input.name,
        input.sku,
        input.barcode ?? null,
        input.category,
        input.cost_price,
        input.selling_price,
        input.current_quantity,
        input.minimum_stock_threshold,
        targetLevel,
        input.unit || 'pcs',
        input.supplier_id ?? null,
        input.expiry_date ?? null
      );

    const newId = Number(res.lastInsertRowid);

    if (input.current_quantity > 0) {
      db.prepare(
        `
        INSERT INTO stock_movements (
          product_id, movement_type, quantity_changed, previous_quantity,
          new_quantity, reason
        ) VALUES (?, 'Supplier delivery', ?, 0, ?, 'Initial product creation opening stock')
      `
      ).run(newId, input.current_quantity, input.current_quantity);
    }

    if (input.expiry_date) {
      db.prepare(
        `
        INSERT INTO expiry_records (product_id, batch_code, quantity, expiry_date, notes)
        VALUES (?, ?, ?, ?, 'Initial batch')
      `
      ).run(newId, `BATCH-${newId}`, input.current_quantity, input.expiry_date);
    }

    return newId;
  });

  const id = insertTx();
  return getProductById(db, id);
}

export function updateProduct(
  db: Database.Database,
  id: number,
  input: Partial<CreateProductInput>
): Product {
  const existing = getProductById(db, id);

  if (input.sku && input.sku.toUpperCase() !== existing.sku.toUpperCase()) {
    const dup = db
      .prepare('SELECT id FROM products WHERE UPPER(sku) = UPPER(?) AND id != ?')
      .get(input.sku, id);
    if (dup) throw new ConflictError(`SKU "${input.sku}" already exists.`);
  }

  if (input.barcode !== undefined && input.barcode !== null && input.barcode !== existing.barcode) {
    const dup = db
      .prepare('SELECT id FROM products WHERE barcode = ? AND id != ?')
      .get(input.barcode, id);
    if (dup) throw new ConflictError(`Barcode "${input.barcode}" is already assigned to another product.`);
  }

  const updateTx = db.transaction(() => {
    const nextQty = input.current_quantity !== undefined ? input.current_quantity : existing.current_quantity;

    db.prepare(
      `
      UPDATE products SET
        name = ?,
        sku = ?,
        barcode = ?,
        category = ?,
        cost_price = ?,
        selling_price = ?,
        current_quantity = ?,
        minimum_stock_threshold = ?,
        target_stock_level = ?,
        unit = ?,
        supplier_id = ?,
        expiry_date = ?,
        version = version + 1,
        updated_at = datetime('now')
      WHERE id = ?
    `
    ).run(
      input.name ?? existing.name,
      input.sku ?? existing.sku,
      input.barcode !== undefined ? input.barcode : existing.barcode,
      input.category ?? existing.category,
      input.cost_price ?? existing.cost_price,
      input.selling_price ?? existing.selling_price,
      nextQty,
      input.minimum_stock_threshold ?? existing.minimum_stock_threshold,
      input.target_stock_level ?? existing.target_stock_level,
      input.unit ?? existing.unit,
      input.supplier_id !== undefined ? input.supplier_id : existing.supplier_id,
      input.expiry_date !== undefined ? input.expiry_date : existing.expiry_date,
      id
    );

    if (nextQty !== existing.current_quantity) {
      const delta = nextQty - existing.current_quantity;
      db.prepare(
        `
        INSERT INTO stock_movements (
          product_id, movement_type, quantity_changed, previous_quantity,
          new_quantity, reason
        ) VALUES (?, 'Manual correction', ?, ?, ?, 'Updated stock via product edit')
      `
      ).run(id, delta, existing.current_quantity, nextQty);
    }

    if (input.expiry_date !== undefined && input.expiry_date !== existing.expiry_date) {
      db.prepare('DELETE FROM expiry_records WHERE product_id = ?').run(id);
      if (input.expiry_date) {
        db.prepare(
          `
          INSERT INTO expiry_records (product_id, batch_code, quantity, expiry_date, notes)
          VALUES (?, ?, ?, ?, 'Updated expiry schedule')
        `
        ).run(id, `BATCH-${id}`, nextQty, input.expiry_date);
      }
    }
  });

  updateTx();
  return getProductById(db, id);
}

export function deleteProduct(db: Database.Database, id: number): { deleted: boolean; id: number } {
  getProductById(db, id);
  const referencedInPo = db
    .prepare('SELECT COUNT(*) as count FROM purchase_order_items WHERE product_id = ?')
    .get(id) as { count: number };

  if (referencedInPo.count > 0) {
    throw new ConflictError(
      'Cannot delete product because it appears in existing purchase orders. Set stock to 0 instead.'
    );
  }

  db.prepare('DELETE FROM products WHERE id = ?').run(id);
  return { deleted: true, id };
}
