import type Database from 'better-sqlite3';
import type { MovementType, Product, StockMovement } from '../types/index.ts';
import { AppError, ConflictError, NotFoundError } from '../utils/errors.ts';
import { getProductById } from './productService.ts';

export interface AdjustStockInput {
  product_id: number;
  quantity_changed: number;
  movement_type: MovementType;
  reason: string;
  reference_po_id?: number | null;
  client_operation_id?: string | null;
  expected_version?: number;
}

export interface AdjustStockResult {
  product: Product;
  movement: StockMovement;
  already_processed?: boolean;
}

export function adjustStock(db: Database.Database, input: AdjustStockInput): AdjustStockResult {
  const tx = db.transaction(() => {
    // Idempotency check for offline queue retries
    if (input.client_operation_id) {
      const existingMovement = db
        .prepare(
          `
          SELECT m.*, p.name AS product_name, p.sku AS product_sku, po.order_number AS reference_order_number
          FROM stock_movements m
          JOIN products p ON p.id = m.product_id
          LEFT JOIN purchase_orders po ON po.id = m.reference_po_id
          WHERE m.client_operation_id = ?
        `
        )
        .get(input.client_operation_id) as StockMovement | undefined;

      if (existingMovement) {
        return {
          product: getProductById(db, existingMovement.product_id),
          movement: existingMovement,
          already_processed: true,
        };
      }
    }

    const row = db
      .prepare('SELECT id, current_quantity, version, name FROM products WHERE id = ?')
      .get(input.product_id) as
      | { id: number; current_quantity: number; version: number; name: string }
      | undefined;

    if (!row) {
      throw new NotFoundError('Product not found');
    }

    if (input.expected_version !== undefined && input.expected_version !== row.version) {
      throw new ConflictError(
        `Sync conflict on "${row.name}": server inventory was updated (current stock is ${row.current_quantity}, version ${row.version}). Please review before syncing.`,
        {
          product_id: row.id,
          server_quantity: row.current_quantity,
          server_version: row.version,
          expected_version: input.expected_version,
        }
      );
    }

    const previousQty = row.current_quantity;
    const newQty = previousQty + input.quantity_changed;

    if (newQty < 0) {
      throw new AppError(
        `Insufficient stock for "${row.name}". Available: ${previousQty}, requested change: ${input.quantity_changed}.`,
        400,
        'INSUFFICIENT_STOCK'
      );
    }

    db.prepare(
      `
      UPDATE products
      SET current_quantity = ?,
          version = version + 1,
          updated_at = datetime('now')
      WHERE id = ?
    `
    ).run(newQty, input.product_id);

    // Keep primary expiry batch quantity synchronized
    db.prepare(
      `
      UPDATE expiry_records
      SET quantity = ?
      WHERE id = (
        SELECT id FROM expiry_records WHERE product_id = ? ORDER BY expiry_date ASC LIMIT 1
      )
    `
    ).run(newQty, input.product_id);

    const movRes = db
      .prepare(
        `
        INSERT INTO stock_movements (
          product_id, movement_type, quantity_changed, previous_quantity,
          new_quantity, reason, reference_po_id, client_operation_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `
      )
      .run(
        input.product_id,
        input.movement_type,
        input.quantity_changed,
        previousQty,
        newQty,
        input.reason,
        input.reference_po_id ?? null,
        input.client_operation_id ?? null
      );

    const movement = db
      .prepare(
        `
        SELECT m.*, p.name AS product_name, p.sku AS product_sku, po.order_number AS reference_order_number
        FROM stock_movements m
        JOIN products p ON p.id = m.product_id
        LEFT JOIN purchase_orders po ON po.id = m.reference_po_id
        WHERE m.id = ?
      `
      )
      .get(Number(movRes.lastInsertRowid)) as StockMovement;

    return {
      product: getProductById(db, input.product_id),
      movement,
    };
  });

  return tx();
}

export interface MovementFilters {
  search?: string;
  product_id?: number;
  movement_type?: string;
  date_from?: string;
  date_to?: string;
  limit?: number;
}

export function listStockMovements(db: Database.Database, filters: MovementFilters = {}): StockMovement[] {
  const conditions: string[] = [];
  const params: unknown[] = [];

  if (filters.product_id) {
    conditions.push('m.product_id = ?');
    params.push(filters.product_id);
  }

  if (filters.movement_type && filters.movement_type !== 'All') {
    conditions.push('m.movement_type = ?');
    params.push(filters.movement_type);
  }

  if (filters.search && filters.search.trim().length > 0) {
    const q = `%${filters.search.trim()}%`;
    conditions.push('(p.name LIKE ? OR p.sku LIKE ? OR m.reason LIKE ?)');
    params.push(q, q, q);
  }

  if (filters.date_from) {
    conditions.push('date(m.created_at) >= date(?)');
    params.push(filters.date_from);
  }

  if (filters.date_to) {
    conditions.push('date(m.created_at) <= date(?)');
    params.push(filters.date_to);
  }

  const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
  const limit = Math.min(Math.max(filters.limit || 200, 1), 500);

  return db
    .prepare(
      `
      SELECT m.*, p.name AS product_name, p.sku AS product_sku, po.order_number AS reference_order_number
      FROM stock_movements m
      JOIN products p ON p.id = m.product_id
      LEFT JOIN purchase_orders po ON po.id = m.reference_po_id
      ${where}
      ORDER BY m.created_at DESC, m.id DESC
      LIMIT ?
    `
    )
    .all(...params, limit) as StockMovement[];
}
