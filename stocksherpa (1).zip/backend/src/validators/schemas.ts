import { z } from 'zod';

const categories = ['Grains', 'Dairy', 'Snacks', 'Personal Care'] as const;
const movementTypes = [
  'Sale',
  'Supplier delivery',
  'Manual correction',
  'Damaged goods',
  'Returned goods',
] as const;
const poStatuses = [
  'Draft',
  'Pending',
  'Sent',
  'Partially Received',
  'Received',
  'Cancelled',
] as const;

export const createProductSchema = z.object({
  name: z.string().trim().min(1, 'Product name is required').max(160),
  sku: z
    .string()
    .trim()
    .min(2, 'SKU must be at least 2 characters')
    .max(64)
    .transform((v) => v.toUpperCase()),
  barcode: z
    .string()
    .trim()
    .max(64)
    .optional()
    .nullable()
    .transform((v) => (v && v.length > 0 ? v : null)),
  category: z.enum(categories, { error: 'Category must be Grains, Dairy, Snacks, or Personal Care' }),
  cost_price: z.coerce.number().min(0, 'Cost price cannot be negative').finite(),
  selling_price: z.coerce.number().min(0, 'Selling price cannot be negative').finite(),
  current_quantity: z.coerce.number().int('Quantity must be a whole number').min(0, 'Quantity cannot be negative'),
  minimum_stock_threshold: z.coerce
    .number()
    .int('Threshold must be a whole number')
    .min(0, 'Minimum threshold cannot be negative'),
  target_stock_level: z.coerce
    .number()
    .int('Target stock level must be a whole number')
    .min(0, 'Target stock level cannot be negative')
    .optional(),
  unit: z.string().trim().min(1).max(32).default('pcs'),
  supplier_id: z.coerce.number().int().positive().optional().nullable(),
  expiry_date: z
    .string()
    .trim()
    .optional()
    .nullable()
    .transform((v) => (v && v.length > 0 ? v : null))
    .refine((v) => v === null || /^\d{4}-\d{2}-\d{2}$/.test(v), 'Expiry date must be YYYY-MM-DD'),
});

export const updateProductSchema = createProductSchema.partial();

export const stockAdjustSchema = z.object({
  product_id: z.coerce.number().int().positive('Valid product ID is required'),
  quantity_changed: z.coerce
    .number()
    .int('Quantity change must be a whole integer')
    .refine((v) => v !== 0, 'Quantity change cannot be zero'),
  movement_type: z.enum(movementTypes),
  reason: z.string().trim().min(1, 'Reason is required').max(250),
  reference_po_id: z.coerce.number().int().positive().optional().nullable(),
  client_operation_id: z.string().trim().max(100).optional().nullable(),
  expected_version: z.coerce.number().int().positive().optional(),
});

export const createSupplierSchema = z.object({
  name: z.string().trim().min(2, 'Supplier name is required').max(150),
  contact_person: z.string().trim().min(2, 'Contact person is required').max(120),
  phone: z
    .string()
    .trim()
    .min(7, 'Phone number is too short')
    .max(24)
    .regex(/^[+\d][\d\s-]{6,22}$/, 'Invalid phone number format'),
  email: z
    .string()
    .trim()
    .optional()
    .nullable()
    .transform((v) => (v && v.length > 0 ? v : null))
    .refine((v) => v === null || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), 'Invalid email address'),
  address: z
    .string()
    .trim()
    .max(300)
    .optional()
    .nullable()
    .transform((v) => (v && v.length > 0 ? v : null)),
});

export const updateSupplierSchema = createSupplierSchema.partial();

export const createPurchaseOrderSchema = z.object({
  supplier_id: z.coerce.number().int().positive('Supplier is required'),
  status: z.enum(['Draft', 'Pending', 'Sent']).optional().default('Pending'),
  notes: z.string().trim().max(500).optional().nullable(),
  items: z
    .array(
      z.object({
        product_id: z.coerce.number().int().positive(),
        quantity_ordered: z.coerce.number().int().positive('Order quantity must be at least 1'),
        unit_cost: z.coerce.number().min(0).optional(),
      })
    )
    .min(1, 'Purchase order must include at least one product'),
});

export const updatePurchaseOrderSchema = z.object({
  status: z.enum(poStatuses).optional(),
  notes: z.string().trim().max(500).optional().nullable(),
  received_items: z
    .array(
      z.object({
        product_id: z.coerce.number().int().positive(),
        quantity_received: z.coerce.number().int().min(0),
      })
    )
    .optional(),
});

export const updateSettingsSchema = z.object({
  store_name: z.string().trim().min(2).max(120).optional(),
  owner_name: z.string().trim().min(2).max(100).optional(),
  store_phone: z.string().trim().max(24).optional(),
  store_address: z.string().trim().max(250).optional(),
});
