import Database from 'better-sqlite3';
import fs from 'fs';
import os from 'os';
import path from 'path';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApiApp } from '../src/app.ts';
import { initializeSchema } from '../src/database/schema.ts';
import { seedDatabase } from '../src/database/seed.ts';

describe('StockSherpa Full-Stack API & Database Workflows', () => {
  let dbPath: string;
  let db: Database.Database;
  let app: ReturnType<typeof createApiApp>;

  beforeAll(() => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'stocksherpa-test-'));
    dbPath = path.join(tmpDir, 'test.db');
    db = new Database(dbPath);
    db.pragma('foreign_keys = ON');
    initializeSchema(db);
    seedDatabase(db, true);
    app = createApiApp(db);
  });

  afterAll(() => {
    db.close();
    try {
      fs.rmSync(path.dirname(dbPath), { recursive: true, force: true });
    } catch {
      // ignore cleanup errors
    }
  });

  it('seeds 60 realistic kirana products and returns health status', async () => {
    const health = await request(app).get('/api/health');
    expect(health.status).toBe(200);
    expect(health.body.products_count).toBe(60);

    const list = await request(app).get('/api/products');
    expect(list.status).toBe(200);
    expect(list.body.count).toBe(60);
  });

  it('executes the complete Hackathon Demo Scenario end-to-end', async () => {
    const summaryBefore = await request(app).get('/api/dashboard/summary');
    expect(summaryBefore.status).toBe(200);
    expect(summaryBefore.body.data.total_products).toBe(60);

    // Search for Atta -> qty 6
    const searchRes = await request(app).get('/api/products?search=Atta');
    expect(searchRes.status).toBe(200);
    const atta = searchRes.body.data.find((p: { name: string }) =>
      p.name.includes('Aashirvaad Shudh Chakki Atta')
    );
    expect(atta).toBeDefined();
    expect(atta.current_quantity).toBe(6);
    expect(atta.stock_status).toBe('In Stock');

    // Decrease stock by 4 -> becomes 2 -> Low Stock
    const adjRes = await request(app).post('/api/stock/adjust').send({
      product_id: atta.id,
      quantity_changed: -4,
      movement_type: 'Sale',
      reason: 'Customer purchase - hackathon demo',
    });
    expect(adjRes.status).toBe(200);
    expect(adjRes.body.data.product.current_quantity).toBe(2);
    expect(adjRes.body.data.product.stock_status).toBe('Low Stock');

    // Verify Atta appears in Reorder Assistant with recommended quantity = 18
    const reorderRes = await request(app).get('/api/reorder/suggestions');
    expect(reorderRes.status).toBe(200);
    const attaSuggestion = reorderRes.body.data.find(
      (s: { product_id: number }) => s.product_id === atta.id
    );
    expect(attaSuggestion).toBeDefined();
    expect(attaSuggestion.recommended_quantity).toBe(18);

    // Generate Purchase Order for Atta
    const poRes = await request(app).post('/api/reorder/generate').send({
      supplier_id: attaSuggestion.supplier_id,
      status: 'Pending',
      notes: 'Demo replenishment order',
      items: [
        {
          product_id: atta.id,
          quantity_ordered: attaSuggestion.recommended_quantity,
          unit_cost: atta.cost_price,
        },
      ],
    });
    expect(poRes.status).toBe(201);
    expect(poRes.body.data.order_number).toMatch(/^PO-\d{4}-\d+$/);
    expect(poRes.body.data.total_cost).toBe(18 * atta.cost_price);

    // Verify stock movement recorded
    const movRes = await request(app).get(`/api/stock/movements/${atta.id}`);
    expect(movRes.status).toBe(200);
    const saleMov = movRes.body.data.find(
      (m: { movement_type: string; quantity_changed: number }) =>
        m.movement_type === 'Sale' && m.quantity_changed === -4
    );
    expect(saleMov).toBeDefined();
    expect(saleMov.previous_quantity).toBe(6);
    expect(saleMov.new_quantity).toBe(2);

    // Verify dashboard KPIs updated
    const summaryAfter = await request(app).get('/api/dashboard/summary');
    expect(summaryAfter.status).toBe(200);
    expect(summaryAfter.body.data.low_stock_count).toBe(
      summaryBefore.body.data.low_stock_count + 1
    );
    expect(summaryAfter.body.data.pending_purchase_orders).toBe(
      summaryBefore.body.data.pending_purchase_orders + 1
    );
    expect(summaryAfter.body.data.inventory_value_cost).toBeLessThan(
      summaryBefore.body.data.inventory_value_cost
    );
  });

  it('prevents negative stock, duplicate SKUs, and invalid prices', async () => {
    const createInvalid = await request(app).post('/api/products').send({
      name: 'Test Item',
      sku: 'TST-001',
      category: 'Snacks',
      cost_price: -10,
      selling_price: 20,
      current_quantity: 5,
      minimum_stock_threshold: 2,
    });
    expect(createInvalid.status).toBe(400);

    const created = await request(app).post('/api/products').send({
      name: 'Haldiram Bhujia Mini (50g)',
      sku: 'TST-BHJ-999',
      barcode: '8909999999991',
      category: 'Snacks',
      cost_price: 8,
      selling_price: 10,
      current_quantity: 3,
      minimum_stock_threshold: 2,
      unit: 'pack',
    });
    expect(created.status).toBe(201);
    const id = created.body.data.id;

    // Duplicate SKU -> 409
    const dupSku = await request(app).post('/api/products').send({
      name: 'Duplicate SKU Item',
      sku: 'TST-BHJ-999',
      category: 'Snacks',
      cost_price: 8,
      selling_price: 10,
      current_quantity: 1,
      minimum_stock_threshold: 1,
    });
    expect(dupSku.status).toBe(409);

    // Prevent negative stock adjustment
    const negAdj = await request(app).post('/api/stock/adjust').send({
      product_id: id,
      quantity_changed: -5,
      movement_type: 'Sale',
      reason: 'Too many units',
    });
    expect(negAdj.status).toBe(400);
    expect(negAdj.body.error).toBe('INSUFFICIENT_STOCK');

    // Adjust to 0 -> Out of Stock
    const zeroAdj = await request(app).post('/api/stock/adjust').send({
      product_id: id,
      quantity_changed: -3,
      movement_type: 'Sale',
      reason: 'Sold remaining units',
    });
    expect(zeroAdj.status).toBe(200);
    expect(zeroAdj.body.data.product.stock_status).toBe('Out of Stock');

    // Edit & Delete
    const editRes = await request(app).put(`/api/products/${id}`).send({ selling_price: 12 });
    expect(editRes.status).toBe(200);
    expect(editRes.body.data.selling_price).toBe(12);

    const delRes = await request(app).delete(`/api/products/${id}`);
    expect(delRes.status).toBe(200);
  });

  it('enforces offline sync idempotency and optimistic version conflict detection', async () => {
    const listRes = await request(app).get('/api/products?search=Parle-G');
    const prod = listRes.body.data[0];

    const opId = 'offline-op-unique-001';
    const first = await request(app).post('/api/stock/adjust').send({
      product_id: prod.id,
      quantity_changed: 5,
      movement_type: 'Supplier delivery',
      reason: 'Offline sync delivery',
      client_operation_id: opId,
      expected_version: prod.version,
    });
    expect(first.status).toBe(200);
    expect(first.body.data.product.current_quantity).toBe(prod.current_quantity + 5);

    // Retry same operation ID -> idempotent, no duplicate increment
    const replay = await request(app).post('/api/stock/adjust').send({
      product_id: prod.id,
      quantity_changed: 5,
      movement_type: 'Supplier delivery',
      reason: 'Offline sync delivery',
      client_operation_id: opId,
      expected_version: prod.version,
    });
    expect(replay.status).toBe(200);
    expect(replay.body.data.already_processed).toBe(true);
    expect(replay.body.data.product.current_quantity).toBe(prod.current_quantity + 5);

    // Stale expected_version with new opId -> 409 CONFLICT
    const stale = await request(app).post('/api/stock/adjust').send({
      product_id: prod.id,
      quantity_changed: -1,
      movement_type: 'Sale',
      reason: 'Stale client adjustment',
      client_operation_id: 'offline-op-stale-002',
      expected_version: prod.version,
    });
    expect(stale.status).toBe(409);
    expect(stale.body.error).toBe('CONFLICT');
  });

  it('updates inventory atomically when receiving a purchase order and persists across DB reopen', async () => {
    const suppliers = await request(app).get('/api/suppliers');
    const supplier = suppliers.body.data[0];
    const prods = await request(app).get(`/api/products?supplier_id=${supplier.id}`);
    const targetProd = prods.body.data[0];
    const startQty = targetProd.current_quantity;

    const poCreate = await request(app).post('/api/purchase-orders').send({
      supplier_id: supplier.id,
      status: 'Sent',
      items: [{ product_id: targetProd.id, quantity_ordered: 10, unit_cost: targetProd.cost_price }],
    });
    expect(poCreate.status).toBe(201);
    const poId = poCreate.body.data.id;

    // Receive PO -> inventory must increase by 10
    const receiveRes = await request(app).put(`/api/purchase-orders/${poId}`).send({
      status: 'Received',
    });
    expect(receiveRes.status).toBe(200);
    expect(receiveRes.body.data.status).toBe('Received');

    const prodAfter = await request(app).get(`/api/products/${targetProd.id}`);
    expect(prodAfter.body.data.current_quantity).toBe(startQty + 10);

    // Expiry alerts endpoint
    const expiryAlerts = await request(app).get('/api/expiry/alerts');
    expect(expiryAlerts.status).toBe(200);
    expect(expiryAlerts.body.data.counts.days_7).toBeGreaterThan(0);

    // Reopen SQLite file to verify real disk persistence
    db.close();
    db = new Database(dbPath);
    db.pragma('foreign_keys = ON');
    app = createApiApp(db);

    const persistedProd = await request(app).get(`/api/products/${targetProd.id}`);
    expect(persistedProd.status).toBe(200);
    expect(persistedProd.body.data.current_quantity).toBe(startQty + 10);
  });
});
